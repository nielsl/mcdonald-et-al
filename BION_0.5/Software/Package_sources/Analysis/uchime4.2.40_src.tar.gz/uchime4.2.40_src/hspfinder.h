#ifndef hspfinder_h
#define hspfinder_h

#include "seq.h"

class HSPFinder
	{
public:
	void SetA(const SeqData &/*SD*/) {}
	void SetB(const SeqData &/*SD*/) {}
	};

#endif // hspfinder_h
