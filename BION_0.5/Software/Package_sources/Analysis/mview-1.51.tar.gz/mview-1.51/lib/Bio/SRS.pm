###########################################################################
#
# Copyright (C) 1997-2008 Nigel P. Brown
# 
# (i) License
# 
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
# 
# (ii) Contacts
# 
#  Project Admin:      Nigel P. Brown
#  Email:              npb@users.sourceforge.net
#  Project URL:        http://bio-mview.sourceforge.net
# 
# (iii) Citation
# 
#  Please acknowledge use of this Program by citing the following reference in
#  any published work including web-sites:
#  
#   Brown, N.P., Leroy C., Sander C. (1998) MView: A Web compatible database
#   search or multiple alignment viewer. Bioinformatics. 14(4):380-381.
#  
#  and provide a link to the MView project URL given above under 'Contacts'.
#
###########################################################################

###########################################################################
#
# Copyright (C) 1997-2008 Nigel P. Brown
# 
# (i) License
# 
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
# 
# (ii) Contacts
# 
#  Project Admin:      Nigel P. Brown
#  Email:              npb@users.sourceforge.net
#  Project URL:        http://bio-mview.sourceforge.net
# 
# (iii) Citation
# 
#  Please acknowledge use of this Program by citing the following reference in
#  any published work including web-sites:
#  
#   Brown, N.P., Leroy C., Sander C. (1998) MView: A Web compatible database
#   search or multiple alignment viewer. Bioinformatics. 14(4):380-381.
#  
#  and provide a link to the MView project URL given above under 'Contacts'.
#
###########################################################################

# $Id: SRS.pm,v 1.20 2008/05/20 12:39:27 npb Exp $

###########################################################################
package Bio::SRS;

@ISA       = qw(Exporter);
@EXPORT    = qw(srsLink);
@EXPORT_OK = ();

use vars qw($Type);

$Type = 1;    #this SRS

###########################################################################
#NCBI entrez 2007
my $URL_NCBI =
    'http://www.ncbi.nlm.nih.gov/entrez/viewer.fcgi';
my %MAP_NCBI = 
    (
     #protein databases	       
     'dbj'     => "$URL_NCBI?val=&AC",
     'emb'     => "$URL_NCBI?val=&AC",
     'gb'      => "$URL_NCBI?val=&AC",
     'pdb'     => "$URL_NCBI?val=&AC&ID",
     'pir'     => "$URL_NCBI?val=&ID",
     'ref'     => "$URL_NCBI?val=&AC",
     'sp'      => "$URL_NCBI?val=&AC",
    );

###########################################################################
#EBI SRS server 2008
my $URL_EBI    = 'http://srs.ebi.ac.uk/srsbin/cgi-bin/wgetz';
my %MAP_EBI =
    (
     #protein databases
     'UNIPROT' => "$URL_EBI?-e+[uniprot-id:(&ID)]|[uniprot-acc:(&AC)]+-noSession",
     'SW'      => "$URL_EBI?-e+[swissprot-id:(&ID)]|[swissprot-acc:(&AC)]+-noSession",
     'UR100'   => "$URL_EBI?-e+[uniref100-acc:(&AC)]+-noSession",
     'UR090'   => "$URL_EBI?-e+[uniref90-acc:(&AC)]+-noSession",
     'UR050'   => "$URL_EBI?-e+[uniref50-acc:(&AC)]+-noSession",
     'UNIPARC' => "$URL_EBI?-e+[uniparc-id:(&ID)]|[uniparc-acc:(&AC)]+-noSession",
     'IPI'     => "$URL_EBI?-e+([ipi-id:(&ID)]|[ipi-acc:(&AC)])+-noSession",
     'PDB'     => "$URL_EBI?-e+[pdb-id:(&ID)]+-noSession",

     #nucleotide databases
     'EM_REL'  => "$URL_EBI?-e+([emblidacc-id:(&ID)]%3Eembl)|[embl-acc:(&AC)]+-view+EmblEntry+-noSession",
     'EM_NEW'  => "$URL_EBI?-e+([emblidacc-id:(&ID)]%3Eembl)|[embl-acc:(&AC)]+-view+EmblEntry+-noSession",
    );
#EMBL nucleotide database aliases to EM_REL
$MAP_EBI{'EM_ANN'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_CON'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_EST'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_GSS'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_HTC'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_HTG'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_PAT'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_STD'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_STS'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_TPA'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_WGS'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_ENV'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_FUN'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_HUM'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_INV'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_MAM'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_MUS'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_PHG'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_PLN'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_PRO'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_ROD'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_SYN'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_TGN'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_UNC'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_VRL'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_VRT'} = \$MAP_EBI{'EM_REL'};
$MAP_EBI{'EM_OM'}  = \$MAP_EBI{'EM_REL'};

###########################################################################
sub srsLink {
    my ($tag) = @_;
    my ($link, $db, $ac, $id) = ('', '', '', '');

    return $link  unless $Type;
    
    my @tmp = ();

    #NCBI style names: gi|number|db|ac|id
    if ($tag =~ /^gi\|[0-9]+\|/) {
	if ((@tmp = split(/\|/, $tag)) >= 5) {
	    ($db, $ac, $id) = ($tmp[2], $tmp[3], $tmp[4]);
	    $link = getLink(\%MAP_NCBI, $db, $ac, $id);
	}
        #warn "Split NCBI (long) $tag => ($db, $ac, $id) => $link\n";
	return $link;
    }

    #NCBI style names: db|ac|id,  db|ac|
    if ($tag =~ /^[^|:]+\|/) {
	if ((@tmp = split(/\|/, $tag)) >= 2) {
	    ($db, $ac, $id) = ($tmp[0], $tmp[1], $tmp[2]||"");
	    if ($ac =~ /^(\S+):\S+/) {
		#SEGS style name:range
		$ac = $id = $1;
	    }
	    $link = getLink(\%MAP_NCBI, $db, $ac, $id);
	}
	#warn "Split NCBI (short) $tag => ($db, $ac, $id) => $link\n";
	return $link;
    }

    #EBI/GCG style names: db:id
    if ($tag =~ /^[^|:]+\:/) {
	if ((@tmp = split(/:/, $tag)) >= 2) {
	    ($db, $ac, $id) = ($tmp[0], $tmp[1], $tmp[1]);
	    $link = getLink(\%MAP_EBI, $db, $ac, $id);
	}
	#warn "Split EBI $tag => ($db,$ac,$id) => $link\n";
	return $link;
    }

    #no match
    return $link;
}

sub getLink() {
    my ($map, $db, $ac, $id) = @_;
    $link = '';
    if (exists $map->{$db}) {
	$link = $map->{$db};
    }
    if (ref $link) { #follow aliases
	if (defined $$link) {
	    $link = $$link;
	} else {
	    $link = '';
	}
    }

    #remove trailing single character qualifiers: .1 _A
    if ($ac =~ /^([^.]+)[._].$/) {
        $ac = $1;
    }
    if ($id =~ /^([^.]+)[._].$/) {
        $id = $1;
    }

    #remove trailing punctuation
    if ($ac =~ /^(.+)[.,;:-_|]+$/) {
        $ac = $1;
    }
    if ($id =~ /^(.+)[.,;:-_|]+$/) {
        $id = $1;
    }

    #substitute into template
    $link =~ s/\&AC/$ac/g;
    $link =~ s/\&ID/$id/g;
    #warn "Link  ($db,$ac,$id) => $link\n";

    return $link;
}

###########################################################################
1;
