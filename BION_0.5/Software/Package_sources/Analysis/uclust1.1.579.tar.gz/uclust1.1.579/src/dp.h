#ifndef dp_h
#define dp_h

#define SAVE_FAST	0

#include "myutils.h"
#include "mx.h"
#include "seqdb.h"
#include "path.h"
#include "diagbox.h"
#include "alnparams.h"

typedef void (*OnPathFn)(const string &Path, bool Full);
struct SegPair;
struct AlnParams;

// public
const char *ViterbiBrute(const SegPair &SP, const AlnParams &AP,
  unsigned DiagLo = UINT_MAX, unsigned DiagHi = UINT_MAX);
const char *ViterbiSimple(const SegPair &SP, const AlnParams &AP);
const char *ViterbiSimpleBand(const SegPair &SP, const AlnParams &AP,
  unsigned DiagLo, unsigned DiagHi);
const char *ViterbiFast(const SegPair &SP, const AlnParams &AP);
const char *ViterbiFastBand(const SegPair &SP, const AlnParams &AP,
  unsigned DiagLo, unsigned DiagHi);
const char *ViterbiFastMainDiag(const SegPair &SP, const AlnParams &AP,
  unsigned BandWidth);

void LogAln(const SegPair &SP, const char *Path);

void GetBruteMxs(Mx<float> **M, Mx<float> **D, Mx<float> **I);
void GetSimpleMxs(Mx<float> **M, Mx<float> **D, Mx<float> **I);
void GetSimpleBandMxs(Mx<float> **M, Mx<float> **D, Mx<float> **I);
#if	SAVE_FAST
void GetFastMxs(Mx<float> **M, Mx<float> **D, Mx<float> **I);
void GetFastBandMxs(Mx<float> **M, Mx<float> **D, Mx<float> **I);
#endif

// private
char *TraceBackBit(unsigned LA, unsigned LB, char State);
void EnumPaths(unsigned L1, unsigned L2, bool SubPaths, OnPathFn OnPath);
float ScorePath(const SegPair &SP, const AlnParams &AP, const char *Path);
void AllocBit(unsigned LA, unsigned LB);

const byte TRACEBITS_DM = 0x01;
const byte TRACEBITS_IM = 0x02;
const byte TRACEBITS_MD = 0x04;
const byte TRACEBITS_MI = 0x08;

extern Mx<byte> g_Mx_TBBit;
extern float *g_DPRow1;
extern float *g_DPRow2;
extern byte **g_TBBit;
extern float **g_SubstMx;

struct SegPair
	{
	const char *LabelA;
	const char *LabelB;
	const byte *A;
	const byte *B;
	unsigned LA;
	unsigned LB;
	unsigned LoA;
	unsigned LoB;
	unsigned SA;
	unsigned SB;

	bool IsFrag() const
		{
		return LoA > 0 || LoB > 0 || SA < LA || SB < LA;
		}

	unsigned GetSegLenA() const
		{
		asserta(SA <= LA);
		return SA;
		}

	unsigned GetSegLenB() const
		{
		asserta(SB <= LB);
		return SB;
		}

	bool LeftA() const
		{
		return LoA == 0;
		}

	bool LeftB() const
		{
		return LoB == 0;
		}

	bool RightA() const
		{
		return LoA + SA == LA;
		}

	bool RightB() const
		{
		return LoB + SB == LB;
		}

	void LogMe() const
		{
		Log("SegPair A(Lo=%u,L=%u,S=%u)%s, B=(Lo=%u,S=%u,L=%u)%s\n",
		  LoA, SA, LA, LabelA,
		  LoB, SB, LB, LabelB);
		}

	void Init(const SeqDB &DB, unsigned i, unsigned j)
		{
		LabelA = DB.GetLabel(i).c_str();
		LabelB = DB.GetLabel(j).c_str();

		A = DB.GetSeq(i);
		B = DB.GetSeq(j);

		LA = DB.GetSeqLength(i);
		LB = DB.GetSeqLength(j);
		asserta(LA > 0 && LB > 0);

		LoA = 0;
		LoB = 0;

		SA = LA;
		SB = LB;
		}
	};

static inline void Max_xM(float &Score, float MM, float DM, float IM, byte &State)
	{
	Score = MM;
	State = 'M';

	if (DM > Score)
		{
		Score = DM;
		State = 'D';
		}
	if (IM > Score)
		{
		Score = IM;
		State = 'I';
		}
	}

static inline void Max_xD(float &Score, float MD, float DD, byte &State)
	{
	if (MD >= DD)
		{
		Score = MD;
		State = 'M';
		}
	else
		{
		Score = DD;
		State = 'D';
		}
	}

static inline void Max_xI(float &Score, float MI, float II, byte &State)
	{
	if (MI >= II)
		{
		Score = MI;
		State = 'M';
		}
	else
		{
		Score = II;
		State = 'I';
		}
	}

#endif // dp_h
