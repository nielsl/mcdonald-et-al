#include "dp.h"
#include "seqdb.h"

#define TRACE_MX	0

extern float **g_SubstMx;

void TestVit()
	{
	SeqDB Input;
	Input.FromFasta(opt_input);

	AlnParams AP;
	// AP.Set(g_SubstMx, -10, -1);

	AP.SubstMx = g_SubstMx;
	AP.OpenA = -12;
	AP.OpenB = -11;
	AP.LOpenA = -10;
	AP.LOpenB = -9;
	AP.ROpenA = -8;
	AP.ROpenB = -7;
	AP.ExtA = -6;
	AP.ExtB = -5;
	AP.LExtA = -4;
	AP.LExtB = -3;
	AP.RExtA = -2;
	AP.RExtB = -1;

	AP.LogMe();

	const unsigned SeqCount = Input.GetSeqCount();
	unsigned PairCount = (SeqCount*(SeqCount - 1))/2;
	unsigned Count = 0;
	for (unsigned i = 0; i < SeqCount; ++i)
		{
		for (unsigned j = i+1; j < SeqCount; ++j)
			{
			ProgressStep(Count++, PairCount, "Testing");

			SegPair SP;
			SP.Init(Input, i, j);

			unsigned LA = Input.GetSeqLength(i);
			unsigned LB = Input.GetSeqLength(j);

			unsigned DiagLo = 1;
			unsigned DiagHi = LA + LB - 1;

		// Use string as 'strsave' coz static buffer is overwritten.
			string PathBrute = ViterbiBrute(SP, AP, DiagLo, DiagHi);

			string PathSimple = ViterbiSimple(SP, AP);
			string PathSimpleBand = ViterbiSimpleBand(SP, AP, DiagLo, DiagHi);

			string PathFast = ViterbiFast(SP, AP);
			string PathFastBand = ViterbiFastBand(SP, AP, DiagLo, DiagHi);

			Mx<float> *BruteM, *BruteD, *BruteI;
			Mx<float> *SimpleM, *SimpleD, *SimpleI;
			Mx<float> *SimpleBandM, *SimpleBandD, *SimpleBandI;

			GetBruteMxs(&BruteM, &BruteD, &BruteI);
			GetSimpleMxs(&SimpleM, &SimpleD, &SimpleI);
			GetSimpleBandMxs(&SimpleBandM, &SimpleBandD, &SimpleBandI);

#if	SAVE_FAST
			Mx<float> *FastM, *FastD, *FastI;
			Mx<float> *FastBandM, *FastBandD, *FastBandI;
			GetFastMxs(&FastM, &FastD, &FastI);
			GetFastBandMxs(&FastBandM, &FastBandD, &FastBandI);
#endif

		// Hack to fix boundary cases
			SimpleBandD->Put(LA, 0, BruteD->Get(LA, 0));
			SimpleBandI->Put(0, LB, BruteI->Get(0, LB));

			bool SimpleMEq = SimpleM->Eq(*BruteM);
			bool SimpleDEq = SimpleD->Eq(*BruteD);
			bool SimpleIEq = SimpleI->Eq(*BruteI);

			bool SimpleBandMEq = SimpleBandM->Eq(*BruteM);
			bool SimpleBandDEq = SimpleBandD->Eq(*BruteD);
			bool SimpleBandIEq = SimpleBandI->Eq(*BruteI);

#if	SAVE_FAST
			bool FastMEq = FastM->Eq(*BruteM);
			bool FastDEq = FastD->Eq(*BruteD);
			bool FastIEq = FastI->Eq(*BruteI);
			bool FastBandMEq = FastBandM->Eq(*BruteM);
			bool FastBandDEq = FastBandD->Eq(*BruteD);
			bool FastBandIEq = FastBandI->Eq(*BruteI);
#endif

#if	TRACE_MX
			Log("---------------------\n");
			Log("\n");
			Log("Brute:\n");
			Log("%s\n", PathBrute.c_str());
			LogAln(SP, PathBrute.c_str());

			Log("\n");
			Log("FullSimple:\n");
			Log("%s\n", PathSimple.c_str());
			LogAln(SP, PathSimple.c_str());

			Log("\n");
			Log("BandSimple:\n");
			Log("%s\n", PathSimpleBand.c_str());
			LogAln(SP, PathSimpleBand.c_str());

#if	SAVE_FAST
			Log("\n");
			Log("Fast:\n");
			Log("%s\n", PathFast.c_str());
			LogAln(SP, PathFast.c_str());
			Log("\n");
#endif // SAVE_FAST
#endif // TRACE_MX
			Log("EQ=MDI Simple=%c%c%c SimpleBand=%c%c%c ",
			  tof(SimpleMEq),
			  tof(SimpleDEq),
			  tof(SimpleIEq),
			  tof(SimpleBandMEq),
			  tof(SimpleBandDEq),
			  tof(SimpleBandIEq));
#if	SAVE_FAST
		  Log(" Fast=%c%c%c FastBand=%c%c%c"
			  tof(FastMEq),
			  tof(FastDEq),
			  tof(FastIEq),
			  tof(FastBandMEq),
			  tof(FastBandDEq),
			  tof(FastBandIEq));
#endif
			Log("\n");
			}
		}
	}
