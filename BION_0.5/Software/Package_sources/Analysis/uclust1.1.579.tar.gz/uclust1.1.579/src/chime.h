#ifndef chime_h
#define chime_h
// svn v515 old voting system
struct RangeInfo
	{
	unsigned Qlo;
	unsigned P1lo;
	unsigned P2lo;

	unsigned Qhi;
	unsigned P1hi;
	unsigned P2hi;

	unsigned QL;
	unsigned P1L;
	unsigned P2L;

	void Clear()
		{
		memset(this, 0xff, sizeof(*this));
		}
	};

struct ChimeModel
	{
	RangeInfo Ranges;
	unsigned Qxlo;
	unsigned Qxhi;
	unsigned P1xlo;
	unsigned P1xhi;
	unsigned P2xlo;
	unsigned P2xhi;
	unsigned DiffsQ12;
	unsigned DiffsQ1;
	unsigned DiffsQ2;
	unsigned DiffsL1;
	unsigned DiffsL2;
	unsigned DiffsX1;
	unsigned DiffsX2;
	unsigned DiffsR1;
	unsigned DiffsR2;
	bool First1;

	void Clear();
	void LogMe() const;
	};

struct ChimeHit
	{
	string QueryLabel;
	unsigned QueryLength;
	unsigned SeedIndexTop;
	unsigned SeedIndex1;
	unsigned SeedIndex2;
	double Score;
	double TopId;
	double Id1;
	double Id2;
	double Id12;
	double IdModel;
	ChimeModel Model;
	unsigned ParentCount;

// Sort by decreasing score
	bool operator<(const ChimeHit &rhs) const
		{
		return Score > rhs.Score;
		}
	};

	//fprintf(g_fReport, Accept ? "YES" : "NO");
	//fprintf(g_fReport, "\t%s", LabQ.c_str());
	//fprintf(g_fReport, "\t%s", LabA.c_str());
	//fprintf(g_fReport, "\t%s", LabB.c_str());
	//fprintf(g_fReport, "\t%c\t%u\t%u\t%u\t%u\t%u\t%u\t%.1f\t%.1f\t%.1f\t%.3f\t%.1f\t\n",
	//  FirstA ? 'A' : 'B', LFor, LAgainst, LAbstain, RFor, RAgainst,
	//  LAbstain, IdA*100.0, IdB*100.0, BestIdM*100.0, BestDiv, BS);

struct ChimeHit2
	{
	string LabQ;
	string LabA;
	string LabB;
	string LabT;
/***
SNP classes:
	QMt		Y
	QmT		N
	qMT		A
	qmt		D
***/
	unsigned LY, LN, LA, LD;
	unsigned RY, RN, RA, RD;
	double PctIdA, PctIdB, PctIdT, PctIdM, PctIdAB;
	double Div;
	unsigned QXLo;
	unsigned QXHi;
	double BS;
	double H;
	unsigned QL;

	ChimeHit2()
		{
		Clear();
		}

	void LogMe() const
		{
		Log("%c Q=%s A=%s B=%s L=%u+/%u-/%u=/%u? R=%u+/%u-/%u=/%u? Div=%.3f H=%.4f\n",
		  Accept() ? 'Y' : 'n',
		  LabQ.c_str(), LabA.c_str(), LabB.c_str(),
		  LY, LN, LA, LD,
		  RY, RN, RA, RD,
		  Div, H);
		}

	void Clear()
		{
		LabQ.clear();
		LabA.clear();
		LabB.clear();
		LabT.clear();
		LY = LN = LA = LD = 0;
		RY = RN = RA = RD = 0;
		PctIdA = PctIdB = PctIdM = PctIdT = PctIdAB = -1.0;
		Div = -1.0;
		H = -1.0;
		BS = -1.0;
		QXLo = UINT_MAX;
		QXHi = UINT_MAX;
		//BS = 0.0;
		//BSL = 0.0;
		//BSR = 0.0;
		};

	bool Accept() const
		{
		return H >= opt_minh;
		}

	unsigned GetLTot() const
		{
		return LY + LN + LA + LD;
		}

	unsigned GetRTot() const
		{
		return RY + RN + RA + RD;
		}

	bool operator<(const ChimeHit2 &rhs) const
		{
		return H > rhs.H;
		}
	};

bool GetBestModel(const char *QueryLabel, const byte *QuerySeq, unsigned QueryLength,
  const char *ParentLabel1, const byte *ParentSeq1, unsigned ParentLength1, const string &Path1,
  const char *ParentLabel2, const byte *ParentSeq2, unsigned ParentLength2, const string &Path2,
  ChimeModel &Model);

double ScoreChime(const char *QueryLabel, const byte *QuerySeq, unsigned QueryLength,
  const char *ParentLabel1, const byte *ParentSeq1, unsigned ParentLength1, const string &Path1,
  const char *ParentLabel2, const byte *ParentSeq2, unsigned ParentLength2, const string &Path2,
  ChimeHit &Hit, bool DoOutput);

void WriteChimeRec(const ChimeHit2 &Hit);

#endif // chime_h
