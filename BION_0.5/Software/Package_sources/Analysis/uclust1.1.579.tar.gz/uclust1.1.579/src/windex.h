#ifndef windex_h
#define windex_h

typedef unsigned word_t; // TODO shorter type for shorter word length
typedef unsigned short wordcount_t;
typedef unsigned arrsize_t;
typedef unsigned short seqcountperword_t;
typedef unsigned seqindex_t;
typedef unsigned short commonwordcount_t;

const unsigned CapacityInc = 8;

#if	WINDEX_STRUCTS
struct WINDEX_ENTRY
	{
	arrsize_t m_Capacity;
	arrsize_t m_Size;
	seqcountperword_t *m_SeqCountsPerWord;
	seqindex_t *m_SeedIndexes;
	};
#endif

class Windex
	{
public:
	unsigned m_WordLength;
	unsigned m_WordCount;
	unsigned m_Hi;
	unsigned m_CapacityInc;
	arrsize_t *m_Capacities;
	arrsize_t *m_Sizes;
	seqindex_t **m_SeedIndexes;

	byte *m_UniqueCounts;

public:
	void AddWords(unsigned SeqIndex, const word_t *Words, unsigned N);
	void Init(unsigned WordLength);
	void LogMe() const;
	unsigned LogMemSize() const;
	void LogWordStats(unsigned TopWords = 10) const;
	const char *WordToStr(word_t Word) const;
	word_t SeqToWord(const byte *Seq) const;
	unsigned SeqToWords(const byte *Seq, unsigned L, word_t *Words) const;
	unsigned SeqToWordsStep(unsigned Step, const byte *Seq, unsigned L, word_t *Words) const;
	unsigned WordsToCounts(const word_t *Words, unsigned N,
	  word_t *UniqueWords, seqcountperword_t *Counts) const;
	unsigned GetUniqueWords(const word_t *Words, unsigned N,
	  word_t *UniqueWords) const;
	};

extern unsigned CharToLetter[256];

#endif // windex_h
