#include "myutils.h"
#include "mx.h"
#include "seqdb.h"

char ProbToChar(float p);

list<MxBase *> *MxBase::m_Matrices = 0;
unsigned MxBase::m_AllocCount;
unsigned MxBase::m_ZeroAllocCount;
unsigned MxBase::m_GrowAllocCount;
double MxBase::m_TotalBytes;
double MxBase::m_MaxBytes;

static const char *LogizeStr(const char *s)
	{
	double d = atof(s);
	d = log(d);
	return TypeToStr<float>(float(d));
	}

static const char *ExpizeStr(const char *s)
	{
	double d = atof(s);
	d = exp(d);
	return TypeToStr<float>(float(d));
	}

void MxBase::OnCtor(MxBase *Mx)
	{
	if (m_Matrices == 0)
		m_Matrices = new list<MxBase *>;
	asserta(m_Matrices != 0);
	m_Matrices->push_front(Mx);
	}

void MxBase::OnDtor(MxBase *Mx)
	{
	if (m_Matrices == 0)
		{
		Warning("MxBase::OnDtor, m_Matrices = 0");
		return;
		}
	for (list<MxBase*>::iterator p = m_Matrices->begin();
	  p != m_Matrices->end(); ++p)
		{
		if (*p == Mx)
			{
			m_Matrices->erase(p);
			if (m_Matrices->empty())
				delete m_Matrices;
			return;
			}
		}
	Warning("MxBase::OnDtor, not found");
	}

MxBase *MxBase::Get(const string &Name)
	{
	if (m_Matrices == 0)
		Die("MxBase::Get, m_Matrices=0");
	for (list<MxBase*>::iterator p = m_Matrices->begin();
	  p != m_Matrices->end(); ++p)
		{
		MxBase *m = *p;
		if (m != 0 && m->m_Name == Name)
			return m;
		}
	Die("MxBase::Get(%s), not found", Name.c_str());
	ureturn(0);
	}

float **MxBase::Getf(const string &Name)
	{
	Mx<float> *m = (Mx<float> *) Get(Name);
	asserta(m->GetTypeSize() == sizeof(float));
	return m->GetData();
	}

double **MxBase::Getd(const string &Name)
	{
	Mx<double> *m = (Mx<double> *) Get(Name);
	asserta(m->GetTypeSize() == sizeof(double));
	return m->GetData();
	}

char **MxBase::Getc(const string &Name)
	{
	Mx<char> *m = (Mx<char> *) Get(Name);
	asserta(m->GetTypeSize() == sizeof(char));
	return m->GetData();
	}

void MxBase::Alloc(const string &Name, unsigned RowCount, unsigned ColCount,
  SeqDB *DB, unsigned IdA, unsigned IdB)
	{
	StartTimer(MxBase_Alloc);

	++m_AllocCount;
	if (m_AllocatedRowCount == 0)
		++m_ZeroAllocCount;

	if (DB != 0)
		{
		asserta(IdA != UINT_MAX);
		asserta(IdB != UINT_MAX);
		asserta(RowCount >= DB->GetSeqLength(IdA) + 1);
		asserta(ColCount >= DB->GetSeqLength(IdB) + 1);
		}
	if (RowCount > m_AllocatedRowCount || ColCount > m_AllocatedColCount)
		{
		if (m_AllocatedRowCount > 0)
			{
			if (opt_logmemgrows)
				Log("MxBase::Alloc grow %s %u x %u -> %u x %u, %s bytes\n",
				  Name.c_str(), m_AllocatedRowCount, m_AllocatedColCount,
				  RowCount, ColCount,
				  IntToStr(GetBytes()));
			++m_GrowAllocCount;
			}

		m_TotalBytes -= GetBytes();

		PauseTimer(MxBase_Alloc);
		StartTimer(MxBase_FreeData);
		FreeData();
		EndTimer(MxBase_FreeData);
		StartTimer(MxBase_Alloc);

		unsigned N = max(RowCount + 16, m_AllocatedRowCount);
		unsigned M = max(ColCount + 16, m_AllocatedColCount);
		N = max(N, M);

		PauseTimer(MxBase_Alloc);
		StartTimer(MxBase_AllocData);
		AllocData(N, N);
		EndTimer(MxBase_AllocData);
		StartTimer(MxBase_Alloc);

		m_TotalBytes += GetBytes();
		if (m_TotalBytes > m_MaxBytes)
			m_MaxBytes = m_TotalBytes;
		}
	
	m_Name = Name;
	m_RowCount = RowCount;
	m_ColCount = ColCount;
	m_SeqDB = DB;
	m_IdA = IdA;
	m_IdB = IdB;

	EndTimer(MxBase_Alloc);
	}

void MxBase::LogMe(bool WithData, int Opts) const
	{
	Log("\n");
	if (Opts & OPT_EXP)
		Log("Exp ");
	else if (Opts & OPT_LOG)
		Log("Log ");
	Log("%s(%p) Rows %u/%u, Cols %u/%u",
	  m_Name.c_str(), this,
	  m_RowCount, m_AllocatedRowCount,
	  m_ColCount, m_AllocatedColCount);
	if (m_SeqDB != 0 && m_IdA != UINT_MAX)
		Log(", A=%s", m_SeqDB->GetLabel(m_IdA).c_str());
	if (m_SeqDB != 0 && m_IdB != UINT_MAX)
		Log(", B=%s", m_SeqDB->GetLabel(m_IdB).c_str());
	Log("\n");
	if (!WithData || m_RowCount == 0 || m_ColCount == 0)
		return;

	const char *z = GetAsStr(0, 0);
	unsigned Width = strlen(z);
	unsigned Mod = 1;
	for (unsigned i = 0; i < Width; ++i)
		Mod *= 10;

	if (!m_Alpha.empty())
		{
		Log("// Alphabet=%s\n", m_Alpha.c_str());
		Log("//      ");
		for (unsigned j = 0; j < SIZE(m_Alpha); ++j)
			Log(" %*c", Width, m_Alpha[j]);
		Log("\n");
		for (unsigned i = 0; i < SIZE(m_Alpha); ++i)
			{
			Log("/* %c */ {", m_Alpha[i]);
			unsigned ci = m_Alpha[i];
			for (unsigned j = 0; j < SIZE(m_Alpha); ++j)
				{
				unsigned cj = m_Alpha[j];
				Log("%s,", GetAsStr(ci, cj));
				}
			Log("},  // %c\n", m_Alpha[i]);
			}
		return;
		}

	const byte *A = 0;
	const byte *B = 0;
	if (m_SeqDB != 0 && m_IdA != UINT_MAX)
		A = m_SeqDB->GetSeq(m_IdA);
	if (m_SeqDB != 0 && m_IdB != UINT_MAX)
		B = m_SeqDB->GetSeq(m_IdB);

	if (B != 0)
		{
		if (A != 0)
			Log("  ");
		Log("%5.5s", "");
		for (unsigned j = 0; j < m_ColCount; ++j)
			Log("%*c", Width, j == 0 ? ' ' : B[j-1]);
		Log("\n");
		}

	if (A != 0)
		Log("  ");
	Log("%5.5s", "");
	for (unsigned j = 0; j < m_ColCount; ++j)
		Log("%*u", Width, j%Mod);
	Log("\n");

	for (unsigned i = 0; i < m_RowCount; ++i)
		{
		if (A != 0)
			Log("%c ", i == 0 ? ' ' : A[i-1]);
		Log("%4u ", i);
		
		for (unsigned j = 0; j < m_ColCount; ++j)
			{
			const char *s = GetAsStr(i, j);
			if (Opts & OPT_LOG)
				s = LogizeStr(s);
			else if (Opts & OPT_EXP)
				s = ExpizeStr(s);
			Log("%s", s);
			}
		Log("\n");
		}
	}
static unsigned g_MatrixFileCount;

void MxBase::LogCounts()
	{
	Log("\n");
	Log("MxBase::LogCounts()\n");
	Log("      What           N\n");
	Log("----------  ----------\n");
	Log("    Allocs  %10u\n", m_AllocCount);
	Log("ZeroAllocs  %10u\n", m_ZeroAllocCount);
	Log("     Grows  %10u\n", m_GrowAllocCount);
	Log("     Bytes  %10.10s\n", MemBytesToStr(m_TotalBytes));
	Log(" Max bytes  %10.10s\n", MemBytesToStr(m_MaxBytes));
	}
