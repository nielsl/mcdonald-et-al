#include "pwa.h"

#define TRACE_ALNS		0

void SetOpts();
double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path);
void GetLetterCounts(const char *Path, unsigned &NA, unsigned &NB);

void TestPWA()
	{
	SeqDB Input;
	Input.FromFasta(opt_input);

	SetOpts();

	AlnParams AP;

	AP.SubstMx = g_SubstMx;

	AP.OpenA = -10;
	AP.OpenB = -10;

	AP.ExtA = -1;
	AP.ExtB = -1;

	AP.LOpenA = -1;
	AP.LOpenB = -1;
	AP.ROpenA = -1;
	AP.ROpenB = -1;

	AP.LExtA = -0.5;
	AP.LExtB = -0.5;
	AP.RExtA = -0.5;
	AP.RExtB = -0.5;

	AP.LogMe();

	AlnHeuristics AH;
	AH.InitFromCmdLine();

	AlnHeuristics ASExact;
	ASExact.InitExact();

	Log("ASCmdLine: ");
	AH.LogMe();
	Log("  ASExact: ");
	ASExact.LogMe();

	PWA pwa;
	pwa.Init(opt_k);

	const unsigned SeqCount = Input.GetSeqCount();
	unsigned PairCount = (SeqCount*(SeqCount - 1))/2;
	unsigned Count = 0;

	Log("\n");
	Log("    i      j       Score     ScoreEx      Id    IdEx  Labels\n");
	Log("-----  -----  ----------  ----------  ------  ------  ------\n");

	unsigned PctIdWrongCount = 0;
	unsigned PctIdWrongCount2 = 0;
	unsigned ScoreWrongCount = 0;
	unsigned TotalSeqLength = 0;
#if	TIMING
	TICKS TotalTicksFast = 0;
	TICKS TotalTicksExact = 0;
#endif
	pwa.m_CheckFast = true;
	for (unsigned i = 0; i < SeqCount; ++i)
		{
		const char *LabelA = Input.GetLabel(i).c_str();
		const byte *A = Input.GetSeq(i);
		unsigned LA = Input.GetSeqLength(i);
		TotalSeqLength += LA;
 
		pwa.SetQuery(LabelA, A, LA);

		for (unsigned j = i+1; j < SeqCount; ++j)
			{
			ProgressStep(Count++, PairCount, "Testing PWA");

			const char *LabelB = Input.GetLabel(j).c_str();
			const byte *B = Input.GetSeq(j);
			unsigned LB = Input.GetSeqLength(j);

			pwa.SetTarget(LabelB, B, LB);
			pwa.Align(AP, AH);
			}
		}

	pwa.LogStats();
	}
