#ifndef path_h
#define path_h

extern char *g_PathBegin;
extern char *g_PathBack;
void AllocPath(unsigned LA, unsigned LB);

#endif // path_h
