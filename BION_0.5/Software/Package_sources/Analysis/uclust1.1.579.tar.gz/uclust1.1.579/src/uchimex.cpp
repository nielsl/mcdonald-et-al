#include "myutils.h"
#include "chime.h"

void UChime2(
  const string &LabQ, const byte *Q, unsigned QL,
  const string &LabA, const byte *A, unsigned AL, const string &PathA,
  const string &LabB, const byte *B, unsigned BL, const string &PathB,
  double TopPctId, struct ChimeHit2 &Hit);

void Make3Way(
  const string &LabQ, const byte *Q, unsigned QL,
  const string &LabA, const byte *A, unsigned AL, const string &PathA,
  const string &LabB, const byte *B, unsigned BL, const string &PathB,
  string &Q3, string &A3, string &B3);

extern FILE *g_f3;
extern FILE *g_fReportx;

static bool isacgt(char c)
	{
	return c == 'A' || c == 'C' || c == 'G' || c == 'T';
	}

static bool BetterHit(const ChimeHit2 &Hit1, const ChimeHit2 &Hit2)
	{
	return Hit1.H > Hit2.H;
	}

bool UChimeX(const string &QueryLabel, const byte *Q, unsigned QL,
  const vector<string> &PLabels, const vector<const byte *> &PSeqs,
  const vector<unsigned> &PLs, const vector<string> &Paths, 
  double TopPctId, ChimeHit2 &BestHit)
	{
	BestHit.Clear();
	BestHit.LabQ = QueryLabel;
	BestHit.PctIdT = TopPctId;

	const unsigned ParentCount = SIZE(PLabels);

	asserta(SIZE(PSeqs) == ParentCount);
	asserta(SIZE(PLs) == ParentCount);
	asserta(SIZE(Paths) == ParentCount);

	unsigned BestP1 = UINT_MAX;
	unsigned BestP2 = UINT_MAX;
	for (unsigned P1 = 0; P1 < ParentCount; ++P1)
		{
		const string &LabA = PLabels[P1];
		const byte *A = PSeqs[P1];
		const unsigned LA = PLs[P1];
		const string &PathA = Paths[P1];

		for (unsigned P2 = P1 + 1; P2 < ParentCount; ++P2)
			{
			const string &LabB = PLabels[P2];
			const byte *B = PSeqs[P2];
			const unsigned LB = PLs[P2];
			const string &PathB = Paths[P2];

			ChimeHit2 Hit;
			UChime2(QueryLabel, Q, QL, LabA, A, LA, PathA, LabB, B, LB, PathB, TopPctId, Hit);
			if (Hit.GetLTot() < opt_minsnps || Hit.GetRTot() < opt_minsnps || Hit.H < 0.001)
				continue;

			if (BetterHit(Hit, BestHit))
				{
				BestP1 = P1;
				BestP2 = P2;
				BestHit = Hit;
				}
			}
		}
	BestHit.PctIdT = TopPctId;

	if (g_f3 != 0 && BestP1 != UINT_MAX)
		{
		asserta(BestP2 != UINT_MAX);
		unsigned P1 = UINT_MAX;
		unsigned P2 = UINT_MAX;

		for (unsigned i = 0; i < ParentCount; ++i)
			{
			if (PLabels[i] == BestHit.LabA)
				P1 = i;
			if (PLabels[i] == BestHit.LabB)
				P2 = i;
			}
		asserta(P1 != UINT_MAX && P2 != UINT_MAX);

		const string &LabA = PLabels[P1];
		const byte *A = PSeqs[P1];
		const unsigned LA = PLs[P1];
		const string &PathA = Paths[P1];

		const string &LabB = PLabels[P2];
		const byte *B = PSeqs[P2];
		const unsigned LB = PLs[P2];
		const string &PathB = Paths[P2];

		string Q3;
		string A3;
		string B3;
		Make3Way(QueryLabel, Q, QL, LabA, A, LA, PathA, LabB, B, LB, PathB, Q3, A3, B3);

		fprintf(g_f3, ">%s\n", QueryLabel.c_str());
		fprintf(g_f3, "%s\n", Q3.c_str());
		fprintf(g_f3, ">%s\n", LabA.c_str());
		fprintf(g_f3, "%s\n", A3.c_str());
		fprintf(g_f3, ">%s\n", LabB.c_str());
		fprintf(g_f3, "%s\n", B3.c_str());
		fprintf(g_f3, "\n");
		}

	if (BestHit.Accept() && g_fReportx != 0 && BestP1 != UINT_MAX)
		{
		asserta(BestP2 != UINT_MAX);

		unsigned P1 = UINT_MAX;
		unsigned P2 = UINT_MAX;

		for (unsigned i = 0; i < ParentCount; ++i)
			{
			if (PLabels[i] == BestHit.LabA)
				P1 = i;
			if (PLabels[i] == BestHit.LabB)
				P2 = i;
			}
		asserta(P1 != UINT_MAX && P2 != UINT_MAX);

		const string &LabA = PLabels[P1];
		const byte *A = PSeqs[P1];
		const unsigned LA = PLs[P1];
		const string &PathA = Paths[P1];

		const string &LabB = PLabels[P2];
		const byte *B = PSeqs[P2];
		const unsigned LB = PLs[P2];
		const string &PathB = Paths[P2];

		string Q3;
		string A3;
		string B3;
		Make3Way(QueryLabel, Q, QL, LabA, A, LA, PathA, LabB, B, LB, PathB, Q3, A3, B3);

		fprintf(g_fReportx, "\n");
		fprintf(g_fReportx, "------------------------------------------------------------------------\n");
		fprintf(g_fReportx, "Query   (%5u nt) %s\n", QL, QueryLabel.c_str());
		fprintf(g_fReportx, "ParentA (%5u nt) %s\n", LA, LabA.c_str());
		fprintf(g_fReportx, "ParentB (%5u nt) %s\n", LB, LabB.c_str());

		const unsigned L = SIZE(Q3);
		asserta(SIZE(A3) == L);
		asserta(SIZE(B3) == L);
		unsigned From = UINT_MAX;
		unsigned To = UINT_MAX;
		unsigned ALo = UINT_MAX;
		unsigned BLo = UINT_MAX;
		unsigned APos = UINT_MAX;
		unsigned BPos = UINT_MAX;
		for (unsigned i = 0; i < L; ++i)
			{
			char c = Q3[i];
			if (c != '-')
				{
				if (From == UINT_MAX)
					{
					ALo = APos;
					BLo = BPos;
					From = i;
					}
				To = i;
				}
			if (A3[i] != '-')
				++APos;
			if (B3[i] != '-')
				++BPos;
			}
		if (ALo == UINT_MAX)
			ALo = 0;
		if (BLo == UINT_MAX)
			BLo = 0;

		string Qs = Q3.substr(From, To-From+1).c_str();
		string As = A3.substr(From, To-From+1).c_str();
		string Bs = B3.substr(From, To-From+1).c_str();
		const unsigned ColCount = SIZE(Qs);
		asserta(SIZE(As) == ColCount);
		asserta(SIZE(Bs) == ColCount);

		string Vs;
		unsigned QPos = 0;
		unsigned FirstACol = UINT_MAX;
		unsigned LastBCol = UINT_MAX;
		for (unsigned Col = 0; Col < ColCount; ++Col)
			{
			char a = As[Col];
			char b = Bs[Col];
			char q = Qs[Col];
			char v = ' ';

			if (isacgt(a) && isacgt(b) && isacgt(q))
				{
				bool Left = QPos <= BestHit.QXLo;
				bool Right = QPos > BestHit.QXHi;
				bool XOver = (!Left && !Right);
				if (q == a && q != b)
					v = Left ? 'A' : 'a';
				else if (q == b && q != a)
					v = Right ? 'B' : 'b';
				else if (a == b && q != a)
					v = 'N';
				else if (q != a && q != b)
					v = '?';
				}
			if (v == 'A' && FirstACol == UINT_MAX)
				FirstACol = Col;
			if (v == 'B')
				LastBCol = Col;

			if (q != '-')
				++QPos;
			Vs.push_back(v);
			}

		string LRs;
		QPos = 0;
		for (unsigned Col = 0; Col < ColCount; ++Col)
			{
			if (QPos <= BestHit.QXLo)
				{
				if (Col >= FirstACol)
					LRs.push_back('A');
				else
					LRs.push_back('.');
				}
			else if (QPos > BestHit.QXHi)
				{
				if (Col <= LastBCol)
					LRs.push_back('B');
				else
					LRs.push_back('.');
				}
			else
				LRs.push_back('x');
			char c = Qs[Col];
			if (c != '-')
				++QPos;
			}

		APos = ALo;
		BPos = BLo;
		QPos = 0;
		unsigned RowCount = (ColCount + 79)/80;
		for (unsigned RowIndex = 0; RowIndex < RowCount; ++RowIndex)
			{
			fprintf(g_fReportx, "\n");
			unsigned FromCol = RowIndex*80;
			unsigned ToCol = FromCol + 79;
			if (ToCol >= ColCount)
				{
				asserta(RowIndex + 1 == RowCount);
				ToCol = ColCount - 1;
				}

		// A row
			fprintf(g_fReportx, "A %5u ", APos + 1);
			for (unsigned Col = FromCol; Col <= ToCol; ++Col)
				{
				char q = Qs[Col];
				char a = As[Col];
				if (a == q)
					a = tolower(a);
				fprintf(g_fReportx, "%c", a);
				if (a != '-')
					++APos;
				}
			fprintf(g_fReportx, " %u\n", APos);

		// Q row
			fprintf(g_fReportx, "Q %5u ", QPos + 1);
			for (unsigned Col = FromCol; Col <= ToCol; ++Col)
				{
				char c = tolower(Qs[Col]);
				fprintf(g_fReportx, "%c", c);
				if (c != '-')
					++QPos;
				}
			fprintf(g_fReportx, " %u\n", QPos);

		// B row
			fprintf(g_fReportx, "B %5u ", BPos + 1);
			for (unsigned Col = FromCol; Col <= ToCol; ++Col)
				{
				char q = Qs[Col];
				char b = Bs[Col];
				if (b == q)
					b = tolower(b);
				fprintf(g_fReportx, "%c", b);
				if (b != '-')
					++BPos;
				}
			fprintf(g_fReportx, " %u\n", BPos);

		// Votes row
			fprintf(g_fReportx, "SNPs    ");
			for (unsigned Col = FromCol; Col <= ToCol; ++Col)
				{
				char c = Vs[Col];
				fprintf(g_fReportx, "%c", c);
				}
			fprintf(g_fReportx, "\n");

		// LR row
			fprintf(g_fReportx, "Model   ");
			for (unsigned Col = FromCol; Col <= ToCol; ++Col)
				{
				char c = LRs[Col];
				fprintf(g_fReportx, "%c", c);
				}
			fprintf(g_fReportx, "\n");
			}
		fprintf(g_fReportx, "\n");
		fprintf(g_fReportx, "Score   %.3f\n", BestHit.H);

		double PctIdP = max(BestHit.PctIdA, BestHit.PctIdB);
		double Div = (BestHit.PctIdM - PctIdP)*100.0/PctIdP;
		fprintf(g_fReportx, "Ids.    QA %.1f%%, QB %.1f%%, AB %.1f%%, QModel %.1f%%, Div. %+.1f%%\n",
		  BestHit.PctIdA,
		  BestHit.PctIdB,
		  BestHit.PctIdAB,
		  BestHit.PctIdM,
		  Div);

		unsigned LTot = BestHit.LY + BestHit.LN + BestHit.LA + BestHit.LD;
		unsigned RTot = BestHit.RY + BestHit.RN + BestHit.RA + BestHit.RD;
		double PctL = Pct(BestHit.LY, LTot);
		double PctR = Pct(BestHit.RY, RTot);
		fprintf(g_fReportx,
		  "SNPs    Left A=%u(%.0f%%)/b=%u/N=%u/?=%u, Right B=%u(%.0f%%)/a=%u/N=%u/?=%u\n",
		  BestHit.LY, PctL, BestHit.LN, BestHit.LA, BestHit.LD,
		  BestHit.RY, PctR, BestHit.RN, BestHit.RA, BestHit.RD);
		}

	return BestHit.H > 0;
	}
