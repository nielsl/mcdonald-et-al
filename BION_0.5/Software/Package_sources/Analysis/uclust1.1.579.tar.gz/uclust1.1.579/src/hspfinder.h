#ifndef hspfinder_h
#define hspfinder_h

#include "windex.h"//@@TODO needed for types, should decouple

const unsigned MinBorderCount = 0;
const unsigned MinDiagCount = 16; // MUST not be zero!
const unsigned MaxReps = 8;

struct HSPData
	{
	unsigned Alo;
	unsigned Blo;
	unsigned Length;
	unsigned SameCount;

	unsigned GetAhi() const
		{
		return Alo + Length - 1;
		}

	unsigned GetBhi() const
		{
		return Blo + Length - 1;
		}

	unsigned GetAmid() const
		{
		return Alo + Length/2;
		}

	unsigned GetBmid() const
		{
		return Blo + Length/2;
		}

	bool operator<(const HSPData &rhs) const
		{
		return Alo < rhs.Alo;
		}

	void LogMe() const
		{
		Log("Alo=%u Blo=%u L=%u Id=%u\n", Alo, Blo, Length, SameCount);
		}
	};

class HSPFinder
	{
public:
	unsigned m_WordLength;
	unsigned m_WordCount;
	unsigned m_Hi;
	unsigned m_AlphaSize;

	const char *m_LabelA;
	const char *m_LabelB;
	const byte *m_A;
	const byte *m_B;
	unsigned m_LA;
	unsigned m_LB;

	unsigned *m_WordToPosA;
	unsigned *m_WordCountsA;

	unsigned *m_DiagCounts;
	unsigned m_DiagCountsSize;

	word_t *m_WordsA;
	word_t *m_WordsB;
	unsigned m_WordCountA;
	unsigned m_WordCountB;
	unsigned m_WordsASize;
	unsigned m_WordsBSize;

public:
	HSPFinder();
	~HSPFinder();
	void Clear(bool ctor = false);

	void Init(unsigned WordLength);
	void SetA(const char *LabelA, const byte *A, unsigned LA);
	void SetB(const char *LabelB, const byte *B, unsigned LB);
	unsigned GetCommonWordCount() const;
	double GetHSPs(vector<HSPData> &HSPs);
	const char *WordToStr(unsigned Word) const;
	unsigned GetBestDiag();
	void GetPlausibleDiagRange(unsigned &dlo, unsigned &dhi) const;
	void LogMe() const;
	unsigned SeqToWord(const byte *Seq) const;
	static bool HSPInPath(const HSPData &HSP, const char *Path);

private:
	unsigned SeqToWords(const byte *Seq, unsigned L, word_t *Words) const;
	void AllocLA(unsigned LA);
	void AllocLB(unsigned LB);
	void AllocDiags(unsigned DiagCount);
	};

#endif // hspfinder_h
