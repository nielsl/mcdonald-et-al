#ifndef beta_h
#define	beta_h

double Beta_Function(double a, double b);
double Incomplete_Beta_Function(double x, double a, double b);

#endif	// beta_h
