#include "myutils.h"
#include "seqdb.h"
#include "uc.h"

/***
>Cluster 0
0       357aa, >KIRN_18E_655 E4OR... *
>Cluster 1
0       323aa, >KIRN_9A_80438 E4O... *
>Cluster 2
0       308aa, >KIRN_17A_37168 E4... at 98%
1       318aa, >KIRN_17A_45293 E4... *
***/

void UCFile::FromClstr(const string &FileName)
	{
	Clear();

	FILE *fClstr = OpenStdioFile(FileName);

	string Line;
	unsigned ClusterCount = 0;
	unsigned FileSize = GetStdioFileSize(fClstr);
	ProgressStep(0, FileSize, "Processing");
	while (ReadLineStdioFile(fClstr, Line))
		{
		unsigned Pos = (unsigned) GetStdioFilePos(fClstr);
		if (Pos < FileSize - 1)
			ProgressStep(Pos, FileSize, "%u clusters", ClusterCount);
		if (Line.empty())
			continue;
		if (Line[0] == '>')
			{
			// >Cluster 2
			// 0123456789
			string sn = Line.substr(9, string::npos);
			unsigned in = (unsigned) atoi(sn.c_str());
			if (in != ClusterCount)
				{
				static bool WarningIssued = false;
				if (!WarningIssued)
					{
					Warning("Expected Cluster %u, got '%s'",
					  ClusterCount, Line.c_str());
					WarningIssued = true;
					}
				}
//			fprintf(fDFA, "<Cluster %u\n", ClusterCount);
			++ClusterCount;
			}
		else
			{
			char LastChar = Line[Line.size()-1];
			if (LastChar != '*' && LastChar != '%')
				Die("Invalid line (doesn't end in '%%' or '*') '%s'", Line.c_str());

			vector<string> Fields;
			Split(Line, Fields);
			unsigned N = SIZE(Fields);

// 0       308aa, >KIRN_17A_37168 E4... at 98%
// 0       --1--- -------2------- --3-- -4 -5-
// 1       318aa, >KIRN_17A_45293 E4... *
// 0       --1--- -------2------- --3-- 4
			if (N < 3)
				Die("Invalid line has %u fields: '%s'", N, Line.c_str());

			unsigned SeqLength = (unsigned) atoi(Fields[1].c_str());
			string Id = Fields[2].substr(1, string::npos);
			if ((LastChar == '*' && N == 4) || (LastChar == '%' && N == 5))
				{
				unsigned L = SIZE(Id);
				if (L <= 3 || Id[L-1] != '.' || Id[L-2] != '.' || Id[L-3] != '.')
					Die("Missing ... in id '%s'", Id.c_str());
				Id = Id.substr(0, L-3);
				}

			const char *Label = strdup(Id.c_str());
			if (Label == 0)
				Die("Out of memory");
			m_Labels.push_back(Label);

			if (ClusterCount == 0)
				Die("Invalid .clstr file, didn't start with >Cluster.");

			char Strand = '.';
			if (LastChar == '*')
				{
			// Seed
				m_RecTypes.push_back('S');
				m_PctIds.push_back(0.0f);
				}
			else
				{
			// Hit
				m_RecTypes.push_back('H');
				string sPctId = Fields[N-1];
				asserta(!sPctId.empty());
				string sPctId2 = sPctId.substr(0, sPctId.size()-1);
				if (sPctId2[0] == '+' || sPctId2[0] == '-')
					{
					Strand = sPctId2[0];
					sPctId2 = sPctId2.substr(2, string::npos);
					}
				unsigned iPctId = (unsigned) atoi(sPctId2.c_str());
				m_PctIds.push_back(float(iPctId));
				}

			m_SeedIndexes.push_back(ClusterCount-1);
			m_SeqLengths.push_back(SeqLength);
			m_CompressedPaths.push_back("?");
			m_Strands.push_back(Strand);
			m_Los.push_back(0);
			m_SeedLos.push_back(0);
			}
		}
	ProgressStep(FileSize-1, FileSize, "%u clusters", ClusterCount);
	CloseStdioFile(fClstr);
	Sort();
	}
