//			Long name		Short		Default									Help
//FLAG_OPT(	someflag,		f,													"This is a flag option")

//			Long name		Short		Default		Min			Max				Help
//INT_OPT(	someint,		i,			-1,			INT_MIN,	INT_MAX,		"This is a signed integer option")

//			Long name		Short		Default		Min			Max				Help
//UNS_OPT(	someuns,		-,			0,			0,			UINT_MAX,		"This is an unsigned integer option")

//			Long name		Short		Default		Min			Max				Help
//FLT_OPT(	someflt,		f,			0.0,		-1,			+1,				"This is a floating-point option")

//			Long name		Short		Default									Help
//STR_OPT(	somestr,		s,			0,										"This is a string option")

//			Long name		Short		Default		Values						Help
//ENUM_OPT(	someenum,		e,			1,			"Value1=1|Value2=2",		"This is an enum option\nwith line break")

//			Long name		Short		Default									Help
STR_OPT(	input,			i,			0,										"Input file name")
STR_OPT(	report,			o,			0,										"")
STR_OPT(	reportx,		o,			0,										"")
STR_OPT(	test,			-,			0,										"")
STR_OPT(	lib,			-,			0,										"Compare input to this library")
STR_OPT(	sort,			-,			0,										"Sort sequences by length")
STR_OPT(	output,			-,			0,										"Output file (format varies by command)")
STR_OPT(	uc,				-,			0,										"Output file")
STR_OPT(	clstr2uc,		-,			0,										"")
STR_OPT(	uc2clstr,		-,			0,										"")
STR_OPT(	uc2fasta,		-,			0,										"")
STR_OPT(	mergesort,		-,			0,										"")
STR_OPT(	tmpdir,			-,			".",									"")
STR_OPT(	staralign,		-,			0,										"")
STR_OPT(	sortuc,			-,			0,										"")
STR_OPT(	blastout,		-,			0,										"Output file, blast-like format")
STR_OPT(	fastapairs,		-,			0,										"Output file, FASTA pairs")
STR_OPT(	types,			-,			"SH",									"")
STR_OPT(	idchar,			-,			"|",									"")
STR_OPT(	diffchar,		-,			" ",									"")
STR_OPT(	uchime,			-,			0,										"")
STR_OPT(	savechunks,		-,			0,										"")
STR_OPT(	henrik,			-,			0,										"")
STR_OPT(	threeway,		-,			0,										"")
STR_OPT(	gapopen,		-,			0,										"")
STR_OPT(	gapext,			-,			0,										"")
STR_OPT(	guide,			-,			0,										"")
STR_OPT(	linkage,		-,			0,										"")

UNS_OPT(	band,			-,			16,			0,			UINT_MAX,		"D.P. band radius (0=don't band)")
UNS_OPT(	minlen,			-,			10,			1,			UINT_MAX,		"Minimum sequence length")
UNS_OPT(	maxlen,			-,			10000,		1,			UINT_MAX,		"Maximum sequence length")
UNS_OPT(	w,				-,			0,			1,			UINT_MAX,		"")
UNS_OPT(	k,				-,			0,			1,			UINT_MAX,		"")
UNS_OPT(	stepwords,		-,			8,			0,			UINT_MAX,		"")
UNS_OPT(	maxaccepts,		-,			1,			0,			UINT_MAX,		"")
UNS_OPT(	maxrejects,		-,			8,			0,			UINT_MAX,		"")
UNS_OPT(	hsp,			-,			32,			1,			UINT_MAX,		"")
UNS_OPT(	bump,			-,			50,			0,			100,			"")
UNS_OPT(	rowlen,			-,			64,			8,			UINT_MAX,		"Row length for blast-like alignment formats")
UNS_OPT(	idprefix,		-,			0,			0,			UINT_MAX,		"")
UNS_OPT(	chunks,			-,			20,			2,			UINT_MAX,		"")
UNS_OPT(	minchunk,		-,			32,			2,			UINT_MAX,		"")
UNS_OPT(	minsnps,		-,			8,			1,			UINT_MAX,		"")

TOG_OPT(	trace,			-,			false,									"")
TOG_OPT(	logmemgrows,	-,			false,									"")
TOG_OPT(	trunclabels,	-,			false,									"Truncate FASTA labels at first whitespace")
TOG_OPT(	verbose,		-,			false,									"")
TOG_OPT(	wordcountreject,-,			true,									"")
TOG_OPT(	ovchunks,		-,			false,									"")

// Making --rev the default doubles memory use
TOG_OPT(	rev,			-,			false,									"")
TOG_OPT(	output_rejects,	-,			false,									"")
TOG_OPT(	blast_termgaps,	-,			false,									"")
TOG_OPT(	fastalign_chime,-,			false,									"")
TOG_OPT(	logbadhsps,		-,			false,									"")
TOG_OPT(	fastalign,		-,			true,									"")

FLT_OPT(	id,				-,			0.9,		0.0,		1.0,			"Fractional identity threshold for clustering")
FLT_OPT(	match,			-,			2.0,		0.0,		FLT_MAX,		"Match score (nucleotides only)")
FLT_OPT(	mismatch,		-,			-1.0,		0.0,		FLT_MAX,		"Mismatch score (nucleotides only)")
FLT_OPT(	hspscore,		-,			1.0,		0.0,		FLT_MAX,		"")
FLT_OPT(	split,			-,			1000.0,		1.0,		FLT_MAX,		"Split size for --mergesort")
FLT_OPT(	mint,			-,			16.0,		1.0,		FLT_MAX,		"")
FLT_OPT(	minh,			-,			0.6,		0.0,		1.0,			"")

FLAG_OPT(	amino,			-,													"")
FLAG_OPT(	nucleo,			-,													"")
FLAG_OPT(	usersort,		-,													"")
FLAG_OPT(	exact,			-,													"")
FLAG_OPT(	optimal,		-,													"")
FLAG_OPT(	version,		-,													"Print version number and exit")
FLAG_OPT(	svnmods,		-,													"Print version number and exit")
FLAG_OPT(	libonly,		-,													"")
FLAG_OPT(	allhits,		-,													"")
FLAG_OPT(	self,			-,													"")
FLAG_OPT(	check_fast,		-,													"")
