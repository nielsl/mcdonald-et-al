#include "myutils.h"
#include "ultra.h"
#include "timing.h"
#include "path.h"

const char *NWAff(const byte *A, unsigned LA, const byte *B, unsigned LB,
  bool LeftTerm, bool RightTerm);
void SortDescending(const unsigned *Values, unsigned N, unsigned *Order);
unsigned GetMinWindexWordCount(unsigned L, double FractId, unsigned WordLength);
unsigned GetMinFilterWordCount(unsigned L, double FractId, unsigned WordLength);
void GetBestSeg(const byte *A, unsigned LA, const byte *B, unsigned LB,
  unsigned Diag, unsigned &loi, unsigned &len);
const char *AlignSeg(const byte *A, unsigned LA, const byte *B, unsigned LB,
  unsigned Diag, unsigned Hiti, unsigned Hitlen);
double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path);
void GetLetterCounts(const string &Path, unsigned &NA, unsigned &NB);
void LogAln(const byte *A, const byte *B, const char *Path);
const char *AlignHSPs(const byte *A, unsigned LA, const byte *B, unsigned LB,
  const vector<HSPData> &HSPs);

//static bool BrianCtlLabel(const string &QueryLabel, const string &SeedLabel)
//	{
//	size_t n = QueryLabel.size();
//	if (n < 3 || QueryLabel[n-2] != '.' || !isdigit(QueryLabel[n-1]))
//		Die("BrianCtlLabel(%s,%s)", QueryLabel.c_str(), SeedLabel.c_str());
//
//	return QueryLabel.substr(0, n-2) == SeedLabel;
//	}

extern bool g_IsNucleo;

Ultra::Ultra()
	{
	Clear(true);
	}

Ultra::~Ultra()
	{
	Clear(false);
	}

void Ultra::Clear(bool ctor)
	{
//	m_Windex.Clear();
	m_PWA.Clear();
	m_AP.Clear();
	m_AH.Clear();

	if (!ctor)
		{
		myfree(m_SeedLabels);
		myfree(m_SeedSeqs);
		myfree(m_WordCounts);
		myfree(m_HotSeeds);
		myfree(m_HotWordCounts);
		myfree(m_HotSortOrder);
		myfree(m_CurrWords);
		myfree(m_CurrUniqueWords);
		myfree(m_SeedLengths);
		}

	m_SeedLabels = 0;
	m_SeedSeqs = 0;
	m_WordCounts = 0;
	m_HotSeeds = 0;
	m_HotWordCounts = 0;
	m_HotSortOrder = 0;
	m_Step = 0;
	m_CurrWords = 0;
	m_CurrUniqueWords = 0;
	m_SeedLengths = 0;

	m_MinFractId = 0;
	m_SeedCount = 0;
	m_MaxSeedCount = 0;
	m_HotCount = 0;
	m_MaxSeqLength = 0;
	m_CurrWordCount = 0;
	m_CurrUniqueWordCount = 0;
	m_CurrLabel = 0;
	m_CurrSeq = 0;
	m_CurrSeqLength = 0;

	m_Rev = false;
	}

void Ultra::Init(double FractId, unsigned WindexWordLength, unsigned FilterWordLength,
  const AlnParams &AP, const AlnHeuristics &AH)
	{
	m_MinFractId = FractId;
	m_Windex.Init(WindexWordLength);
	m_PWA.Init(FilterWordLength);
	m_AP = AP;
	m_AH = AH;
	}

void Ultra::AllocSeqLength(unsigned SeqLength)
	{
	if (SeqLength <= m_MaxSeqLength)
		return;

	StartTimer(U_AllocSeqLength);

	myfree(m_CurrWords);
	myfree(m_CurrUniqueWords);

// Lots of room to grow to avoid thrashing,
// only a couple of vectors here.
	m_MaxSeqLength = SeqLength + 1024;

	m_CurrWords = myalloc<word_t>(m_MaxSeqLength);
	m_CurrUniqueWords = myalloc<word_t>(m_MaxSeqLength);

	if (opt_logmemgrows)
		Log("Ultra::AllocSeqLength(%u)\n", m_MaxSeqLength);

	EndTimer(U_AllocSeqLength);
	}

void Ultra::AllocSeedCount(unsigned SeedCount)
	{
	if (SeedCount <= m_MaxSeedCount)
		return;

	StartTimer(U_AllocSeedCount);

// Big grow to avoid thrashing.
	m_MaxSeedCount = SeedCount < 100000 ? 100000 : (3*SeedCount)/2;

	if (opt_logmemgrows)
		Log("Ultra::AllocSeedCount(%u)\n", m_MaxSeedCount);

	byte **NewSeedSeqs = myalloc<byte *>(m_MaxSeedCount);
	const char **NewSeedLabels = myalloc<const char *>(m_MaxSeedCount);
	unsigned *NewSeedLengths = myalloc<unsigned>(m_MaxSeedCount);

	commonwordcount_t *NewWordCounts = myalloc<commonwordcount_t>(m_MaxSeedCount);
	unsigned *NewHotSeeds = myalloc<unsigned>(m_MaxSeedCount);
	unsigned *NewHotWordCounts = myalloc<unsigned>(m_MaxSeedCount);

	if (m_SeedCount > 0)
		{
		memcpy(NewSeedSeqs, m_SeedSeqs, m_SeedCount*sizeof(m_SeedSeqs[0]));
		memcpy(NewSeedLabels, m_SeedLabels, m_SeedCount*sizeof(m_SeedLabels[0]));
		memcpy(NewSeedLengths, m_SeedLengths, m_SeedCount*sizeof(m_SeedLengths[0]));

		memcpy(NewWordCounts, m_WordCounts, m_SeedCount*sizeof(m_WordCounts[0]));
		memcpy(NewHotSeeds, m_WordCounts, m_SeedCount*sizeof(m_HotSeeds[0]));
		memcpy(NewHotWordCounts, m_WordCounts, m_SeedCount*sizeof(m_HotWordCounts[0]));
		}

	myfree(m_SeedSeqs);
	myfree(m_SeedLengths);
	myfree(m_SeedLabels);

	myfree(m_WordCounts);
	myfree(m_HotSeeds);
	myfree(m_HotWordCounts);

	myfree(m_HotSortOrder);

	m_WordCounts = NewWordCounts;
	m_HotSeeds = NewHotSeeds;
	m_HotWordCounts = NewHotWordCounts;
	m_SeedSeqs = NewSeedSeqs;
	m_SeedLabels = NewSeedLabels;
	m_SeedLengths = NewSeedLengths;

	m_HotSortOrder = myalloc<unsigned>(m_MaxSeedCount);

	EndTimer(U_AllocSeedCount);
	}

unsigned Ultra::AddSeed(const char *Label, const byte *Seq, unsigned L)
	{
	SetCurrSeq(Label, Seq, L);
	CurrSeqToWords(1);
	return AddSeed();
	}

unsigned Ultra::AddSeed()
	{
	if (m_Step != 1)
		CurrSeqToWords(1);

	AllocSeedCount(m_SeedCount+1);

	StartTimer(U_AddSeed);

	unsigned SeedIndex = m_SeedCount++;
	m_SeedLabels[SeedIndex] = strdup(m_CurrLabel);
	asserta(m_SeedLabels[SeedIndex]);
	m_SeedSeqs[SeedIndex] = myalloc<byte>(m_CurrSeqLength);
	memcpy(m_SeedSeqs[SeedIndex], m_CurrSeq, m_CurrSeqLength);
	m_SeedLengths[SeedIndex] = m_CurrSeqLength;

	EndTimer(U_AddSeed);

	m_Windex.AddWords(SeedIndex, m_CurrUniqueWords, m_CurrUniqueWordCount);

	if (m_Rev)
		{
		void RevComp(const byte *Seq, unsigned L, byte *RCSeq);

		unsigned SeedIndex2 = m_SeedCount++;

		m_SeedLabels[SeedIndex2] = m_SeedLabels[SeedIndex];

		byte *RCSeq = myalloc<byte>(m_CurrSeqLength);

		RevComp(m_CurrSeq, m_CurrSeqLength, RCSeq);
		m_SeedSeqs[SeedIndex2] = RCSeq;

		m_SeedLengths[SeedIndex2] = m_CurrSeqLength;

		m_Windex.SeqToWordsStep(1, RCSeq, m_CurrSeqLength, m_CurrWords);

		unsigned UniqueWordCount = m_Windex.GetUniqueWords(m_CurrWords, m_CurrWordCount,
		  m_CurrUniqueWords);
		m_Windex.AddWords(SeedIndex2, m_CurrUniqueWords, m_CurrUniqueWordCount);

		return SeedIndex/2;
		}

	return SeedIndex;
	}

void Ultra::SetCurrSeq(const char *Label, const byte *Seq, unsigned L)
	{
	AllocSeqLength(L);

	m_CurrLabel = Label;
	m_CurrSeq = Seq;
	m_CurrSeqLength = L;
	}

void Ultra::CurrSeqToWords(unsigned Step)
	{
	AddCounter(Step, Step);

	m_Step = Step;
	m_CurrWordCount = m_Windex.SeqToWordsStep(Step, m_CurrSeq, m_CurrSeqLength,
	  m_CurrWords);

	m_CurrUniqueWordCount = m_Windex.GetUniqueWords(m_CurrWords, m_CurrWordCount,
	  m_CurrUniqueWords);
	}

void Ultra::SetWordCounts()
	{
	StartTimer(U_SetWordCounts);

	zero(m_WordCounts, m_SeedCount);

	for (unsigned i = 0; i < m_CurrUniqueWordCount; ++i)
		{
		word_t Word = m_CurrUniqueWords[i];

		arrsize_t Size = m_Windex.m_Sizes[Word];
		const seqindex_t *SeedIndexes = m_Windex.m_SeedIndexes[Word];

		for (unsigned j = 0; j < Size; ++j)
			{
			seqindex_t SeedIndex = SeedIndexes[j];
			assert(SeedIndex < m_SeedCount);
			++(m_WordCounts[SeedIndex]);
			}
		}

	EndTimer(U_SetWordCounts);
	}

void Ultra::SetHotHits(unsigned MinWordCount)
	{
	StartTimer(U_SetHotHits);

	m_HotCount = 0;
	if (opt_bump == 0 || MinWordCount == 0)
		{
		for (unsigned SeedIndex = 0; SeedIndex < m_SeedCount; ++SeedIndex)
			{
			unsigned n = m_WordCounts[SeedIndex];
			if (n >= MinWordCount)
				{
				m_HotWordCounts[m_HotCount] = n;
				m_HotSeeds[m_HotCount++] = SeedIndex;
				}
			}
		}
	else
		{
		double Bump = opt_bump/100.0;
		unsigned MaxCount = 0;
		unsigned MinCount = MinWordCount;
		for (unsigned SeedIndex = 0; SeedIndex < m_SeedCount; ++SeedIndex)
			{
			unsigned n = m_WordCounts[SeedIndex];
			if (n >= MinCount)
				{
				if (n > MaxCount)
					{
					unsigned NewMinCount = unsigned(n*Bump);
					if (NewMinCount > MinCount && NewMinCount < MaxCount)
						MinCount = NewMinCount;
					MaxCount = n;
					}
				m_HotWordCounts[m_HotCount] = n;
				m_HotSeeds[m_HotCount++] = SeedIndex;
				}
			}
		}

	PauseTimer(U_SetHotHits);
	SortDescending(m_HotWordCounts, m_HotCount, m_HotSortOrder);
	StartTimer(U_SetHotHits);

	AddCounter(HotHits, m_HotCount);
	EndTimer(U_SetHotHits);
	}

bool Ultra::Search(const char *Label, const byte *Seq, unsigned L, ON_HIT_FN OnHit,
  HitData &BestHit)
	{
	IncCounter(Search);

	SetCurrSeq(Label, Seq, L);

	unsigned MinWindexWordCount;
	unsigned Step;
	GetWordCountingParams(L, MinWindexWordCount, Step);

	CurrSeqToWords(Step);
	SetWordCounts();
	SetHotHits(MinWindexWordCount);

	m_PWA.SetQuery(m_CurrLabel, m_CurrSeq, m_CurrSeqLength);
	unsigned AcceptCount = 0;
	unsigned RejectCount = 0;

	HitData Hit;

	Hit.Global = true;

	Hit.QueryLabel = Label;
	Hit.QuerySeq = Seq;
	Hit.QueryLo = 0;
	Hit.QueryLength = L;

	Hit.SeedLo = 0;

	double BestFractId = 0.0;
	for (unsigned i = 0; i < m_HotCount; ++i)
		{
		unsigned SeedIndex = m_HotSeeds[m_HotSortOrder[i]];

		const char *SeedLabel = m_SeedLabels[SeedIndex];
		if (opt_self && strcmp(Label, SeedLabel) == 0)
			continue;

		const char *Path = AlignCurrToSeed(SeedIndex);
		double FractId = 0.0;
		if (Path != 0)
			FractId = GetFractIdGivenPath(m_CurrSeq, m_SeedSeqs[SeedIndex], Path);

		const byte *SeedSeq = m_SeedSeqs[SeedIndex];
		unsigned SeedLength = m_SeedLengths[SeedIndex];
		if (Path == 0 || FractId < m_MinFractId)
			{
			++RejectCount;

			if (opt_output_rejects)
				{
				Hit.SeedLabel = SeedLabel;
				Hit.SeedIndex = SeedIndex;
				Hit.SeedLabel = SeedLabel;
				Hit.SeedSeq = SeedSeq;
				Hit.SeedLength = SeedLength;

				Hit.Path = "?";
				Hit.FractId = 0;
				OnHitWrapper(OnHit, Hit);
				}

			if (opt_maxrejects > 0 && RejectCount >= opt_maxrejects)
				break;

			continue;
			}

		Hit.SeedIndex = SeedIndex;
		Hit.SeedLabel = SeedLabel;
		Hit.SeedSeq = SeedSeq;
		Hit.SeedLength = SeedLength;

		Hit.Path = Path;
		Hit.FractId = FractId;

#if	DEBUG
		{
		unsigned NA, NB;
		GetLetterCounts(Hit.Path, NA, NB);
		assert(Hit.QueryLo + NA <= Hit.QueryLength);
		assert(Hit.SeedLo + NB <= Hit.SeedLength);
		}
#endif

		if (opt_allhits)
			{
			bool Ok = OnHitWrapper(OnHit, Hit);
			if (!Ok)
				break;
			}

		if (FractId >= BestFractId)
			{
			BestFractId = FractId;
			BestHit = Hit;
			}

		++AcceptCount;
		if (opt_maxaccepts > 0 && AcceptCount >= opt_maxaccepts)
			break;
		}

	if (AcceptCount > 0 && !opt_allhits)
		OnHitWrapper(OnHit, BestHit);

	bool Found = (AcceptCount > 0);
	return Found;
	}

bool Ultra::OnHitWrapper(ON_HIT_FN OnHit, HitData &Hit)
	{
	if (OnHit == 0)
		return true;

	if (g_IsNucleo)
		Hit.Strand = '+';
	else
		Hit.Strand = '.';

	if (m_Rev)
		{
		if (g_IsNucleo && Hit.SeedIndex%2 == 1)
			Hit.Strand = '-';
		Hit.SeedIndex /= 2;
		}

	return OnHit(Hit);
	}

const char *Ultra::AlignCurrToSeed(unsigned SeedIndex)
	{
	IncCounter(AlignCurrToSeed);
	const char *SeedLabel = m_SeedLabels[SeedIndex];
	const byte *SeedSeq = m_SeedSeqs[SeedIndex];
	unsigned SeedLength = m_SeedLengths[SeedIndex];
	m_PWA.SetTarget(SeedLabel, SeedSeq, SeedLength);
	return m_PWA.Align(m_AP, m_AH);
	}

void Ultra::GetWordCountingParams(unsigned L, unsigned &MinWindexWordCount,
  unsigned &Step)
	{
	if (!opt_wordcountreject)
		{
		MinWindexWordCount = 0;
		Step = 1;
		return;
		}

	unsigned ThreshCount = GetMinWindexWordCount(L, m_MinFractId, m_Windex.m_WordLength);

	if (opt_stepwords == 0)
		{
		Step = 1;
		MinWindexWordCount = ThreshCount;
		}
	else
		{
		Step = ThreshCount/opt_stepwords;
		if (Step == 0)
			Step = 1;

		//MinWindexWordCount = 2*opt_stepwords;
		MinWindexWordCount = min(ThreshCount, opt_stepwords/2);
		}
	}

const byte *Ultra::GetSeedSeq(unsigned SeedIndex) const
	{
	if (m_Rev)
		{
		asserta(SeedIndex*2 < m_SeedCount);
		return m_SeedSeqs[SeedIndex*2];
		}
	else
		{
		asserta(SeedIndex < m_SeedCount);
		return m_SeedSeqs[SeedIndex];
		}
	}

unsigned Ultra::GetSeedLength(unsigned SeedIndex) const
	{
	if (m_Rev)
		{
		asserta(SeedIndex*2 < m_SeedCount);
		return m_SeedLengths[SeedIndex*2];
		}
	else
		{
		asserta(SeedIndex < m_SeedCount);
		return m_SeedLengths[SeedIndex];
		}
	}

const char *Ultra::GetSeedLabel(unsigned SeedIndex) const
	{
	if (m_Rev)
		{
		asserta(SeedIndex*2 < m_SeedCount);
		return m_SeedLabels[SeedIndex*2];
		}
	else
		{
		asserta(SeedIndex < m_SeedCount);
		return m_SeedLabels[SeedIndex];
		}
	}
