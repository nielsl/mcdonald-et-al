#ifndef seqdb_h
#define seqdb_h

#include <vector>
#include <map>

using namespace std;

struct SeqDB
	{
private:
	SeqDB(const SeqDB &rhs);
	SeqDB &operator=(const SeqDB &rhs);

public:
	string m_Name;
	vector<string> m_Labels;
	vector<byte *> m_Seqs;
	vector<unsigned> m_Lengths;
	map<string, unsigned> m_LabelToIndex;

	byte *m_Buffer;
	bool m_Aligned;
	unsigned m_BufferPos;
	unsigned m_BufferSize;

	SeqDB();
	~SeqDB();
	void Clear();

	bool IsNucleo() const;

	byte *GetSeq(unsigned SeqIndex) const
		{
		asserta(SeqIndex < SIZE(m_Seqs));
		return m_Seqs[SeqIndex];
		}

	const string &GetLabel(unsigned SeqIndex) const
		{
		asserta(SeqIndex < SIZE(m_Labels));
		return m_Labels[SeqIndex];
		}

	void SetLabel(unsigned SeqIndex, const string &Label)
		{
		asserta(SeqIndex < SIZE(m_Labels));
		m_Labels[SeqIndex] = Label;
		}

	unsigned GetSeqLength(unsigned SeqIndex) const
		{
		asserta(SeqIndex < SIZE(m_Lengths));
		return m_Lengths[SeqIndex];
		}

	unsigned GetSeqCount() const
		{
		return SIZE(m_Seqs);
		}

	unsigned GetPairCount() const
		{
		unsigned SeqCount = GetSeqCount();
		return (SeqCount*(SeqCount - 1))/2;
		}

	unsigned GetPairIndex(unsigned SeqIndex1, unsigned SeqIndex2) const
		{
		if (SeqIndex1 > SeqIndex2)
			return (SeqIndex1*(SeqIndex1 - 1))/2 + SeqIndex2;
		return (SeqIndex2*(SeqIndex2 - 1))/2 + SeqIndex1;
		}

	unsigned GetColCount() const
		{
		if (!m_Aligned)
			Die("SeqDB::GetColCount, not aligned");
		if (m_Lengths.empty())
			Die("SeqDB::GetColCount, empty");
		return m_Lengths[0];
		}

	unsigned GetSeqIndex(const string &Label, bool DieOnError = true) const;

	bool ColIsAligned(unsigned ColIndex, bool IgnoreCase = false) const;
	unsigned GetUngappedSeqLength(unsigned SeqIndex) const;
	void AddSeq(const string &Label, const byte *Seq, unsigned Length);
	unsigned GetMaxLabelLength() const;
	unsigned GetMaxSeqLength() const;
	void IndexLabels();
	unsigned GetIndex(const string &Label) const;

	void LogMe() const;
	void FromFasta(const string &FileName);
	void ToFasta(const string &FileName) const;
	void ToFasta(FILE *f, unsigned SeqIndex) const;
	void ToFasta(const string &FileName, const vector<bool> &Upper) const;
	void ToFasta(FILE *f, unsigned SeqIndex, const vector<bool> &Upper) const;
	};

#endif
