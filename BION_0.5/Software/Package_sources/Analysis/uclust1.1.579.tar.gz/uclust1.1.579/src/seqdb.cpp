#include "myutils.h"
#include "seqdb.h"
#include "timing.h"

bool isgap(char c)
	{
	return c == '-' || c == '.';
	}

const unsigned ROWLEN = 80;

SeqDB::~SeqDB()
	{
	Clear();
	}

SeqDB::SeqDB()
	{
	m_Name.clear();
	m_Labels.clear();
	m_Seqs.clear();
	m_Lengths.clear();
	m_Buffer = 0;
	m_BufferPos = 0;
	m_BufferSize = 0;
	}

void SeqDB::Clear()
	{
	m_Name.clear();
	m_Labels.clear();
	m_Seqs.clear();
	m_Lengths.clear();
	myfree(m_Buffer);
	m_Buffer = 0;
	m_BufferPos = 0;
	m_BufferSize = 0;
	}

void SeqDB::FromFasta(const string &FileName)
	{
	Clear();

	Progress("Reading %s\n", FileName.c_str());
	StartTimer(ReadAllStdioFile);

	off_t otFileSize;
	m_Buffer = ReadAllStdioFile(FileName, otFileSize);
	EndTimer(ReadAllStdioFile);

	unsigned FileSize = (unsigned) otFileSize;
	if ((off_t) FileSize != otFileSize)
		Die("SeqDB::FromFasta, off_t overflow");

	if (FileSize == 0)
		return;

	if (m_Buffer[0] != '>' && m_Buffer[0] != '<')
		Die("File '%s' is not FASTA or DFA format", FileName.c_str());
	bool DFA = (m_Buffer[0] == '<');

	Progress("Parsing sequence data\n");

	StartTimer(ScanFasta);
	enum
		{
		AtStart,
		InLabel,
		InSeq,
		} State = AtStart;

	vector<string> LongSeqLabels;
	vector<unsigned> LongSeqLengths;

	byte *Ptr = m_Buffer;
	char *Label = 0;
	unsigned SeqLength = 0;
	bool TruncatingLabel = false;
	string DLabel;
	for (unsigned i = 0; i < FileSize; ++i)
		{
		assert(Ptr <= m_Buffer + i);
		byte c = m_Buffer[i];
		bool eol = (c == '\n' || c == '\r');

		switch (State)
			{
		case AtStart:
			if (isspace(c))
				continue;
			else if (c == '>')
				goto StartLabel;
			else
				{
				if (isprint(c))
					Die("Invalid sequence data, expected '>' but got '%c'", c);
				else
					Die("Invalid sequence data, expected '>' but got non-printing byte 0x%02x", c);
				}
			continue;

		case InLabel:
			if (eol)
				{
				*Ptr++ = 0;
				goto StartSeq;
				}
			if (TruncatingLabel)
				continue;
			if (opt_trunclabels && isspace(c))
				{
				TruncatingLabel = true;
				continue;
				}
			if (c == '\t')
				c = ' ';
			*Ptr++ = c;
			continue;

		case InSeq:
			if (isspace(c))
				continue;
			else if (c == '>')
				goto StartLabel;
			else if (!isprint(c))
				Warning("non-printing byte 0x%02x ignored in sequence", c);
			else
				{
				*Ptr++ = c;
				++SeqLength;
				}
			continue;

		default:
			asserta(false);
			}

	StartLabel:
		{
		TruncatingLabel = false;
		assert(SIZE(m_Labels) == SIZE(m_Seqs));
		State = InLabel;
		if (!m_Labels.empty())
			{
			if (SeqLength == 0)
				Die("Empty sequence in '%.32s'", FileName.c_str());
			m_Lengths.push_back(SeqLength);
			}
		Label = (char *) (Ptr);
		continue;
		}

	StartSeq:
		m_Labels.push_back(Label);
		SeqLength = 0;
		State = InSeq;
		m_Seqs.push_back((byte *) Ptr);
		continue;
		}

	if (SeqLength == 0)
		Die("Empty sequence in '%.32s'", FileName.c_str());
	m_Lengths.push_back(SeqLength);
	asserta(Ptr <= m_Buffer + FileSize);

	const unsigned SeqCount = SIZE(m_Seqs);
	asserta(SIZE(m_Labels) == SeqCount);
	asserta(SIZE(m_Lengths) == SeqCount);

	EndTimer(ScanFasta);
	Progress("%s sequences\n", IntToStr(GetSeqCount()));
	}

void SeqDB::ToFasta(const string &FileName) const
	{
	FILE *f = CreateStdioFile(FileName);
	for (unsigned SeqIndex = 0; SeqIndex < GetSeqCount(); ++SeqIndex)
		ToFasta(f, SeqIndex);
	CloseStdioFile(f);
	}

void SeqDB::ToFasta(const string &FileName, const vector<bool> &Upper) const
	{
	FILE *f = CreateStdioFile(FileName);
	for (unsigned SeqIndex = 0; SeqIndex < GetSeqCount(); ++SeqIndex)
		ToFasta(f, SeqIndex, Upper);
	CloseStdioFile(f);
	}

void SeqDB::ToFasta(FILE *f, unsigned SeqIndex) const
	{
	asserta(SeqIndex < SIZE(m_Seqs));
	fprintf(f, ">%s\n", GetLabel(SeqIndex).c_str());
	unsigned L = GetSeqLength(SeqIndex);
	const byte *Seq = GetSeq(SeqIndex);
	unsigned BlockCount = (L + ROWLEN - 1)/ROWLEN;
	for (unsigned BlockIndex = 0; BlockIndex < BlockCount; ++BlockIndex)
		{
		unsigned From = BlockIndex*ROWLEN;
		unsigned To = From + ROWLEN;
		if (To >= L)
			To = L;
		for (unsigned Pos = From; Pos < To; ++Pos)
			fputc(Seq[Pos], f);
		fputc('\n', f);
		}
	}

void SeqDB::ToFasta(FILE *f, unsigned SeqIndex, const vector<bool> &Upper) const
	{
	unsigned L = GetSeqLength(SeqIndex);
	asserta(SIZE(Upper) == L);
	asserta(SeqIndex < SIZE(m_Seqs));
	fprintf(f, ">%s\n", GetLabel(SeqIndex).c_str());
	const byte *Seq = GetSeq(SeqIndex);
	unsigned BlockCount = (L + ROWLEN - 1)/ROWLEN;
	for (unsigned BlockIndex = 0; BlockIndex < BlockCount; ++BlockIndex)
		{
		unsigned From = BlockIndex*ROWLEN;
		unsigned To = From + ROWLEN;
		if (To >= L)
			To = L;
		for (unsigned Pos = From; Pos < To; ++Pos)
			fputc(Upper[Pos] ? toupper(Seq[Pos]) : tolower(Seq[Pos]), f);
		fputc('\n', f);
		}
	}

unsigned SeqDB::GetMaxLabelLength() const
	{
	const unsigned SeqCount = GetSeqCount();
	unsigned MaxL = 0;
	for (unsigned Index = 0; Index < SeqCount; ++Index)
		{
		unsigned L = SIZE(m_Labels[Index]);
		if (L > MaxL)
			MaxL = L;
		}
	return MaxL;
	}

unsigned SeqDB::GetMaxSeqLength() const
	{
	const unsigned SeqCount = GetSeqCount();
	unsigned MaxL = 0;
	for (unsigned Index = 0; Index < SeqCount; ++Index)
		{
		unsigned L = m_Lengths[Index];
		if (L > MaxL)
			MaxL = L;
		}
	return MaxL;
	}

void SeqDB::LogMe() const
	{
	Log("\n");
	const unsigned SeqCount = GetSeqCount();
	Log("SeqDB(%s), %u seqs, aligned=%c\n", m_Name.c_str(), SeqCount, tof(m_Aligned));
	if (SeqCount == 0)
		return;

	Log("Index             Label  Length  Seq\n");
	Log("-----  ----------------  ------  ---\n");
	for (unsigned Index = 0; Index < SeqCount; ++Index)
		{
		Log("%5u", Index);
		Log("  %16.16s", m_Labels[Index].c_str());
		unsigned L = m_Lengths[Index];
		Log("  %6u", L);
		Log("  %*.*s", L, L, m_Seqs[Index]);
		Log("\n");
		}
	}

unsigned SeqDB::GetSeqIndex(const string &Label, bool DieOnError) const
	{
	const unsigned SeqCount = GetSeqCount();
	for (unsigned i = 0; i < SeqCount; ++i)
		if (m_Labels[i] == Label)
			return i;
	if (DieOnError)
		Die("SeqDB::GetSeqIndex(%.16s), not found", Label.c_str());
	return UINT_MAX;
	}

bool SeqDB::ColIsAligned(unsigned ColIndex, bool IgnoreCase) const
	{
	unsigned AlignedLetterCount = 0;
	const unsigned SeqCount = GetSeqCount();
	for (unsigned SeqIndex = 0; SeqIndex < SeqCount; ++SeqIndex)
		{
		const byte *Seq = GetSeq(SeqIndex);
		byte c = Seq[ColIndex];
		if (isgap(c))
			continue;
		if (!IgnoreCase && islower(c))
			return false;
		++AlignedLetterCount;
		}
	return AlignedLetterCount > 1;
	}

unsigned SeqDB::GetUngappedSeqLength(unsigned SeqIndex) const
	{
	const byte *Seq = GetSeq(SeqIndex);
	const unsigned L = GetSeqLength(SeqIndex);
	unsigned n = 0;
	for (unsigned i = 0; i < L; ++i)
		{
		byte c = Seq[i];
		if (!isgap(c))
			++n;
		}
	return n;
	}

void SeqDB::AddSeq(const string &Label, const byte *Seq, unsigned Length)
	{
	m_Labels.push_back(Label);
	m_Lengths.push_back(Length);
	byte *s = myalloc<byte>(Length);
	memcpy(s, Seq, Length);
	m_Seqs.push_back(s);
	m_Aligned = (SIZE(m_Seqs) == 1 || Length == m_Lengths[0]);
	}

bool SeqDB::IsNucleo() const
	{
	const unsigned SeqCount = GetSeqCount();
	unsigned N = 0;
	for (unsigned i = 0; i < 100; ++i)
		{
		unsigned SeqIndex = unsigned(rand()%SeqCount);
		const byte *Seq = GetSeq(SeqIndex);
		unsigned L = GetSeqLength(SeqIndex);
		const unsigned Pos = unsigned(rand()%L);
		byte c = Seq[Pos];

		bool IsNucleoLetter(byte c);
		if (IsNucleoLetter(c))
			++N;
		}
	return N > 80;
	}

void SeqDB::IndexLabels()
	{
	m_LabelToIndex.clear();
	const unsigned SeqCount = GetSeqCount();
	for (unsigned Index = 0; Index < SeqCount; ++Index)
		{
		const string &Label = GetLabel(Index);
		if (m_LabelToIndex.find(Label) != m_LabelToIndex.end())
			Die("Dupe label '%s'", Label.c_str());
		m_LabelToIndex[Label] = Index;
		}
	}

unsigned SeqDB::GetIndex(const string &Label) const
	{
	if (m_LabelToIndex.empty())
		Die("SeqDB::GetIndex, labels not indexed");
	map<string, unsigned>::const_iterator p = m_LabelToIndex.find(Label);
	if (p == m_LabelToIndex.end())
		Die("Label not found (inconsistent use of --trunclabels?) '%s'", Label.c_str());
	return p->second;
	}
