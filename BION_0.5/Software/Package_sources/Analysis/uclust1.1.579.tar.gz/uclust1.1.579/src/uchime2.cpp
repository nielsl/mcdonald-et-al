#include "myutils.h"
#include "chime.h"
#include "seqdb.h"
#include "uc.h"

#define TRACE		0
#define TRACE_BS	0

void Make3Way(
  const string &LabQ, const byte *Q, unsigned QL,
  const string &LabA, const byte *A, unsigned AL, const string &PathA,
  const string &LabB, const byte *B, unsigned BL, const string &PathB,
  string &Q3, string &A3, string &B3);

#if	DEBUG
void GetLetterCounts(const string &Path, unsigned &NA, unsigned &NB);
#endif

static double ComputeHenrik(const ChimeHit2 &Hit)
	{
	double Henrik(unsigned y, unsigned n, double t);

	double Div = Hit.PctIdM/Hit.PctIdT;
	if (Div < 1.005)
		return 0;

	double HL = Henrik(Hit.LY, Hit.GetLTot() - Hit.LY, opt_mint);
	double HR = Henrik(Hit.RY, Hit.GetRTot() - Hit.RY, opt_mint);

	double PctIdP = max(Hit.PctIdA, Hit.PctIdB);
	double R = (101.0 - PctIdP)/(101.0 - Hit.PctIdM);
	double H = min(HL, HR)*R;
	return H;
	}

static bool isacgt(char c)
	{
	return c == 'A' || c == 'C' || c == 'G' || c == 'T';
	}

//void WriteChimeRec(const ChimeHit2 &Hit)
//	{
//	extern FILE *g_fReport;
//	if (g_fReport == 0)
//		return;
//
//	double PctIdP = max(Hit.PctIdA, Hit.PctIdB);
//	double Div = Hit.PctIdM == 0.0 ? 0.0 : Hit.PctIdM/PctIdP;
//	if (Div <= 1.002)
//		return;
//
//	FILE *f = g_fReport;
//
//	fprintf(f, "%.5f", Hit.H);
//	fprintf(f, "\t%.5f", Hit.Div);
//
//	fprintf(f, "\t%s", Hit.LabQ.c_str());
//	fprintf(f, "\t%s", Hit.LabA.c_str());
//	fprintf(f, "\t%s", Hit.LabB.c_str());
//
//	fprintf(f, "\t%u", Hit.LFor);
//	fprintf(f, "\t%u", Hit.LAgainst);
//	fprintf(f, "\t%u", Hit.LAbstain);
//
//	fprintf(f, "\t%u", Hit.RFor);
//	fprintf(f, "\t%u", Hit.RAgainst);
//	fprintf(f, "\t%u", Hit.RAbstain);
//
//	fprintf(f, "\t%.1f", Hit.PctIdA);
//	fprintf(f, "\t%.1f", Hit.PctIdB);
//	fprintf(f, "\t%.1f", Hit.PctIdM);
//	fprintf(f, "\t%.1f", Hit.PctIdAB);
//	fprintf(f, "\t%.1f", Hit.PctIdT);
//	fprintf(f, "\t%u", Hit.QL);
//
//	fprintf(f, "\n");
//	}

static bool BSRep(unsigned For, unsigned Against, unsigned Abstain)
	{
	unsigned N = For + Against + Abstain;
	if (N < 4)
		return false;
	unsigned Votes = unsigned(N/10.0 + 0.5);
	unsigned Ayes = 0;
	unsigned Nayes = 0;
	for (unsigned i = 0; i < Votes; ++i)
		{
		unsigned r = rand()%N;
		if (r < For)
			++Ayes;
		else if (r < For + Against)
			++Nayes;
		}
#if	TRACE_BS
	Log(" N %u Votes %u Ayes %u Nayes %u Abstains %u\n",
	  N, Votes, Ayes, Nayes, Votes - Ayes - Nayes);
#endif
	return Ayes > Nayes;
	}

static double GetBSPct(unsigned For, unsigned Against, unsigned Abstain)
	{
	//For += 1;
	//Against += 1;
	unsigned Ayes = 0;
	for (unsigned i = 0; i < 100; ++i)
		{
		bool Aye = BSRep(For, Against, Abstain);
#if	TRACE_BS
		Log("Vote %3u %s\n", i, Aye ? "Aye" : "Nay");
#endif
		if (Aye)
			++Ayes;
		}
	return double(Ayes);
	}

void UChime2_3(const string &LabQ, const string &Q3, const string &LabA, const string &A3,
  const string &LabB, const string &B3, unsigned QueryLength, double TopPctId, struct ChimeHit2 &Hit)
	{
#if	TRACE
	Log("\n");
	Log("UChime2_3\n");
	Log("Q3=%s\n", Q3.c_str());
	Log("A3=%s\n", A3.c_str());
	Log("B3=%s\n", B3.c_str());
#endif

	Hit.Clear();
	Hit.LabQ = LabQ;

	const unsigned ColCount = SIZE(Q3);
	asserta(SIZE(A3) == SIZE(Q3));
	asserta(SIZE(B3) == SIZE(Q3));

	unsigned QPos = 0;
	unsigned APos = 0;
	unsigned BPos = 0;
	unsigned DiffCount = 0;
	vector<unsigned> ColToQPos;
	vector<unsigned> AccumCount;
	vector<unsigned> AccumSameA;
	vector<unsigned> AccumSameB;
	vector<unsigned> AccumForA;
	vector<unsigned> AccumForB;
	vector<unsigned> AccumAbstain;
	vector<unsigned> AccumAgainst;
	unsigned SumSameA = 0;
	unsigned SumSameB = 0;
	unsigned SumSameAB = 0;
	unsigned Sum = 0;
	unsigned SumForA = 0;
	unsigned SumForB = 0;
	unsigned SumAbstain = 0;
	unsigned SumAgainst = 0;
	for (unsigned Col = 0; Col < ColCount; ++Col)
		{
		char q = Q3[Col];
		char a = A3[Col];
		char b = B3[Col];

		if (isacgt(q) && isacgt(a) && isacgt(b))
			{
			if (q == a)
				++SumSameA;
			if (q == b)
				++SumSameB;
			if (a == b)
				++SumSameAB;
			if (q == a && q != b)
				++SumForA;
			if (q == b && q != a)
				++SumForB;
			if (a == b && q != a)
				++SumAgainst;
			if (q != a && q != b && a != b)
				++SumAbstain;
			++Sum;
			}

		ColToQPos.push_back(QPos);
		AccumSameA.push_back(SumSameA);
		AccumSameB.push_back(SumSameB);
		AccumCount.push_back(Sum);
		AccumForA.push_back(SumForA);
		AccumForB.push_back(SumForB);
		AccumAbstain.push_back(SumAbstain);
		AccumAgainst.push_back(SumAgainst);

		if (q != '-')
			++QPos;
		if (a != '-')
			++APos;
		if (b != '-')
			++BPos;
		}

	asserta(SIZE(ColToQPos) == ColCount);
	asserta(SIZE(AccumSameA) == ColCount);
	asserta(SIZE(AccumSameB) == ColCount);
	asserta(SIZE(AccumAbstain) == ColCount);
	asserta(SIZE(AccumAgainst) == ColCount);

	double IdA = double(SumSameA)/Sum;
	double IdB = double(SumSameB)/Sum;
	double IdAB = double(SumSameAB)/Sum;
	double MaxId = max(IdA, IdB);

#if	TRACE
	Log("IdA=%.1f%% IdB=%.1f%% IdAB=%.1f\n", IdA*100.0, IdB*100.0, IdAB*100.0);
	Log("\n");
	Log("    x   IdAL   IdBL   IdAR   IdBR  DivAB  DivBA\n");
	Log("-----  -----  -----  -----  -----  -----  -----\n");
#endif
	unsigned BestXLo = UINT_MAX;
	unsigned BestXHi = UINT_MAX;
	double BestDiv = 0.0;
	double BestIdM = 0.0;
	bool FirstA = false;
	for (unsigned x = 1; x < ColCount-1; ++x)
		{
		unsigned SameAL = AccumSameA[x];
		unsigned SameBL = AccumSameB[x];
		unsigned SameAR = SumSameA - AccumSameA[x];
		unsigned SameBR = SumSameB - AccumSameB[x];

		double IdAB = double(SameAL + SameBR)/Sum;
		double IdBA = double(SameBL + SameAR)/Sum;

		double DivAB = IdAB/MaxId;
		double DivBA = IdBA/MaxId;
		double MaxDiv = max(DivAB, DivBA);
		if (MaxDiv > BestDiv)
			{
			BestDiv = MaxDiv;
			BestXLo = x;
			BestXHi = x;
			FirstA = (DivAB > DivBA);
			if (FirstA)
				BestIdM = IdAB;
			else
				BestIdM = IdBA;
			}
		else if (MaxDiv == BestDiv)
			BestXHi = x;

#if	TRACE
		Log("%5u", x);
		Log("  %5u", SameAL);
		Log("  %5u", SameBL);
		Log("  %5u", SameAR);
		Log("  %5u", SameBR);
		Log("  %5.3f", DivAB);
		Log("  %5.3f", DivBA);
		Log("\n");
#endif
		}

	unsigned BestX = (BestXHi + BestXLo)/2;
//	BestXHi = BestX;
//	BestXLo = BestX;//@@@

	QPos = 0;
	for (unsigned x = 0; x < ColCount; ++x)
		{
		if (x == BestXLo)
			Hit.QXLo = QPos;
		else if (x == BestXHi)
			{
			Hit.QXHi = QPos;
			break;
			}
		char q = Q3[x];
		if (q != '-')
			++QPos;
		}

	if (FirstA)
		{
		Hit.LY = AccumForA[BestXLo];
		Hit.LN = AccumForB[BestXLo];

		Hit.RY = SumForB - AccumForB[BestXHi];
		Hit.RN = SumForA - AccumForA[BestXHi];
		}
	else
		{
		Hit.LY = AccumForB[BestXLo];
		Hit.LN = AccumForA[BestXLo];
		Hit.RY = SumForA - AccumForA[BestXHi];
		Hit.RN = SumForB - AccumForB[BestXHi];
		}

	Hit.LA = AccumAgainst[BestXLo];
	Hit.LD = AccumAbstain[BestXLo];

	Hit.RA = SumAgainst - AccumAgainst[BestXHi];
	Hit.RD = SumAbstain - AccumAbstain[BestXHi];

	Hit.PctIdAB = IdAB*100.0;
	Hit.PctIdM = BestIdM*100.0;

	Hit.Div = BestDiv;
	Hit.PctIdT = TopPctId;
	Hit.QL = QueryLength;

	if (FirstA)
		{
		Hit.LabA = LabA;
		Hit.LabB = LabB;
		Hit.PctIdA = IdA*100.0;
		Hit.PctIdB = IdB*100.0;
		}
	else
		{
		Hit.LabA = LabB;
		Hit.LabB = LabA;
		Hit.PctIdA = IdB*100.0;
		Hit.PctIdB = IdA*100.0;
		}

	Hit.H = ComputeHenrik(Hit);
//	WriteChimeRec(Hit);
	}

void UChime2(
  const string &LabQ, const byte *Q, unsigned QL,
  const string &LabA, const byte *A, unsigned AL, const string &PathA,
  const string &LabB, const byte *B, unsigned BL, const string &PathB,
  double TopPctId, struct ChimeHit2 &Hit)
	{
#if	TRACE
	Log("\n");
	Log("UChime2\n");
	Log("Q=%s\n", LabQ.c_str());
	Log("A=%s\n", LabA.c_str());
	Log("B=%s\n", LabB.c_str());
#endif

	string Q3;
	string A3;
	string B3;
	Make3Way(LabQ, Q, QL, LabA, A, AL, PathA, LabB, B, BL, PathB, Q3, A3, B3);
	UChime2_3(LabQ, Q3, LabA, A3, LabB, B3, QL, TopPctId, Hit);
	}
