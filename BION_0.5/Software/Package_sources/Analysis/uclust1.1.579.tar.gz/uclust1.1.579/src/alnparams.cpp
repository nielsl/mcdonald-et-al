#include "myutils.h"
#include "mx.h"
#include "pwa.h"	// for SegPair
#include <float.h>

/***
SE-B(6) compressed alphabet:
	AST, CP, DEHKNQR, FWY, G, ILMV

From NAR (2004) 32(1) p380-85.
***/

void SetBLOSUM62();
void SetBLOSUM70C();
void SetNucSubstMx(double Match, double Mismatch);
// void InitShortWords(unsigned WordLength, unsigned AlphaSize);

// Values chosen to make obviously wrong results,
// must be overwritten by amino/nucleo value..
float g_GapOpen = 999;
float g_TermGapOpen = 999;
float g_TermGapExt = 999;
float g_GapExt = 999;

static const char AlphaNuc[] = "ACGT"; // U is mapped to T below
static const char AlphaAmino[] = "ACEDGFIHKMLNQPSRTWVY";
static byte g_CompChar[256];

const char *g_Alpha;
unsigned g_AlphaSize;

//TODO bad letters
unsigned CharToLetter[256];
const unsigned BadLetter = UINT_MAX;

static bool IsNuc[256];

static bool InitIsNuc()
	{
	IsNuc[byte('A')] = true;
	IsNuc[byte('C')] = true;
	IsNuc[byte('G')] = true;
	IsNuc[byte('T')] = true;
	IsNuc[byte('U')] = true;
	IsNuc[byte('N')] = true;

	IsNuc[byte('a')] = true;
	IsNuc[byte('c')] = true;
	IsNuc[byte('g')] = true;
	IsNuc[byte('t')] = true;
	IsNuc[byte('u')] = true;
	IsNuc[byte('n')] = true;
	return true;
	}
static bool IsNucDone = InitIsNuc();

bool IsNucleoLetter(byte c)
	{
	return IsNuc[c];
	}

static void InitCharToLetterAmino()
	{
	g_Alpha = AlphaAmino;

	g_AlphaSize = (unsigned) strlen(g_Alpha);
	for (unsigned i = 0; i < g_AlphaSize; ++i)
		{
		char c = g_Alpha[i];
		CharToLetter[tolower(c)] = i;
		CharToLetter[toupper(c)] = i;
		}
	}

static void InitCharToLetterNuc()
	{
	static bool Done = false;
	if (Done)
		return;
	Done = true;

	g_Alpha = AlphaNuc;

	g_AlphaSize = (unsigned) strlen(g_Alpha);
	for (unsigned i = 0; i < g_AlphaSize; ++i)
		{
		char c = g_Alpha[i];
		CharToLetter[tolower(c)] = i;
		CharToLetter[toupper(c)] = i;
		if (c == 'T')
			{
			CharToLetter['U'] = i;
			CharToLetter['u'] = i;
			}
		}

	for (unsigned i = 0; i < 256; ++i)
		g_CompChar[i] = i;

#define c(x,y)	\
	g_CompChar[(byte) toupper(x)] = (byte) toupper(y);	\
	g_CompChar[(byte) tolower(x)] = (byte) tolower(y);	\
	g_CompChar[(byte) toupper(y)] = (byte) toupper(x);	\
	g_CompChar[(byte) tolower(y)] = (byte) tolower(x);

	c('A', 'U')
	c('A', 'T')
	c('C', 'G')
	c('N', 'N')
#undef c
	}

const char *WordToStr(unsigned Word, unsigned WordLength)
	{
	extern const char *g_Alpha;
	extern unsigned g_AlphaSize;

	static char Str[32];
	for (unsigned i = 0; i < WordLength; ++i)
		{
		unsigned w = Word%g_AlphaSize;
		Str[WordLength-i-1] = g_Alpha[w];
		Word /= g_AlphaSize;
		}
	Str[WordLength] = 0;
	return Str;
	}

const byte *RevComp(const byte *Seq, unsigned L)
	{
	static byte *RCSeq = 0;
	static unsigned RCSeqL = 0;
	if (RCSeqL < L)
		{
		RCSeqL = L + 512;
		RCSeq = myalloc<byte>(RCSeqL);
		}

	for (unsigned i = 0; i < L; ++i)
		RCSeq[L-i-1] = g_CompChar[Seq[i]];

	return RCSeq;
	}

void RevComp(const byte *Seq, unsigned L, byte *RCSeq)
	{
	for (unsigned i = 0; i < L; ++i)
		RCSeq[L-i-1] = g_CompChar[Seq[i]];
	}

void AlnParams::Clear()
	{
	OpenA = OBVIOUSLY_WRONG_PENALTY;
	OpenB = OBVIOUSLY_WRONG_PENALTY;
	ExtA = OBVIOUSLY_WRONG_PENALTY;
	ExtB = OBVIOUSLY_WRONG_PENALTY;
	LOpenA = OBVIOUSLY_WRONG_PENALTY;
	LOpenB = OBVIOUSLY_WRONG_PENALTY;
	ROpenA = OBVIOUSLY_WRONG_PENALTY;
	ROpenB = OBVIOUSLY_WRONG_PENALTY;
	LExtA = OBVIOUSLY_WRONG_PENALTY;
	LExtB = OBVIOUSLY_WRONG_PENALTY;
	RExtA = OBVIOUSLY_WRONG_PENALTY;
	RExtB = OBVIOUSLY_WRONG_PENALTY;
	}

bool AlnParams::Is2() const
	{
	float g = OpenA;
	float e = ExtA;
	if (OpenB != g || LOpenA != g || LOpenB != g || ROpenA != g || ROpenB != g)
		return false;
	if (ExtB != e || LExtA != e || LExtB != e || RExtA != e || RExtB != e)
		return false;
	return true;
	}

bool AlnParams::Is4() const
	{
	float g = OpenA;
	float tg = LOpenA;
	float e = ExtA;
	float te = LExtA;
	if (OpenB != g || LOpenA != tg || LOpenB != tg || ROpenA != tg || ROpenB != tg)
		return false;
	if (ExtB != e || LExtA != te || LExtB != te || RExtA != te || RExtB != te)
		return false;
	return true;
	}

const char *AlnParams::GetType() const
	{
	if (Is2())
		return "2";
	else if (Is4())
		return "4";
	return "12";
	}

void AlnParams::Init2(const float * const *Mx, float Open, float Ext)
	{
	SubstMx = Mx;
	OpenA = OpenB = LOpenA = LOpenB = ROpenA = ROpenB = Open;
	ExtA = ExtB = LExtA = LExtB = RExtA = RExtB = Ext;
	}

void AlnParams::Init4(const float * const *Mx, float Open, float Ext,
  float TermOpen, float TermExt)
	{
	SubstMx = Mx;
	OpenA = OpenB = Open;
	LOpenA = LOpenB = ROpenA = ROpenB = TermOpen;
	ExtA = ExtB = Ext;
	LExtA = LExtB = RExtA = RExtB = TermExt;
	}

void AlnParams::Init(const AlnParams &AP, const SegPair &SP)
	{
	SubstMx = AP.SubstMx;
	OpenA = AP.OpenA;
	OpenB = AP.OpenB;
	ExtA = AP.ExtA;
	ExtB = AP.ExtB;

	if (SP.LeftA())
		{
		LOpenA = AP.LOpenA;
		LExtA = AP.LExtA;
		}
	else
		{
		LOpenA = AP.OpenA;
		LExtA = AP.ExtA;
		}

	if (SP.LeftB())
		{
		LOpenB = AP.LOpenB;
		LExtB = AP.LExtB;
		}
	else
		{
		LOpenB = AP.OpenB;
		LExtB = AP.ExtB;
		}

	if (SP.RightA())
		{
		ROpenA = AP.ROpenA;
		RExtA = AP.RExtA;
		}
	else
		{
		ROpenA = AP.OpenA;
		RExtA = AP.ExtA;
		}

	if (SP.RightB())
		{
		ROpenB = AP.ROpenB;
		RExtB = AP.RExtB;
		}
	else
		{
		ROpenB = AP.OpenB;
		RExtB = AP.ExtB;
		}
	}

void AlnParams::LogMe() const
	{
	Log("AlnParams(%s)", GetType());
	if (Is2())
		Log(" g=%.1f e=%.1f", -OpenA, -ExtA);
	else if (Is4())
		Log(" g=%.1f tg=%.1f e=%.1f te=%.1f", -OpenA, -ExtA, -LOpenA, -LExtA);
	else
		Log(
" gA=%.1f gB=%.1f gAL=%.1f gBL=%.1f gAR=%.1f gBR=%.1f eA=%.1f eB=%.1f eAL=%.1f eBL=%.1f eAR=%.1f eBR=%.1f",
		  OpenA, OpenB, LOpenA, LOpenB, ROpenA, ROpenB, ExtA, ExtB, LExtA, LExtB, RExtA, RExtB);
	Log("\n");
	}

/***
Open/Ext format string is one or more:
	[<flag><flag>...]<value>

Value is (positive) penalty or * (disabled).
Flag is:
	Q		Query.
	T		Target sequence.
	I		Internal gaps (defafault internal and terminal).
	E		End gaps (default internal and terminal).
	L		Left end.
	R		Right end.
***/

static void ParseGapStr(const string &s,
  float &QI, float &QL, float &QR,
  float &TI, float &TL, float &TR)
	{
	if (s.empty())
		return;

	bool Q = false;
	bool T = false;
	bool I = false;
	bool E = false;
	bool L = false;
	bool R = false;

	const unsigned K = SIZE(s);
	unsigned Dec = 0;
	float Value = FLT_MAX;
	for (unsigned i = 0; i <= K; ++i)
		{
		char c = s.c_str()[i];
		if (c == 0 || c == '/')
			{
			if (Value == FLT_MAX)
				Die("Invalid gap penalty string, missing penalty '%s'", s.c_str());
			if (!Q && !T && !I && !E && !L && !R)
				{
				Q = true;
				T = true;
				L = true;
				R = true;
				I = true;
				}

			if (!E && !I && !L && !R)
				{
				E = false;
				I = true;
				L = true;
				R = true;
				}

			if (E)
				{
				if (L || R)
					Die("Invalid gap penalty string (E and L or R) '%s'", s.c_str());
				L = true;
				R = true;
				}

			if (!Q && !T)
				{
				Q = true;
				T = true;
				}

			if (Q && L)
				QL = -Value;
			if (Q && R)
				QR = -Value;
			if (Q && I)
				QI = -Value;
			if (T && L)
				TL = -Value;
			if (T && R)
				TR = -Value;
			if (T && I)
				TI = -Value;
			
			Value = FLT_MAX;
			Dec = 0;
			Q = false;
			T = false;
			I = false;
			E = false;
			L = false;
			R = false;
			}
		else if (c == '*')
			{
			if (Value != FLT_MAX)
				Die("Invalid gap penalty (* in floating point number) '%s'", s.c_str());
			Value = -MINUS_INFINITY;
			}
		else if (isdigit(c))
			{
			if (Value == -MINUS_INFINITY)
				Die("Invalid gap penalty (* in floating point number) '%s'", s.c_str());
			if (Value == FLT_MAX)
				Value = 0.0;
			if (Dec > 0)
				{
				Dec *= 10;
				Value += float(c - '0')/Dec;
				}
			else
				Value = Value*10 + (c - '0');
			}
		else if (c == '.')
			{
			if (Dec > 0)
				Die("Invalid gap penalty (two decimal points) '%s'", s.c_str());
			Dec = 1;
			}
		else
			{
			switch (c)
				{
			case 'Q':
				Q = true;
				break;
			case 'T':
				T = true;
				break;
			case 'I':
				I = true;
				break;
			case 'L':
				L = true;
				break;
			case 'R':
				R = true;
				break;
			case 'E':
				E = true;
				break;
			default:
				Die("Invalid char '%c' in gap penalty string '%s'", c, s.c_str());
				}
			}
		}

	//if (QL == FLT_MAX)
	//	Die("Invalid gap penalty string, QL not specified '%s'", s.c_str());
	//if (QR == FLT_MAX)
	//	Die("Invalid gap penalty string, QR not specified '%s'", s.c_str());
	//if (QI == FLT_MAX)
	//	Die("Invalid gap penalty string, QI not specified '%s'", s.c_str());
	//if (TL == FLT_MAX)
	//	Die("Invalid gap penalty string, TL not specified '%s'", s.c_str());
	//if (TR == FLT_MAX)
	//	Die("Invalid gap penalty string, TR not specified '%s'", s.c_str());
	//if (TI == FLT_MAX)
	//	Die("Invalid gap penalty string, TI not specified '%s'", s.c_str());
	}

void AlnParams::SetPenalties(const string &OpenStr, const string &ExtStr)
	{
	ParseGapStr(OpenStr, OpenA, LOpenA, ROpenA, OpenB, LOpenB, ROpenB);
	ParseGapStr(ExtStr, ExtA, LExtA, RExtA, ExtB, LExtB, RExtB);
	}

void AlnParams::InitFromCmdLine(bool IsNucleo)
	{
	if (IsNucleo)
		{
		InitCharToLetterNuc();
		SetNucSubstMx(opt_match, opt_mismatch);

		Init4(g_SubstMx, -10.0, -1.0, -0.5, -0.5);
		}
	else
		{
		InitCharToLetterAmino();
		SetBLOSUM62();

		Init4(g_SubstMx, -17.0, -1.0, -0.5, -0.5);
		}

	asserta(SubstMx != 0);

	SetPenalties(opt_gapopen, opt_gapext);
	}

static void Test1(const string &os, const string &es)
	{
	AlnParams AP;
	Log("\n");
	Log("OpenStr %s\n", os.c_str());
	Log(" ExtStr %s\n", es.c_str());
	AP.SetPenalties(os, es);
	AP.LogMe();
	}

void TestGapStr()
	{
	Test1("17I/0.5E", "1I/0.5E");
	Test1("17I/0.5L/0.4R", "1Q/2T");
	Test1("1QL/2QR/3QI/4TL/5TR/6TI", ".1QL/.2QR/.3QI/.4TL/.5TR/.6TI");
	}
