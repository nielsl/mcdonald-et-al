#include "myutils.h"
#include "chime.h"
#include "seqdb.h"
#include "sfasta.h"
#include "ultra.h"
#include <algorithm>
#include <set>

//void Uchime1(const UCFile &UC, const SeqDB &Input, const SeqDB &Lib,
//  const vector<unsigned> &RecIndexes, ChimeHit2 &Hit);
//bool ParseBrianLabel(const string &Label, unsigned &L, unsigned &D,
//  string &Parent1, string &Parent2);

void SetOpts();
bool SearchChime(Ultra &U, PWA &pwa, const AlnParams &AP, const AlnHeuristics &AH,
  const char *QueryLabel, const byte *QuerySeq,
  unsigned QueryLength, ChimeHit2 &Hit);

extern bool g_IsNucleo;

FILE *g_fChunks;
FILE *g_f3;
FILE *g_fReportx;

static FILE *g_fReport;

//static vector<ChimeHit2> g_Hits;
//static unsigned g_FP;
//static unsigned g_TP;
//static unsigned g_FN;
//static unsigned g_TN;
//static vector<unsigned> g_TPs;
//static set<string> g_Labels;

static void LogChimeHit(const ChimeHit2 &Hit)
	{
	char leftvotes[64];
	char rightvotes[64];
	sprintf(leftvotes, "A%u/b%u/N%u/?%u", Hit.LY, Hit.LN, Hit.LA, Hit.LD);
	sprintf(rightvotes, "B%u/a%u/N%u/?%u", Hit.RY, Hit.RN, Hit.RA, Hit.RD);

	double PctIdP = max(Hit.PctIdA, Hit.PctIdB);
	double Div = Hit.PctIdM == 0.0 ? 0.0 : Hit.PctIdM/PctIdP;
//	double DivT = Hit.PctIdM == 0.0 ? 0.0 : Hit.PctIdM/Hit.PctIdT;

	fprintf(g_fReport, "%c", Hit.Accept() ? 'Y' : 'n');
	fprintf(g_fReport, "  %8.3f", Hit.H);
	fprintf(g_fReport, "  %7.3f", Div);
	fprintf(g_fReport, "  %12.12s", leftvotes);
	fprintf(g_fReport, "  %12.12s", rightvotes);
	fprintf(g_fReport, "  %5.1f%%", PctIdP);
	fprintf(g_fReport, "  %5.1f%%", Hit.PctIdT);
	fprintf(g_fReport, "  %5.1f%%", Hit.PctIdAB);
	fprintf(g_fReport, "  %5.1f%%", Hit.PctIdM);
	fprintf(g_fReport, "  %s", Hit.LabQ.c_str());

	fprintf(g_fReport, " (");
	if (!Hit.LabT.empty() && Hit.LabA == Hit.LabT)
		fprintf(g_fReport, "+");
	fprintf(g_fReport, "%s", Hit.LabA.c_str());

	fprintf(g_fReport, ",");
	if (!Hit.LabT.empty() && Hit.LabB == Hit.LabT)
		fprintf(g_fReport, "+");
	fprintf(g_fReport, "%s", Hit.LabB.c_str());
	if (!Hit.LabT.empty() && Hit.LabA != Hit.LabT && Hit.LabB != Hit.LabT)
		fprintf(g_fReport, ",+%s", Hit.LabT.c_str());
	fprintf(g_fReport, ")");

	fprintf(g_fReport, "\n");
	}

//void AddChimeHit(const ChimeHit2 &Hit)
//	{
//	if (Hit.Div <= 0.0)
//		return;
//	asserta(Hit.H <= 1.0 && Hit.H >= 0);
//
//	if (opt_brian_ch || opt_brian_ctl)
//		{
//		if (g_Labels.find(Hit.LabQ) != g_Labels.end())
//			Die("Dupe label %s", Hit.LabQ.c_str());
//		g_Labels.insert(Hit.LabQ);
//		}
//
//	if (opt_brian_ch)
//		{
//		if (g_TPs.empty())
//			g_TPs.resize(25, 0);
//		
//		unsigned D, L;
//		string P1, P2;
//		bool Ok = ParseBrianLabel(Hit.LabQ, L, D, P1, P2);
//		asserta(Ok);
//		asserta(D <= 25);
//		if (Hit.Accept())
//			{
//			g_TPs[D-1] += 1;
//			g_TP += 1;
//			}
//		else
//			g_FN += 1;
//		}
//	else if (opt_brian_ctl)
//		{
//		if (Hit.Accept())
//			g_FP += 1;
//		else
//			g_TN += 1;
//		}
//
//	g_Hits.push_back(Hit);
//	}

void LogChimeHits(const vector<ChimeHit2> &Hits)
	{
	if (g_fReport == 0)
		return;

	fprintf(g_fReport, ">         H      Div  L.SNPs y/n/?  R.SNPs y/n/?     IdP     IdT    IdAB     IdM  Labels\n");
	fprintf(g_fReport, "-  --------  -------  ------------  ------------  ------  ------  ------  ------  ------\n");

	unsigned YCount = 0;
	unsigned NCount = 0;
	const unsigned N = SIZE(Hits);
	for (unsigned i = 0; i < N; ++i)
		{
		const ChimeHit2 &Hit = Hits[i];
		if (Hit.Accept())
			++YCount;
		else
			++NCount;
		LogChimeHit(Hit);
		}

	//if (opt_brian_ch)
	//	{
	//	Log("\n");
	//	Log(" D     TP     Sens\n");
	//	Log("--  -----  -------\n");
	//	for (unsigned D = 1; D <= 25; ++D)
	//		{
	//		unsigned TP = g_TPs[D-1];
	//		double Sens = double(TP);
	//		Log("%2u  %5u  %6.1f%%\n", D, TP, Sens);
	//		}
	//	double Sens = 100.0*double(g_TP)/2500.0;
	//	Log("TP=%u FN=%u Sens %.1f%%\n", g_TP, g_FN, Sens);
	//	}
	//else if (opt_brian_ctl)
	//	{
	//	Log("\n");
	//	double Err = 100.0*double(g_FP)/2500.0;
	//	Log("TN=%u FP=%u Err %.1f%%\n", g_TN, g_FP, Err);
	//	}
	if (YCount == 0 && NCount == 0)
		return;
	Log("\n");
	Log("@UCHIME;");
	Log("Input=%s;", opt_uchime.c_str());
	Log("Ref=%s;", opt_lib.c_str());
	Log("N=%u;", YCount+NCount);
	Log("Hits=%u;", YCount);
	Log("Pct=%.1f%%", double(YCount*100.0)/(YCount+NCount));
	Log("\n");
	}

//void LogChimeHits()
//	{
//	sort(g_Hits.begin(), g_Hits.end());
//	LogChimeHits(g_Hits);
//	}

void UChime()
	{
	opt_fastalign = false;//@@TODO
	opt_fastalign_chime = false;//@@TODO
	opt_id = 0.7;//@@TODO
	if (opt_lib == "")
		opt_self = true;//@@TODO

	if (opt_uchime == "")
		Die("Missing --uchime");

	//if (optset_uc)
	//	g_UC.Create(opt_uc);

	if (opt_report != "")
		g_fReport = CreateStdioFile(opt_report);

	if (opt_reportx != "")
		g_fReportx = CreateStdioFile(opt_reportx);

	if (opt_savechunks != "")
		g_fChunks = CreateStdioFile(opt_savechunks);

	if (opt_threeway != "")
		g_f3 = CreateStdioFile(opt_threeway);

	SFasta SF;
	SF.Open(opt_uchime);
	g_IsNucleo = true;

	SetOpts();

	Ultra U;
	AlnParams AP;
	AP.InitFromCmdLine(g_IsNucleo);
	AlnHeuristics AH;
	AH.InitFromCmdLine();
	U.Init(opt_id, opt_w, opt_k, AP, AH);

	PWA pwa;
	pwa.Init(opt_k);

	AlnParams AP2;
	AP2.InitFromCmdLine(g_IsNucleo);

	AlnHeuristics AH2;
	AH2.InitExact();

	SFasta Lib;
	const string &LibFileName = (opt_lib != "" ? opt_lib : opt_uchime);
	Lib.Open(LibFileName);
	unsigned LibSeedCount = 0;
	const unsigned Scale = 1000000;
	ProgressStep(0, Scale, "Reading %.32s, %u seeds", LibFileName.c_str(), LibSeedCount);
	for (;;)
		{
		const byte *Seq = Lib.GetNextSeq();
		if (Seq == 0)
			break;

		double PctDone = Lib.GetPctDone();
		unsigned Counter = unsigned((PctDone*Scale)/100.0);
		if (Counter == 0)
			Counter = 1;
		if (Counter >= Scale-1)
			Counter = Scale-2;

		const char *Label = Lib.GetLabel();
		unsigned L = Lib.GetSeqLength();
		unsigned SeedIndex = U.AddSeed(Label, Seq, L);
		++LibSeedCount;
		ProgressStep(Counter, Scale, "Reading lib, %u seeds", LibSeedCount);
		}
	ProgressStep(Scale-1, Scale, "Reading %.32s, %u seeds",
	  LibFileName.c_str(), LibSeedCount);
	Lib.Clear();

	ProgressStep(0, Scale, "");
	unsigned MinLenCount = 0;
	unsigned MaxLenCount = 0;
//	vector<float> TotalFractId(LibSeedCount, 0);
	unsigned HitCount = 0;
	unsigned SeqCount = 0;
	vector<ChimeHit2> Hits;
	for (;;)
		{
		const byte *Seq = SF.GetNextSeq();
		if (Seq == 0)
			break;

		double PctDone = SF.GetPctDone();
		unsigned Counter = unsigned((PctDone*Scale)/100.0);
		if (Counter == 0)
			Counter = 1;
		if (Counter >= Scale-1)
			Counter = Scale-2;
		
		double p = Pct(HitCount, SeqCount);
		ProgressStep(Counter, Scale, "Chimera search %s, %u found (%.1f%%)",
		  opt_uchime.c_str(), HitCount, p);

		const char *Label = SF.GetLabel();
		unsigned L = SF.GetSeqLength();
		if (L < opt_minlen)
			{
			++MinLenCount;
			continue;
			}
		else if (L > opt_maxlen && opt_maxlen > 0)
			{
			++MaxLenCount;
			continue;
			}
		++SeqCount;
		ChimeHit2 Hit;
		SearchChime(U, pwa, AP2, AH2, Label, Seq, L, Hit);
		Hit.LabQ = Label;
		Hits.push_back(Hit);
		Hit.LogMe();
		if (Hit.Accept())
			++HitCount;
		}

	double p = Pct(HitCount, SeqCount);
	ProgressStep(Scale-1, Scale, "Chimera search %s, %u found (%.1f%%)",
	  opt_uchime.c_str(), HitCount, p);

	sort(Hits.begin(), Hits.end());
	LogChimeHits(Hits);

	U.Clear();

	//if (optset_uc)
	//	g_UC.Clear();

	if (g_fChunks != 0)
		CloseStdioFile(g_fChunks);

	if (g_fReport != 0)
		CloseStdioFile(g_fReport);

	if (g_fReportx != 0)
		CloseStdioFile(g_fReportx);

	if (g_f3 != 0)
		CloseStdioFile(g_f3);
	}
