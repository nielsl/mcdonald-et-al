#include "myutils.h"
#include "seqdb.h"
#include "timing.h"
#include <algorithm>

const vector<unsigned> *g_SortVec;
const unsigned *g_SortPtr;

void Range(vector<unsigned> &v, unsigned N)
	{
	v.clear();
	v.reserve(N);
	for (unsigned i = 0; i < N; ++i)
		v.push_back(i);
	}

void Range(unsigned *v, unsigned N)
	{
	for (unsigned i = 0; i < N; ++i)
		v[i] = i;
	}

static bool CmpAscVec(unsigned i, unsigned j)
	{
	return (*g_SortVec)[i] < (*g_SortVec)[j];
	}

static bool CmpAscPtr(unsigned i, unsigned j)
	{
	return g_SortPtr[i] < g_SortPtr[j];
	}

static bool CmpDescVec(unsigned i, unsigned j)
	{
	return (*g_SortVec)[i] > (*g_SortVec)[j];
	}

static bool CmpDescPtr(unsigned i, unsigned j)
	{
	return g_SortPtr[i] > g_SortPtr[j];
	}

void SortAscending(const vector<unsigned> &Values, vector<unsigned> &Order)
	{
	StartTimer(Sort);
	const unsigned N = SIZE(Values);
	Range(Order, N);
	g_SortVec = &Values;
	sort(Order.begin(), Order.end(), CmpAscVec);
	EndTimer(Sort);
	}

void SortAscending(const unsigned *Values, unsigned N, vector<unsigned> &Order)
	{
	StartTimer(Sort);
	Range(Order, N);
	g_SortPtr = Values;
	sort(Order.begin(), Order.end(), CmpAscPtr);
	EndTimer(Sort);
	}

void SortDescending(const vector<unsigned> &Values, vector<unsigned> &Order)
	{
	StartTimer(Sort);
	const unsigned N = SIZE(Values);
	Range(Order, N);
	g_SortVec = &Values;
	sort(Order.begin(), Order.end(), CmpDescVec);
	EndTimer(Sort);
	}

void SortDescending(const unsigned *Values, unsigned N, unsigned *Order)
	{
	StartTimer(Sort);
	Range(Order, N);
	g_SortPtr = Values;
	sort(Order, Order + N, CmpDescPtr);
	EndTimer(Sort);
	}

void SortDescending(const unsigned *Values, unsigned N, vector<unsigned> &Order)
	{
	StartTimer(Sort);
	Range(Order, N);
	g_SortPtr = Values;
	sort(Order.begin(), Order.end(), CmpDescPtr);
	EndTimer(Sort);
	}

void SortByLength()
	{
	if (opt_sort == "")
		Die("Missing --sort");
	if (opt_output == "")
		Die("Missing --output");

	SeqDB Input;
	Input.FromFasta(opt_sort);
	const unsigned SeqCount = Input.GetSeqCount();

	Progress("Sorting by length\n");
	vector<unsigned> SeqIndexes;
	SortDescending(Input.m_Lengths, SeqIndexes);

	unsigned FirstSeqIndex = SeqIndexes[0];
	unsigned MidSeqIndex = SeqIndexes[SeqCount/2];
	unsigned LastSeqIndex = SeqIndexes[SeqCount-1];
	unsigned MinSeqLength = Input.GetSeqLength(LastSeqIndex);
	unsigned MaxSeqLength = Input.GetSeqLength(FirstSeqIndex);
	unsigned MedianSeqLength = Input.GetSeqLength(MidSeqIndex);
	Progress("Length min %u, median %u, max %u\n",
	  MinSeqLength, MedianSeqLength, MaxSeqLength);
	Log("Length min %u, median %u, max %u\n",
	  MinSeqLength, MedianSeqLength, MaxSeqLength);

	FILE *fOut = CreateStdioFile(opt_output);
	for (unsigned i = 0; i < SeqCount; ++i)
		{
		ProgressStep(i, SeqCount, "Writing output");
		unsigned SeqIndex = SeqIndexes[i];
		Input.ToFasta(fOut, SeqIndex);
		}
	Progress("Write done, closing file and exiting\n");
	CloseStdioFile(fOut);
	}

void SortByLength(const string &InputFileName, const string &OutputFileName)
	{
	SeqDB Input;
	Input.FromFasta(InputFileName);
	const unsigned SeqCount = Input.GetSeqCount();

	Progress("Sorting %s\n", InputFileName.c_str());

	vector<unsigned> SeqIndexes;
	SortDescending(Input.m_Lengths, SeqIndexes);

	unsigned FirstSeqIndex = SeqIndexes[0];
	unsigned MidSeqIndex = SeqIndexes[SeqCount/2];
	unsigned LastSeqIndex = SeqIndexes[SeqCount-1];
	unsigned MinSeqLength = Input.GetSeqLength(LastSeqIndex);
	unsigned MaxSeqLength = Input.GetSeqLength(FirstSeqIndex);
	unsigned MedianSeqLength = Input.GetSeqLength(MidSeqIndex);

	FILE *fOut = CreateStdioFile(OutputFileName);
	for (unsigned i = 0; i < SeqCount; ++i)
		{
		ProgressStep(i, SeqCount, "Writing %s", OutputFileName.c_str());
		unsigned SeqIndex = SeqIndexes[i];
		Input.ToFasta(fOut, SeqIndex);
		}
	CloseStdioFile(fOut);
	}
