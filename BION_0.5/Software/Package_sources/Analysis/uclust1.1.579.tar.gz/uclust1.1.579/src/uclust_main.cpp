#include "myutils.h"
#include "seqdb.h"
#include "mx.h"
#include "timing.h"
#include <algorithm>

SeqDB Input;
bool g_IsNucleo = true;

void UC2Clstr();

int main(int argc, char **argv)
	{
#if	defined(DEBUG) && defined(_MSC_VER)
	_CrtSetDbgFlag(_CRTDBG_CHECK_ALWAYS_DF);
#endif

	MyCmdLine(argc, argv);

	if (opt_version)
		{
		printf("uclust v1.1.%s\n", SVN_VERSION);
		return 0;
		}

	if (opt_svnmods)
		{
		printf("Revision %s\n", SVN_VERSION);
		printf("%s\n", SVN_MODS);
		return 0;
		}

	if (!opt_quiet)
		fprintf(stderr, "uclust v1.1.%s\n", SVN_VERSION);

	if (argc < 2)
		{
		void Help();
		Help();
		return 0;
		}

	if (opt_id < 0.0 || opt_id > 1.0)
		Die("--id must be in range 0.0 to 1.0");

	if (opt_henrik != "")
		{
		void DoHenrik();
		DoHenrik();
		ProgressExit();
		return 0;
		}

	if (opt_uchime != "")
		{
		void UChime();
		UChime();
		ProgressExit();
		return 0;
		}

	if (opt_sortuc != "")
		{
		void SortUC();
		SortUC();
		ProgressExit();
		return 0;
		}

	if (opt_uc2clstr != "")
		{
		void UC2Clstr();
		UC2Clstr();
		ProgressExit();
		return 0;
		}

	if (opt_clstr2uc != "")
		{
		void Clstr2UC();
		Clstr2UC();
		ProgressExit();
		return 0;
		}

	if (opt_uc2fasta != "")
		{
		void UC2Fasta();
		UC2Fasta();
		ProgressExit();
		return 0;
		}

	if (opt_staralign != "")
		{
		void StarAlign();
		StarAlign();
		ProgressExit();
		return 0;
		}

	if (opt_input != "" && !optset_test)
		{
		void UCluster();
		UCluster();
		ProgressExit();
		return 0;
		}

	if (opt_test != "")
		{
		void Test();
		Test();
		ProgressExit();
		return 0;
		}

	if (opt_sort != "")
		{
		void SortByLength();
		SortByLength();
		ProgressExit();
		return 0;
		}

	if (opt_mergesort != "")
		{
		void MergeSort();
		MergeSort();
		ProgressExit();
		return 0;
		}

	if (opt_guide != "")
		{
		void Guide();
		Guide();
		ProgressExit();
		return 0;
		}

	CmdLineErr("No command specified");
	return 0;
	}
