#include "myutils.h"
#include "beta.h"

/***
Suppose I do an opinion poll. Votes are yes, no or don't know.
The probabilities are fixed (and sum to one because there are
no other options), but we don't know them, all we have is the
observed frequencies from a small sample.

Here is the question: given that I observe y yes votes, n no
votes and d don't know votes, what is the probability that the
true, unknown probability of yes over no exceeds a given threshold,
i.e. that:

p(yes) / p(no) > t.

ANSWER:   1-I_{t/(1+t)}(y+1,n+1)

where
I_x(p,q) = B_x(p,q)/B(p,q)

with B(p,q) the beta function and B_x(p,q) the incomplete beta function.
Since p=y+1 and q=n+1 are integers, B(y+1,n+1)=y!n!/(y+n+1)!
and B_x(y+1,n+1) is a polynomial in x which is given by a terminating 
Gauss' hypergeometric series.
***/

static double I_(double x, double p, double q)
	{
	for (int i = 0; i < 10; ++i)
		{
		double top = Incomplete_Beta_Function(x, p, q);
		double bottom = Beta_Function(p, q);
		if (bottom > 0)
			return top/bottom;
		p /= 1.5;
		q /= 1.5;
		}
	return 0.0;
	}

double Henrik(unsigned y, unsigned n, double t)
	{
	double x = I_(t/(1+t), y+1, n+1);
	if (x < -0.001 || x > 1.001)
		Warning("Henrik x=%g", x);
	if (x < 0.0)
		x = 0.0;
	if (x > 1.0)
		x = 1.0;
	return 1.0 - x;
	}

static void h(unsigned y, unsigned n, double t)
	{
	double H = Henrik(y, n, t);
	Log("%5u  %5u  %5.3f  %10.3f %s\n", y, n, t, H,
		H > 0.9 ? "<<<" : "");
	}

void TestBeta()
	{
	Log("B(1, 2) = %g\n", Beta_Function(1.0, 2.0));
	Log("B(3, 4) = %g\n", Beta_Function(3.0, 4.0));
	Log("I(0.5, 1, 2) = %g\n", Incomplete_Beta_Function(0.5, 1.0, 2.0));

	Log("\n");
	Log("    y      n      t           P\n");
	Log("-----  -----  -----  ----------\n");

	for (unsigned ti = 0; ti < 3; ++ti)
		{
		double t = ti+1;
		for (unsigned y = 1; y < 20; y += 3)
			{
			for (unsigned n = 1; n < 20; n += 3)
				{
				h(y, n, t);
				}
			}
		}
	}

void DoHenrik()
	{
	vector<string> Fields;
	Split(opt_henrik, Fields, '/');
	asserta(SIZE(Fields) == 3);

	unsigned y = atoi(Fields[0].c_str());
	unsigned n = atoi(Fields[1].c_str());
	double t = atof(Fields[2].c_str());

	double H = Henrik(y, n, t);
	Progress("Henrik(%u, %u, %.1f)=%.3f\n", y, n, t, H);
	Log("Henrik(%u, %u, %.1f)=%.3f\n", y, n, t, H);
	}
