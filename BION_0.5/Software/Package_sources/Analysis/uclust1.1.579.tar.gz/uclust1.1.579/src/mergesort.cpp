#include "myutils.h"
#include "seqdb.h"
#include "sfasta.h"

void SortByLength(const string &InputFileName, const string &OutputFileName);
void SortDescending(const vector<unsigned> &Values, vector<unsigned> &Order);

static void GetTmpFileName(unsigned SplitIndex, const string &Name,
  string &TmpFileName)
	{
	char n[16];
	sprintf(n, "%u", SplitIndex);
	TmpFileName = opt_tmpdir + string("/") + Name + string(".") + string(n) + string(".tmp");
	}

void MergeSort()
	{
	if (opt_mergesort == "")
		Die("Missing --mergesort");
	if (opt_output == "")
		Die("Missing --output");
	if (opt_split > 4000.0 && sizeof(void *) <= 4)
		Die("--mem %s is too big (>4Gb) this build has 32-bit pointers",
		  MemBytesToStr(opt_split*1e6));
	else if (opt_split > 2000.0)
		Warning("--mem %s, may fail on some computers", MemBytesToStr(opt_split*1e6));

	const string &FileName = opt_mergesort;
	unsigned SplitSize = (unsigned) (opt_split*1e6);
	char *Buffer = myalloc<char>(SplitSize);

	FILE *fIn = OpenStdioFile(FileName);
	FILE *fOut = CreateStdioFile(opt_output);

	off_t FileSize = GetStdioFileSize(fIn);
	Log("File size %.3g bytes\n", (double) FileSize);

	unsigned SplitCount = 0;
	off_t FilePos = 0;

	SplitCount = 0;
	for (unsigned SplitIndex = 0; ; ++SplitIndex)
		{
		if (FilePos >= FileSize)
			break;

		off_t otBytesToRead = FileSize - FilePos;

		bool Trunc = false;
		if (otBytesToRead >= (off_t) SplitSize)
			{
			Trunc = true;
			otBytesToRead = SplitSize;
			}

		unsigned BytesToRead = (unsigned) otBytesToRead;
		Log("Read split %u pos=%g bytes=%u\n", SplitIndex, (double) FilePos, BytesToRead);
		Progress("Reading split %u\n", SplitIndex);
		ReadStdioFile(fIn, FilePos, Buffer, BytesToRead);

		unsigned SplitBytes = BytesToRead;
		if (Trunc)
			{
		// Search backwards for first '>'
			unsigned SeqStart = UINT_MAX;
			for (unsigned i = 0; i < BytesToRead; ++i)
				{
				if (Buffer[BytesToRead-i-1] == '>')
					{
					SeqStart = BytesToRead-i-1;
					Log("i=%u SeqStart=%u\n", i, SeqStart);
					break;
					}
				}
			if (SeqStart == UINT_MAX)
				Die("Failed to find '>' in split %u", SplitIndex);

		// Truncate up to last > to avoid partial sequence
			SplitBytes = SeqStart;
			}

		string TmpFileName;
		GetTmpFileName(SplitIndex, "split", TmpFileName);
		FILE *f = CreateStdioFile(TmpFileName);
		Progress("Writing %s, %s bytes\n", TmpFileName.c_str(), MemBytesToStr(SplitBytes));
		WriteStdioFile(f, Buffer, SplitBytes);
		CloseStdioFile(f);
		++SplitCount;

		FilePos += SplitBytes;
		}
	CloseStdioFile(fIn);
	Progress("%u splits done\n", SplitCount);
	myfree(Buffer);
	
	for (unsigned SplitIndex = 0; SplitIndex < SplitCount; ++SplitIndex)
		{
		string TmpFileName;
		GetTmpFileName(SplitIndex, "split", TmpFileName);

		string TmpFileName2;
		GetTmpFileName(SplitIndex, "split_sorted", TmpFileName2);

		SortByLength(TmpFileName, TmpFileName2);

		DeleteStdioFile(TmpFileName);
		}
	Progress("Sorting done\n");

	vector<const byte *> Seqs(SplitCount);
	vector<unsigned> Lengths(SplitCount);
	vector<const char *> Labels(SplitCount);
	vector<SFasta *> SFs(SplitCount);

	for (unsigned SplitIndex = 0; SplitIndex < SplitCount; ++SplitIndex)
		{
		SFasta *SF = new SFasta;
		SFs[SplitIndex] = SF;

		string TmpFileName;
		GetTmpFileName(SplitIndex, "split_sorted", TmpFileName);
		SF->Open(TmpFileName);
		Seqs[SplitIndex] = SF->GetNextSeq();
		if (Seqs[SplitIndex] == 0)
			Die("Get first seq failed in %s\n", TmpFileName.c_str());
		Lengths[SplitIndex] = SF->GetSeqLength();
		Labels[SplitIndex] = SF->GetLabel();
		}

	Progress("Merging\n");
	unsigned OutCount = 0;
	for (;;)
		{
	// Find max
		unsigned MaxLength = 0;
		unsigned MaxSplit = 0;
		for (unsigned SplitIndex = 0; SplitIndex < SplitCount; ++SplitIndex)
			{
			if (Lengths[SplitIndex] > MaxLength)
				{
				MaxLength = Lengths[SplitIndex];
				MaxSplit = SplitIndex;
				}
			}
		if (MaxLength == 0)
			break;

	// Output longest
		fprintf(fOut, ">%s\n", Labels[MaxSplit]);
		fprintf(fOut, "%*.*s\n", Lengths[MaxSplit], Lengths[MaxSplit], Seqs[MaxSplit]);

	// Read next
		SFasta *SF = SFs[MaxSplit];
		Seqs[MaxSplit] = SF->GetNextSeq();
		if (Seqs[MaxSplit] == 0)
			{
			SF->Clear();
			Lengths[MaxSplit] = 0;
			string TmpFileName;
			GetTmpFileName(MaxSplit, "split_sorted", TmpFileName);
			Progress("\n");
			Progress("Delete %s\n", TmpFileName.c_str());
			DeleteStdioFile(TmpFileName);
			}
		else
			{
			Lengths[MaxSplit] = SF->GetSeqLength();
			Labels[MaxSplit] = SF->GetLabel();
			}
		++OutCount;
		if (OutCount%10000 == 0)
			Progress("%u seqs written\r", OutCount);
		}
	CloseStdioFile(fOut);
	Progress("\n");
	Progress("Merge done, %u seqs written\n", OutCount);
	}
