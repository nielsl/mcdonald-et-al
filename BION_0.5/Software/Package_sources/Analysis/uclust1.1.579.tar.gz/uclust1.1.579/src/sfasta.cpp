#include "sfasta.h"
#include "timing.h"

const unsigned BufferSize = 16*1024*1024;

SFasta::SFasta()
	{
	m_FileName = "";
	m_File = 0;
	m_Buffer = 0;
	m_BufferSize = 0;
	m_BufferOffset = 0;
	m_BufferBytes = 0;
	m_FilePos = 0;
	m_FileSize = 0;
	m_Label = 0;
	m_SeqLength = 0;
	}

SFasta::~SFasta()
	{
	Clear();
	}

void SFasta::Clear()
	{
	myfree(m_Buffer);
	if (m_File != 0)
		CloseStdioFile(m_File);

	m_FileName = "";
	m_File = 0;
	m_Buffer = 0;
	m_BufferSize = 0;
	m_BufferOffset = 0;
	m_BufferBytes = 0;
	m_FilePos = 0;
	m_FileSize = 0;
	m_Label = 0;
	m_SeqLength = 0;
	}

void SFasta::LogMe() const
	{
	Log("\n");
	Log("SFasta::LogMe()\n");
	Log("FileName=%s\n", m_FileName.c_str());
	Log("FileSize=%u\n", (unsigned) m_FileSize);
	Log("FilePos=%u\n", (unsigned) m_FilePos);
	Log("BufferSize=%u\n", m_BufferSize);
	Log("BufferPos=%u\n", m_BufferOffset);
	Log("BufferBytes=%u\n", m_BufferBytes);
	if (m_Label == 0)
		Log("Label=NULL\n");
	else
		Log("Label=%s\n", m_Label);
	Log("SeqLength=%u\n", m_SeqLength);
	}

const byte *SFasta::GetNextSeq()
	{
// End of cache?
	if (m_BufferOffset == m_BufferBytes)
		{
	// End of file?
		if (m_FilePos == m_FileSize)
			return 0;
		FillCache();
		}

	StartTimer(GetNextSeq);
	asserta(m_Buffer[m_BufferOffset] == '>');
	m_Label = (char *) (m_Buffer + m_BufferOffset + 1);
	
// Scan to end-of-line.
// Use dubious library function strchr() in the hope
// that it uses fast machine code.
	byte *ptr = (byte *) strchr(m_Label, '\n');
	asserta(ptr != 0);
	*ptr = 0;

	if (opt_trunclabels)
		{
		for (char *p = m_Label; *p; ++p)
			if (isspace(*p))
				{
				*p = 0;
				break;
				}
		}
	else
		{
		for (char *p = m_Label; *p; ++p)
			if (*p == '\t')
				{
				*p = ' ';
				break;
				}
		}

// Check for CR-NL line termination
	if (ptr[-1] == '\r')
		*ptr--;

// Nul-terminate label string and move to
// start of sequence data.
	*ptr++ = 0;
	byte *Seq = ptr;

// Delete white space in-place
	byte *To = ptr;
	m_BufferOffset = (unsigned) (ptr - m_Buffer);
	while (m_BufferOffset < m_BufferBytes)
		{
		byte c = m_Buffer[m_BufferOffset];
		if (c == '>')
			break;
		++m_BufferOffset;
		if (isspace(c))
			continue;
		*To++ = c;
		}
	m_SeqLength = unsigned(To - Seq);
	EndTimer(GetNextSeq);
	return Seq;
	}

void SFasta::Open(const string &FileName)
	{
	Clear();
	m_File = OpenStdioFile(FileName);
	m_BufferSize = BufferSize;
	m_Buffer = myalloc<byte>(m_BufferSize);
	m_FileSize = GetStdioFileSize(m_File);
	}

void SFasta::Rewind()
	{
	m_BufferOffset = 0;
	m_BufferBytes = 0;
	m_FilePos = 0;
	}

bool SFasta::IsNucleo()
	{
	bool IsNucleoLetter(byte c);

	if (m_FilePos != 0)
		Die("SFasta::IsNucleo, not at BOF");

	unsigned LetterCount = 0;
	unsigned NucleoLetterCount = 0;
	for (;;)
		{
		const byte *Seq = GetNextSeq();
		if (Seq == 0)
			break;
		unsigned L = GetSeqLength();
		for (unsigned i = 0; i < L; ++i)
			if (IsNucleoLetter(Seq[i]))
				++NucleoLetterCount;
		LetterCount += L;
		if (LetterCount > 256)
			break;
		}
	Rewind();
	if (LetterCount == 0)
		return true;

// Nucleo if more than 90% nucleo letters AGCTUN
	return double(NucleoLetterCount)/LetterCount > 0.9;
	}

void SFasta::FillCache()
	{
	asserta(m_FilePos < m_FileSize);

// off_t may be larger type than unsigned, e.g. 64- vs. 32-bit.
	off_t otBytesToRead = m_FileSize - m_FilePos;

	bool FinalBuffer = true;
	if (otBytesToRead > (off_t) m_BufferSize)
		{
		FinalBuffer = false;
		otBytesToRead = m_BufferSize;
		}

	unsigned BytesToRead = unsigned(otBytesToRead);
	asserta(BytesToRead > 0);
	asserta(BytesToRead <= m_BufferSize);

	ReadStdioFile(m_File, m_FilePos, m_Buffer, BytesToRead);
	if (m_Buffer[0] != '>')
		{
		if (m_FilePos == 0)
			Die("Input is not FASTA file");
		else
			Die("SFasta::FillCache() failed, expected '>'");
		}

	m_BufferOffset = 0;

// If last buffer in file, done
	if (FinalBuffer)
		{
		m_BufferBytes = BytesToRead;
		m_FilePos += BytesToRead;
		return;
		}

// If not last buffer, truncate any partial sequence
// at end of buffer. Search backwards to find last '>'.
	byte *ptr = m_Buffer + BytesToRead - 1;
	while (ptr > m_Buffer)
		{
		byte c = *ptr;
		if (c == '>')
			break;
		--ptr;
		}

	if (ptr == m_Buffer)
		{
		LogMe();
		if (*ptr != '>')
			{
	// No '>' found.
	// This might techincally be legal FASTA if the entire
	// buffer is white space, but strange if not the last buffer
	// in the file, so quit anyway.
			Die("Failed to find '>' (pos=%u, bytes=%u)",
			  (unsigned) m_FilePos, BytesToRead);
			}
		else
			{
	// Entire buffer is one sequence which may be truncated.
			Die("Sequence too long (pos=%u, bytes=%u)",
			  (unsigned) m_FilePos, BytesToRead);
			}
		}

	asserta(*ptr == '>');

	m_BufferBytes = unsigned(ptr - m_Buffer);
	m_FilePos += m_BufferBytes;
	}

void TestSFasta()
	{
	SFasta SF;
	SF.Open(opt_input);

	Log("  Index   Length  Label\n");
	Log("-------  -------  -----\n");
	unsigned Index = 0;
	for (;;)
		{
		const byte *Seq = SF.GetNextSeq();
		if (Seq == 0)
			break;
		const char *Label = SF.GetLabel();
		unsigned L = SF.GetSeqLength();

		Log("%7u  %7u  '%s'\n", Index, L, Label);

		Log("%7.7s  %7.7s  '%*.*s'\n", "", "", L, L, Seq);

		++Index;
		}
	}

double SFasta::GetPctDone() const
	{
	if (m_FilePos == 0 || m_FileSize == 0)
		return 0.0;

	assert(m_FilePos >= (off_t) m_BufferBytes);
	off_t BufferStart = m_FilePos - m_BufferBytes;
	off_t BufferPos = BufferStart + m_BufferOffset;

	return double(BufferPos)*100.0/double(m_FileSize);
	}
