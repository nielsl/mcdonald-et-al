#include "myutils.h"
#include "hspfinder.h"
#include "timing.h"

const char *WordToStr(unsigned Word, unsigned WordLength);
extern unsigned g_AlphaSize;

HSPFinder::HSPFinder()
	{
	Clear(true);
	}

HSPFinder::~HSPFinder()
	{
	Clear();
	}

void HSPFinder::Clear(bool ctor)
	{
	m_WordLength = 0;
	m_WordCount = 0;
	m_Hi = 0;

	m_LabelA = 0;
	m_LabelB = 0;
	m_LA = 0;
	m_LB = 0;

	m_DiagCountsSize = 0;

	m_WordCountA = 0;
	m_WordCountB = 0;
	m_WordsASize = 0;
	m_WordsBSize = 0;

	if (!ctor)
		{
		myfree(m_WordsA);
		myfree(m_WordsB);
		myfree(m_WordToPosA);
		myfree(m_WordCountsA);
		myfree(m_DiagCounts);
		}

	m_WordsA = 0;
	m_WordsB = 0;
	m_WordToPosA = 0;
	m_WordCountsA = 0;
	m_DiagCounts = 0;
	}

void HSPFinder::Init(unsigned WordLength)
	{
	m_WordLength = WordLength;

// WordCount = WordLength^AlphaSize
	m_WordCount = 1;
	for (unsigned i = 0; i < WordLength; ++i)
		m_WordCount *= g_AlphaSize;
	m_Hi = m_WordCount/g_AlphaSize;

	m_WordToPosA = myalloc<unsigned>(m_WordCount*MaxReps);
	m_WordCountsA = myalloc<unsigned>(m_WordCount);
	}

const char *HSPFinder::WordToStr(unsigned Word) const
	{
	return ::WordToStr(Word, m_WordLength);
	}

// WARNING -- can't skip wildcards because indexes used to
// compute diagonal!
unsigned HSPFinder::SeqToWords(const byte *Seq, unsigned L, word_t *Words) const
	{
	if (L < m_WordLength)
		return 0;

	StartTimer(WF_SeqToWords);

	const unsigned WordCount = L - m_WordLength + 1;
	word_t Word = 0;
	const byte *Front = Seq;
	const byte *Back = Seq;
	for (unsigned i = 0; i < m_WordLength-1; ++i)
		{
		unsigned Letter = CharToLetter[*Front++];
		Word = (Word*g_AlphaSize) + Letter;
		}

	for (unsigned i = m_WordLength-1; i < L; ++i)
		{
		unsigned Letter = CharToLetter[*Front++];
		Word = (Word*g_AlphaSize) + Letter;

		assert(Word < m_WordCount);
#if	DEBUG
		if (Word != SeqToWord(Seq+i+1-m_WordLength))
			{
			unsigned SWord = SeqToWord(Seq+i+1-m_WordLength);
			Log("SeqToWord(Pos=%u)=%u=%s\n", i+1-m_WordLength, SWord, WordToStr(SWord));
			Die("Word");
			}
#endif
		*Words++ = Word;

		Letter = CharToLetter[*Back++];
		Word -= Letter*m_Hi;
		}

	EndTimer(WF_SeqToWords);
	return WordCount;
	}

void HSPFinder::AllocLA(unsigned LA)
	{
	if (LA <= m_WordsASize)
		return;
	StartTimer(WF_AllocLA);
	myfree(m_WordsA);

	m_WordsASize = LA + 32;
	m_WordsA = myalloc<word_t>(m_WordsASize);

	if (opt_logmemgrows)
		Log("HSPFinder::AllocLA(%u)\n", m_WordsASize);

	EndTimer(WF_AllocLA);
	}

void HSPFinder::AllocLB(unsigned LB)
	{
	if (LB <= m_WordsBSize)
		return;
	StartTimer(WF_AllocLB);
	myfree(m_WordsB);

	m_WordsBSize = LB + 32;
	m_WordsB = myalloc<word_t>(m_WordsBSize);

	if (opt_logmemgrows)
		Log("HSPFinder::AllocLB(%u)\n", m_WordsBSize);

	EndTimer(WF_AllocLB);
	}

void HSPFinder::AllocDiags(unsigned DiagCount)
	{
	if (DiagCount <= m_DiagCountsSize)
		return;

	StartTimer(WF_AllocDiags);
	m_DiagCountsSize = DiagCount + 32;
	myfree(m_DiagCounts);
	m_DiagCounts = myalloc<unsigned>(m_DiagCountsSize);

	if (opt_logmemgrows)
		Log("HSPFinder::AllocDiags(%u)\n", m_DiagCountsSize);

	EndTimer(WF_AllocDiags);
	}

void HSPFinder::SetA(const char *LabelA, const byte *A, unsigned LA)
	{
	AllocLA(LA);

	m_LabelA = LabelA;
	m_A = A;
	m_LA = LA;

	m_WordCountA = SeqToWords(A, LA, m_WordsA);

	StartTimer(WF_SetA);

	zero(m_WordCountsA, m_WordCount);
	for (unsigned PosA = 0; PosA < m_WordCountA; ++PosA)
		{
		unsigned Word = m_WordsA[PosA];
		assert(Word < m_WordCount);
		unsigned n = m_WordCountsA[Word];
		if (n == MaxReps)
			continue;
		m_WordToPosA[Word*MaxReps + n] = PosA;
		++(m_WordCountsA[Word]);
		}
	EndTimer(WF_SetA);
	}

void HSPFinder::SetB(const char *LabelB, const byte *B, unsigned LB)
	{
	AllocLB(LB);

	m_LabelB = LabelB;
	m_B = B;
	m_LB = LB;

	m_WordCountB = SeqToWords(B, LB, m_WordsB);
	}

unsigned HSPFinder::GetCommonWordCount() const
	{
	StartTimer(WF_GetCommonWordCount);
	unsigned Count = 0;
	for (unsigned PosB = 0; PosB < m_WordCountB; ++PosB)
		{
		unsigned Word = m_WordsB[PosB];
		assert(Word < m_WordCount);
		if (m_WordCountsA[Word] > 0)
			++Count;
		}
	EndTimer(WF_GetCommonWordCount);
	return Count;
	}

// To suppress spurious hits, restrict to reasonable range around
// the main diagonal.
void HSPFinder::GetPlausibleDiagRange(unsigned &dlo, unsigned &dhi) const
	{
// Reject HSPs not within 16 of main diagonal
	dlo = min(m_LA, m_LB);
	if (dlo >= 16)
		dlo -= 16;
	else
		dlo = 0;
	dhi = max(m_LA, m_LB) + 16;
	}

unsigned HSPFinder::GetBestDiag()
	{
	unsigned DiagCount = m_LA + m_LB - 1;
	AllocDiags(DiagCount);

	StartTimer(WF_GetBestDiag);

	unsigned dlo, dhi;
	GetPlausibleDiagRange(dlo, dhi);

	zero(m_DiagCounts, DiagCount);

	unsigned MaxDiagCount = 0;
	unsigned BestDiag = UINT_MAX;
	for (unsigned PosB = 0; PosB < m_WordCountB; ++PosB)
		{
		unsigned Word = m_WordsB[PosB];
		assert(Word < m_WordCount);
		unsigned N = m_WordCountsA[Word];
		for (unsigned i = 0; i < N; ++i)
			{
			unsigned PosA = m_WordToPosA[Word*MaxReps + i];
			unsigned Diag = (m_LA + PosB) - PosA;
			assert(Diag > 0);
			assert(Diag < DiagCount);
			if (Diag < dlo || Diag > dhi)
				continue;
			unsigned NewCount = m_DiagCounts[Diag] + 1;
			m_DiagCounts[Diag] = NewCount;
			if (NewCount > MaxDiagCount)
				{
				BestDiag = Diag;
				MaxDiagCount = NewCount;
				}
			}
		}
	EndTimer(WF_GetBestDiag);
	return BestDiag;
	}

unsigned HSPFinder::SeqToWord(const byte *Seq) const
	{
	word_t Word = 0;
	const byte *Front = Seq;
	for (unsigned i = 0; i < m_WordLength; ++i)
		{
		unsigned Letter = CharToLetter[*Front++];
		Word = (Word*g_AlphaSize) + Letter;
		}
	return Word;
	}

void HSPFinder::LogMe() const
	{
	Log("\n");
	Log("HSPFinder::LogMe()\n");
	Log("LA=%u, LB=%u, LabelA=%s, LabelB=%s\n",
	  m_LA, m_LB, m_LabelA, m_LabelB);
	Log("A=%*.*s\n", m_LA, m_LA, m_A);
	Log("B=%*.*s\n", m_LB, m_LB, m_B);
	Log("\n");
	Log(" PosA      Word\n");
	Log("-----  --------\n");
	for (unsigned i = 0; i < m_WordCountA; ++i)
		Log("%5u  %8.8s\n", i, WordToStr(m_WordsA[i]));
	Log("\n");
	Log(" PosB      Word   PosAs\n");
	Log("-----  --------  ------\n");
	for (unsigned i = 0; i < m_WordCountB; ++i)
		{
		unsigned Word = m_WordsB[i];
		assert(Word < m_WordCount);
		Log("%5u  %8.8s", i, WordToStr(Word));
		unsigned n = m_WordCountsA[Word];
		if (n > 0)
			Log("  %u:", n);
		asserta(n <= MaxReps);
		for (unsigned k = 0; k < n; ++k)
			Log(" %u", m_WordToPosA[Word*MaxReps + k]);
		Log("\n");
		}
	}

bool HSPFinder::HSPInPath(const HSPData &HSP, const char *Path)
	{
	unsigned Amid = HSP.GetAmid();
	unsigned Bmid = HSP.GetBmid();

	unsigned APos = 0;
	unsigned BPos = 0;
	for (const char *p = Path; *p; ++p)
		{
		char c = *p;
		if (c == 'M' || c == 'D')
			{
			if (APos == Amid)
				return BPos == Bmid;
			else if (APos > Amid)
				return false;
			}
		if (c == 'M' || c == 'D')
			++APos;
		if (c == 'M' || c == 'I')
			++BPos;
		}
	return false;
	}
