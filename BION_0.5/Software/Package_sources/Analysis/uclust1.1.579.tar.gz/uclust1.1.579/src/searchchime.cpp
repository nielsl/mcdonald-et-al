#include "myutils.h"
#include "ultra.h"
#include "chime.h"
#include "uc.h"
#include "pwa.h"
#include <set>
#include <algorithm>

#define TRACE	0

bool UChimeX(const string &QueryLabel, const byte *QuerySeq, unsigned QueryLength,
  const vector<string> &ParentLabels, const vector<const byte *> &ParentSeqs,
  const vector<unsigned> &ParentLengths, const vector<string> &Paths, 
  double TopPctId, ChimeHit2 &Hit);

void LogAln(const byte *A, const byte *B, const char *Path);
const char *NWAff(const byte *A, unsigned LA, const byte *B, unsigned LB,
  bool LeftTerm, bool RightTerm);
double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path);

extern FILE *g_fChunks;

static void GetCandidateParents(Ultra &U, PWA &pwa,
  const AlnParams &AP, const AlnHeuristics &AH,
  const char *QueryLabel, const byte *QuerySeq, unsigned QueryLength,
  set<unsigned> &Parents)
	{
	Parents.clear();

	unsigned ChunkLength = opt_ovchunks ?
	  (2*QueryLength)/opt_chunks : QueryLength/opt_chunks;
	if (ChunkLength < opt_minchunk)
		ChunkLength = opt_minchunk;

	unsigned ChunkCount = (QueryLength + ChunkLength - 1)/ChunkLength;

	for (unsigned ChunkIndex = 0; ChunkIndex < ChunkCount; ++ChunkIndex)
		{
		HitData Hit;
	
		unsigned Lo = opt_ovchunks ?
		  (ChunkIndex*ChunkLength)/2 : ChunkIndex*ChunkLength;
		unsigned Length = ChunkLength;
		if (Lo + Length >= QueryLength)
			Length = QueryLength - Lo - 1;
		if (Length + 8 < opt_minchunk)
			{
			asserta(ChunkIndex+1 == ChunkCount);
			break;
			}
		const byte *Chunk = QuerySeq + Lo;

		char Prefix[32];
		sprintf(Prefix, "%u|", Lo);
		string ChunkLabel = string(Prefix) + string(QueryLabel);

		if (g_fChunks)
			{
			fprintf(g_fChunks, ">%s\n", ChunkLabel.c_str());
			fprintf(g_fChunks, "%*.*s\n", Length, Length, Chunk);
			}

		bool Found = U.Search(QueryLabel, Chunk, Length, 0, Hit);
		if (Found)
			Parents.insert(Hit.SeedIndex);
		}
	}

bool SearchChime(Ultra &U, PWA &pwa, const AlnParams &AP, const AlnHeuristics &AH,
  const char *QueryLabel, const byte *QuerySeq, unsigned QueryLength, ChimeHit2 &Hit)
	{
	Hit.Clear();

#if	TRACE
	Log("\n");
	Log("Query >%s\n", QueryLabel);
#endif

	set<unsigned> Parents;
	GetCandidateParents(U, pwa, AP, AH, QueryLabel, QuerySeq, QueryLength, Parents);

	unsigned ParentCount = SIZE(Parents);
#if	TRACE
	{
	Log("%u parents\n", ParentCount);
	for (set<unsigned>::const_iterator p = Parents.begin();
	  p != Parents.end(); ++p)
		{
		unsigned SeedIndex = *p;
		const char *SeedLabel = U.GetSeedLabel(SeedIndex);
		Log(" %s", SeedLabel);
		}
	Log("\n");
	}
#endif
	if (ParentCount <= 1)
		return false;

	pwa.SetQuery(QueryLabel, QuerySeq, QueryLength);

	vector<string> ParentLabels;
	vector<const byte *> ParentSeqs;
	vector<unsigned> ParentLengths;
	vector<string> Paths;
	vector<double> ParentIds;
	double TopId = 0.0;
	string LabT;
	for (set<unsigned>::const_iterator p = Parents.begin();
	  p != Parents.end(); ++p)
		{
		unsigned SeedIndex = *p;
		const char *SeedLabel = U.GetSeedLabel(SeedIndex);
		const byte *SeedSeq = U.GetSeedSeq(SeedIndex);
		unsigned SeedL = U.GetSeedLength(SeedIndex);
		pwa.SetTarget(SeedLabel, SeedSeq, SeedL);
		const char *Path = pwa.Align(AP, AH);
		if (Path == 0)
			continue;

		double Id = GetFractIdGivenPath(QuerySeq, SeedSeq, Path);
		if (Id > TopId)
			{
			LabT = SeedLabel;
			TopId = Id;
			}

		ParentLabels.push_back(SeedLabel);
		ParentSeqs.push_back(SeedSeq);
		ParentLengths.push_back(SeedL);
		ParentIds.push_back(Id);
		Paths.push_back(Path);
		}

	bool Found = UChimeX(QueryLabel, QuerySeq, QueryLength,
	  ParentLabels, ParentSeqs, ParentLengths, Paths, TopId*100.0, Hit);
	Hit.LabT = LabT;

	return Found;
	}
