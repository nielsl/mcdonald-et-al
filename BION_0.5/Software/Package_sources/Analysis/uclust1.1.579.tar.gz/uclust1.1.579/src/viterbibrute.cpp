#include "dp.h"

#define TRACE			0
#define TRACE_RESULT	0

void GetDiagLoHi(unsigned LA, unsigned LB, const char *Path,
  unsigned &dlo, unsigned &dhi);

static const SegPair *g_SP;
static const AlnParams *g_AP;

static Mx<float> g_MxDPM;
static Mx<float> g_MxDPD;
static Mx<float> g_MxDPI;

static float **g_DPM;
static float **g_DPD;
static float **g_DPI;

static float g_BestScore;
static string g_BestPath;

static unsigned g_LA;
static unsigned g_LB;
static unsigned g_DiagLo;
static unsigned g_DiagHi;
static bool g_RestrictDiags;

void GetBruteMxs(Mx<float> **M, Mx<float> **D, Mx<float> **I)
	{
	*M = &g_MxDPM;
	*D = &g_MxDPD;
	*I = &g_MxDPI;
	}

static void Alloc(unsigned LA, unsigned LB)
	{
	g_MxDPM.Alloc("BruteM", LA+1, LB+1);
	g_MxDPD.Alloc("BruteD", LA+1, LB+1);
	g_MxDPI.Alloc("BruteI", LA+1, LB+1);

	g_DPM = g_MxDPM.GetData();
	g_DPD = g_MxDPD.GetData();
	g_DPI = g_MxDPI.GetData();
	}

static void GetPrefixLengths(const string &Path, unsigned &i, unsigned &j)
	{
	i = 0;
	j = 0;
	for (unsigned k = 0; k < SIZE(Path); ++k)
		{
		switch (Path[k])
			{
		case 'M': ++i; ++j; break;
		case 'D': ++i; break;
		case 'I': ++j; break;
		default: asserta(false);
			}
		}
	}

static void OnPath(const string &Path, bool Full)
	{
	if (Path.empty())
		return;

	unsigned i;
	unsigned j;
	GetPrefixLengths(Path, i, j);
	byte LastState = Path[Path.size() - 1];

	if (g_RestrictDiags)
		{
		unsigned dlo, dhi;
		GetDiagLoHi(g_LA, g_LB, Path.c_str(), dlo, dhi);
		if ((dlo != UINT_MAX && dlo < g_DiagLo) || (dhi != UINT_MAX && dhi > g_DiagHi))
			{
#if	TRACE
			Log("dlo=%u<%u dhi=%u>%u Path=%s\n",
			  dlo, g_DiagLo, dhi, g_DiagHi, Path.c_str());
#endif
			return;
			}
		}

	AlnParams AP;
	SegPair SP = *g_SP;
	SP.SA = i;
	SP.SB = j;
	AP.Init(*g_AP, SP);
	float Score = ScorePath(*g_SP, AP, Path.c_str());

	if (Full && Score > g_BestScore)
		{
		g_BestScore = Score;
		g_BestPath = Path;
		}

	switch (LastState)
		{
	case 'M':
		if (Score > g_DPM[i][j])
			{
#if	TRACE
			Log("DPM[%u][%u] = %g\n", i, j, Score);
#endif
			g_DPM[i][j] = Score;
			}
		break;

	case 'D':
		if (Score > g_DPD[i][j])
			{
#if	TRACE
			Log("DPD[%u][%u] = %g\n", i, j, Score);
#endif
			g_DPD[i][j] = Score;
			}
		break;

	case 'I':
		if (Score > g_DPI[i][j])
			{
#if	TRACE
			Log("DPI[%u][%u] = %g\n", i, j, Score);
#endif
			g_DPI[i][j] = Score;
			}
		break;

	default:
		asserta(false);
		}
	}

const char *ViterbiBrute(const SegPair &SP, const AlnParams &AP,
  unsigned DiagLo, unsigned DiagHi)
	{
	g_BestPath.clear();
	g_BestScore = MINUS_INFINITY;

	const byte *A = SP.A + SP.LoA;
	const byte *B = SP.B + SP.LoB;

	unsigned LA = SP.GetSegLenA();
	unsigned LB = SP.GetSegLenB();

	Alloc(LA, LB);

	g_SP = &SP;
	g_AP = &AP;

	g_LA = LA;
	g_LB = LB;
	g_DiagLo = DiagLo;
	g_DiagHi = DiagHi;
	g_RestrictDiags = (DiagLo != UINT_MAX);

	for (unsigned i = 0; i <= LA; ++i)
		{
		for (unsigned j = 0; j <= LB; ++j)
			{
			g_DPM[i][j] = MINUS_INFINITY;
			g_DPD[i][j] = MINUS_INFINITY;
			g_DPI[i][j] = MINUS_INFINITY;
			}
		}

	g_DPM[0][0] = 0;
	EnumPaths(LA, LB, true, OnPath);

#if	TRACE || TRACE_RESULT
	g_MxDPM.LogMe();
	g_MxDPD.LogMe();
	g_MxDPI.LogMe();
#endif

	return g_BestPath.c_str();
	}
