#include "myutils.h"
#include "timing.h"

void GetPathLetterCounts(const char *Path, unsigned &M, unsigned &D, unsigned &I)
	{
	M = D = I = 0;
	for (const char *p = Path; *p; ++p)
		switch (*p)
			{
		case 'M':
			++M;
			break;
		case 'D':
			++D;
			break;
		case 'I':
			++I;
			break;
		default:
			asserta(false);
			}
	}

unsigned GetCompressedPathLetterCounts(const char *CompressedPath,
  unsigned &M, unsigned &D, unsigned &I)
	{
	M = 0;
	D = 0;
	I = 0;
	const char *p = CompressedPath;
	for (;;)
		{
		if (!(*p))
			break;
		unsigned n = 0;
		while (*p && isdigit(*p))
			n = n*10 + (*p++ - '0');
		if (*p == 0)
			break;
		char State = *p++;
		if (n == 0)
			n = 1;

		switch (State)
			{
		case 'M':
			++M;
			break;
		case 'D':
			++D;
			break;
		case 'I':
			++I;
			break;
		default:
			asserta(false);
			}
		}
	return M + D + I;
	}

void GetCompressedPathLetterCounts(const char *CompressedPath,
  unsigned &ACount, unsigned &BCount)
	{
	ACount = 0;
	BCount = 0;
	const char *p = CompressedPath;
	for (;;)
		{
		if (!(*p))
			return;
		unsigned n = 0;
		while (*p && isdigit(*p))
			n = n*10 + (*p++ - '0');
		if (*p == 0)
			return;
		char State = *p++;
		if (n == 0)
			n = 1;

		switch (State)
			{
		case 'M':
			ACount += n;
			BCount += n;
			break;
		case 'D':
			ACount += n;
			break;
		case 'I':
			BCount += n;
			break;
		default:
			asserta(false);
			}
		}
	}

void ExpandPath(const char *CompressedPath, vector<char> &States, vector<unsigned> &Counts)
	{
	States.clear();
	Counts.clear();
	
	const char *p = CompressedPath;
	for (;;)
		{
		if (!(*p))
			return;
		unsigned n = 0;
		while (*p && isdigit(*p))
			n = n*10 + (*p++ - '0');
		if (*p == 0)
			return;
		char State = *p++;
		if (n == 0)
			n = 1;
		States.push_back(State);
		Counts.push_back(n);
		}
	}

void ExpandPath(const char *CompressedPath, string &Path)
	{
	Path.clear();
	
	const char *p = CompressedPath;
	for (;;)
		{
		if (!(*p))
			return;
		unsigned n = 0;
		while (*p && isdigit(*p))
			n = n*10 + (*p++ - '0');
		if (*p == 0)
			return;
		char State = *p++;
		if (n == 0)
			n = 1;
		for (unsigned i = 0; i < n; ++i)
			Path.push_back(State);
		}
	}

const char *CompressPath(const char *Path)
	{
	if (Path == 0)
		return 0;

	StartTimer(CompressPath);

	static char *Buffer;
	static unsigned BufferSize = 0;

	unsigned L = (unsigned) strlen(Path);
	if (L + 1 > BufferSize)
		{
		myfree(Buffer);
		BufferSize = L + 4096;
		Buffer = myalloc<char>(BufferSize);
		}

	char LastC = *Path;
	unsigned n = 1;
	char *p = Buffer;
	for (unsigned i = 1; i < L; ++i)
		{
		char c = Path[i];
		if (c == LastC)
			{
			++n;
			continue;
			}
		else
			{
			assert(n > 0);
			if (n == 1)
				*p++ = LastC;
			else if (n > 1)
				{
				static char s[16];
				int k = sprintf(p, "%u%c", n, LastC);
				p += k;
				}
			LastC = c;
			n = 1;
			}
		}
	if (n == 1)
		*p++ = LastC;
	else if (n > 1)
		{
		static char s[16];
		int k = sprintf(p, "%u%c", n, LastC);
		p += k;
		}
	*p = 0;
	EndTimer(CompressPath);
	return Buffer;
	}

const char *CompressPath(const string &Path)
	{
	return CompressPath(Path.c_str());
	}
