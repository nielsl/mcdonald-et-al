#include "myutils.h"
#include "timing.h"
#include <time.h>
#include <algorithm>

#if	TIMING

static TICKS g_StartTicks = GetClockTicks();
static time_t g_StartTime = time(0);

double g_Counters[CounterCount];
double g_TotalCounts[TimerCount];
TICKS g_BeginTicks[TimerCount];
double g_TotalTicks[TimerCount];
TIMER g_CurrTimer = TIMER_None;
//static map<string, double> g_TotalBytes;

const char *TimerToStr(TIMER t)
	{
	switch (t)
		{
#define T(x)	case TIMER_##x: return #x;
#include "timers.h"
		}
	return "?";
	}

const char *CounterToStr(COUNTER c)
	{
	switch (c)
		{
#define C(x)	case COUNTER_##x: return #x;
#include "counters.h"
		}
	return "?";
	}

static bool LT(unsigned i, unsigned j)
	{
	return g_TotalTicks[i] > g_TotalTicks[j];
	}

void LogCounters()
	{
	Log("\n");
	Log("                        Counter            N\n");
	Log("--------------------------------  ----------\n");
	for (unsigned i = 0; i < CounterCount; ++i)
		{
		double N = g_Counters[i];
		if (N == 0)
			continue;
		Log("%32.32s  %10.10s\n", CounterToStr((COUNTER) i), FloatToStr(N));
		// Log("%32.32s  %10.3g\n", CounterToStr((COUNTER) i), N);
		}
	}

void LogTickStats()
	{
	TICKS Now = GetClockTicks();
	time_t tNow = time(0);
	double ElapsedTicks = double(Now - g_StartTicks);
	double ElapsedSecs = double(tNow - g_StartTime);
	if (ElapsedSecs == 0.0)
		ElapsedSecs = 0.1;
	double TicksToSecs = ElapsedSecs/ElapsedTicks;

	void Range(vector<unsigned> &v, unsigned N);
	vector<unsigned> SortOrder;
	Range(SortOrder, TimerCount);
	sort(SortOrder.begin(), SortOrder.end(), LT);

	Log("\n");
	Log("Ticks/sec %s\n", FloatToStr(ElapsedTicks/ElapsedSecs));
	Log("                            What           N       Ticks        Secs      Pct\n");
	Log("--------------------------------  ----------  ----------  ----------  -------\n");

	double TotalPct = 0;
	for (unsigned k = 0; k < TimerCount; ++k)
		{
		unsigned i = SortOrder[k];
		double N = g_TotalCounts[i];
		if (N == 0)
			continue;
		const char *Name = TimerToStr((TIMER) i);
		double Ticks = g_TotalTicks[i];
		double f = Pct(Ticks, ElapsedTicks);
		TotalPct += f;
		Log("%32.32s  %10s  %10.2g  %10.10s  %7.1f%%\n",
		  Name,
		  FloatToStr(N),
		  Ticks,
		  SecsToStr(Ticks*TicksToSecs),
		  f);
		}
	Log("--------------------------------              ----------     -------\n");
	Log("                %16.16s              %10.2g  %10.10s  %7.1f%%\n",
	  "Total",
	  ElapsedTicks,
	  SecsToStr(ElapsedTicks*TicksToSecs),
	  TotalPct);
	}

void LogMemStats()
	{
	//g_LogStatsDone = true;
	//double FinalMem = GetMemUseBytes();

	//Log("\n");
	//Log("LogMemStats()\n");
	//Log("                            What       Bytes      Pct\n");
	//Log("--------------------------------  ----------  -------\n");

	//double TotalPct = 0;
	//for (map<string, double>::const_iterator p = g_TotalBytes.begin();
	//  p != g_TotalBytes.end(); ++p)
	//	{
	//	const string &Name = p->first;
	//	double Bytes = p->second;
	//	double f = Pct(Bytes, FinalMem);
	//	TotalPct += f;
	//	Log("%32.32s  %10.10s  %7.1f%%\n",
	//	  Name.c_str(),
	//	  MemBytesToStr(Bytes),
	//	  f);
	//	}
	//Log("--------------------------------              -------\n");
	//Log("                %16.16s              %7.1f%%\n",  "Total", TotalPct);
	}

#else	// if TIMING

void LogTickStats()
	{
	}

void LogMemStats()
	{
	}

void LogCounters()
	{
	}

#endif	// if TIMING

void LogStats()
	{
	LogCounters();
	LogMemStats();
	LogTickStats();
	}
