#include "pwa.h"

#define TRACE		0

double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path);

char *g_PathBegin;
char *g_PathBack;
static unsigned g_PathSize;

void AllocPath(unsigned LA, unsigned LB)
	{
	if (LA+LB < g_PathSize)
		return;

	myfree(g_PathBegin);
	g_PathSize = LA+LB+16;
	if (opt_logmemgrows)
		Log("AllocPath(%u,%u) %s bytes\n",
		  LA, LB, IntToStr(g_PathSize));

	g_PathBegin = myalloc<char>(g_PathSize+1);
	g_PathBack = g_PathBegin + g_PathSize;
	*g_PathBack = 0;
	}

void GetLetterCounts(const char *Path, unsigned &NA, unsigned &NB)
	{
	NA = 0;
	NB = 0;
	for (;;)
		{
		char c = *Path++;
		if (c == 0)
			return;
		if (c == 'M' || c == 'D')
			++NA;
		if (c == 'M' || c == 'I')
			++NB;
		}
	}

void GetLetterCounts(const string &Path, unsigned &NA, unsigned &NB)
	{
	return GetLetterCounts(Path.c_str(), NA, NB);
	}

PWA::PWA()
	{
	Clear(true);
	}

void PWA::Clear(bool Ctor)
	{
	if (!Ctor)
		{
		m_HSPs.clear();
		myfree(m_Path);
		}

	m_QueryLabel = 0;
	m_QuerySeq = 0;
	m_QueryLength = 0;

	m_TargetLabel = 0;
	m_TargetSeq = 0;
	m_TargetLength = 0;

	m_QueryCachedInHSPFinder = false;
	m_Path = 0;
	m_PathBufferSize = 0;

	m_CheckFast = false;
	m_CompareFullCount = 0;
	m_AlignNoHSPCount = 0;
	m_PathEqFullCount = 0;
	m_TPPathEqFullCount = 0;
	m_HSPRejectCount = 0;
	m_HSPRejectFPCount = 0;
	m_WrongIdCount = 0;
	m_HitCount = 0;
	m_FPHitCount = 0;
	m_FNHitCount = 0;
	m_BadHSPCount = 0;

#if	TIMING
	m_TotalExactTicks = 0;
	m_TotalHeuristicTicks = 0;
#endif
	}

void PWA::Init(unsigned HSPFinderWordLength)
	{
	m_HSPFinder.Init(HSPFinderWordLength);
	}

void PWA::AllocPath()
	{
	unsigned BufferSize = m_TargetLength + m_QueryLength;
	if (BufferSize <= m_PathBufferSize)
		return;
	myfree(m_Path);
	m_PathBufferSize = BufferSize + 32;
	m_Path = myalloc<char>(m_PathBufferSize);
	}

void PWA::SetQuery(const char *QueryLabel, const byte *QuerySeq,
  unsigned QueryLength)
	{
	m_QueryLabel = QueryLabel;
	m_QuerySeq = QuerySeq;
	m_QueryLength = QueryLength;
	m_QueryCachedInHSPFinder = false;
	}

void PWA::SetTarget(const char *TargetLabel, const byte *TargetSeq,
  unsigned TargetLength)
	{
	m_TargetLabel = TargetLabel;
	m_TargetSeq = TargetSeq;
	m_TargetLength = TargetLength;
	}

void PWA::SetQueryForHSPFinder()
	{
	if (m_QueryCachedInHSPFinder)
		return;

	m_HSPFinder.SetA(m_QueryLabel, m_QuerySeq, m_QueryLength);
	m_QueryCachedInHSPFinder = true;
	}

const char *PWA::AlignNoHSPs(const AlnParams &AP, unsigned BandWidth)
	{
	SegPair SP;

	SP.LabelA = m_QueryLabel;
	SP.LabelB = m_TargetLabel;

	SP.A = m_QuerySeq;
	SP.B = m_TargetSeq;

	SP.LoA = 0;
	SP.LoB = 0;

	SP.LA = m_QueryLength;
	SP.LB = m_TargetLength;

	SP.SA = m_QueryLength;
	SP.SB = m_TargetLength;

	const char *Path;
	if (BandWidth == 0)
		{
		Path = ViterbiFast(SP, AP);
#if	TRACE
		Log("ViterbiFast\n");
		Log("%s\n", Path);
		LogAln(SP, Path);
#endif
		}
	else
		{
		Path = ViterbiFastMainDiag(SP, AP, BandWidth);
#if	TRACE
		Log("ViterbiFastMainDiag\n");
		Log("%s\n", Path);
		LogAln(SP, Path);
#endif
		}
#if	DEBUG
	{
	unsigned NA, NB;
	void GetLetterCounts(const char *Path, unsigned &NA, unsigned &NB);
	GetLetterCounts(Path, NA, NB);
	asserta(NA == m_QueryLength);
	asserta(NB == m_TargetLength);
	}
#endif
	return Path;
	}

const char *PWA::Align(const AlnParams &AP, const AlnHeuristics &AH)
	{
	IncCounter(PWA_Align);
	if (m_CheckFast)
		{
		AlnHeuristics AHEx;
		AHEx.InitExact();
#if	TIMING
		TICKS t1 = GetClockTicks();
#endif
		const char *PathEx_ = AlignNoCompareFull(AP, AHEx);
#if	TIMING
		m_TotalExactTicks += GetClockTicks() - t1;
#endif
		char *PathEx = mystrsave(PathEx_);
		m_HSPs.clear();
#if	TIMING
		TICKS t2 = GetClockTicks();
#endif
		const char *Path = AlignNoCompareFull(AP, AH);
#if	TIMING
		m_TotalHeuristicTicks += GetClockTicks() - t2;
#endif

		CompareFull(Path, PathEx, m_HSPs);

		myfree(PathEx);
		return Path;
		}
	return AlignNoCompareFull(AP, AH);
	}

const char *PWA::AlignNoCompareFull(const AlnParams &AP, const AlnHeuristics &AH)
	{
#if	TRACE
	Log("\n");
	Log("PWA::AlignNoCompareFull");
	Log("AP=");
	AP.LogMe();
	Log("AH=");
	AH.LogMe();
#endif

	AllocPath();

	if (AH.MinHSPLength == 0)
		return AlignNoHSPs(AP, AH.BandWidth);

	SetQueryForHSPFinder();
	m_HSPFinder.SetB(m_TargetLabel, m_TargetSeq, m_TargetLength);
	double HSPId = m_HSPFinder.GetHSPs(m_HSPs);
	if (!m_HSPs.empty() && AH.MinHSPFractId > 0 && HSPId < AH.MinHSPFractId)
		return 0;

	const unsigned HSPCount = SIZE(m_HSPs);
	if (HSPCount == 0)
		return AlignNoHSPs(AP, AH.BandWidth);

#if	TRACE
	Log("LA=%u LB=%u %u HSPs\n", m_QueryLength, m_TargetLength, HSPCount);
	Log("  Seg      i    Alo    Blo     SA     SB    %%Id\n");
	Log("-----  -----  -----  -----  -----  -----  -----\n");
	string Annot;
	double SPPctId;
#endif

	StartTimer(PWA_AlignNCF);
	char *PathPtr = m_Path;
	for (unsigned i = 0; i < HSPCount; ++i)
		{
		const HSPData *PrevHSP = (i == 0 ? 0 : &m_HSPs[i-1]);
		const HSPData *HSP = &m_HSPs[i];

	// Align region before HSP
		SegPair SP;
		GetSP(PrevHSP, HSP, SP);
#if	TRACE
		char *SPPath = PathPtr;
#endif
		PauseTimer(PWA_AlignNCF);
		PathPtr = AlignSP(SP, AP, AH, PathPtr);
		StartTimer(PWA_AlignNCF);
#if	TRACE
		{
		*PathPtr = 0;
		double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path);
		SPPctId = GetFractIdGivenPath(SP.A + SP.LoA, SP.B + SP.LoB, SPPath)*100.0;
		unsigned K = (unsigned) strlen(SPPath);
		for (unsigned k = 0; k < K; ++k)
			Annot.push_back('s');
		}
#endif

	// Trivial path for HSP
		memset(PathPtr, 'M', HSP->Length);
		PathPtr += HSP->Length;

#if	TRACE
		{
		char c = '1' + (i%10);
		for (unsigned k = 0; k < HSP->Length; ++k)
			Annot.push_back(c);

		Log("%5.5s", "s");
		Log("  %5u", i);
		Log("  %5u", SP.LoA);
		Log("  %5u", SP.LoB);
		Log("  %5u", SP.SA);
		Log("  %5u", SP.SB);
		Log("  %4.0f%%", SPPctId);
		Log("\n");

		Log("%5.5s", "H");
		Log("  %5u", i);
		Log("  %5u", HSP->Alo);
		Log("  %5u", HSP->Blo);
		Log("  %5u", HSP->Length);
		Log("  %5.5s", "=");
		Log("  %4.0f%%", Pct(HSP->SameCount, HSP->Length));
		Log("\n");
		}
#endif
		}

#if	TRACE
	char *SPPath = PathPtr;
#endif
	SegPair SP;
	GetSP(&m_HSPs[HSPCount-1], 0, SP);
	PauseTimer(PWA_AlignNCF);
	PathPtr = AlignSP(SP, AP, AH, PathPtr);
	StartTimer(PWA_AlignNCF);
	*PathPtr = 0;

#if TRACE
	{
	unsigned K = (unsigned) strlen(SPPath);
	for (unsigned k = 0; k < K; ++k)
		Annot.push_back('s');
	double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path);
	SPPctId = GetFractIdGivenPath(SP.A + SP.LoA, SP.B + SP.LoB, SPPath)*100.0;
	Log("%5.5s", "s");
	Log("  %5u", HSPCount);
	Log("  %5u", SP.LoA);
	Log("  %5u", SP.LoB);
	Log("  %5u", SP.SA);
	Log("  %5u", SP.SB);
	Log("  %4.0f%%", SPPctId);
	Log("\n");
	}
#endif

#if	DEBUG
	{
	unsigned NA, NB;
	void GetLetterCounts(const char *Path, unsigned &NA, unsigned &NB);
	GetLetterCounts(m_Path, NA, NB);
	asserta(NA == m_QueryLength);
	asserta(NB == m_TargetLength);
	}
#endif
#if	TRACE
	Log("\n");
	Log("FINAL:\n");
	Log("%s\n", Annot.c_str());
	LogAln(m_QuerySeq, m_TargetSeq, m_Path);
	Log("\n");
#endif
	EndTimer(PWA_AlignNCF);
	return m_Path;
	}

void PWA::GetSP(const HSPData *HSP1, const HSPData *HSP2, SegPair &SP)
	{
	SP.LabelA = m_QueryLabel;
	SP.LabelB = m_TargetLabel;

	SP.LA = m_QueryLength;
	SP.LB = m_TargetLength;

	SP.A = m_QuerySeq;
	SP.B = m_TargetSeq;

	SP.LoA = 0;
	SP.LoB = 0;
	if (HSP1 != 0)
		{
		SP.LoA = HSP1->GetAhi() + 1;
		SP.LoB = HSP1->GetBhi() + 1;
		}

	unsigned EndA = 0;
	unsigned EndB = 0;
	if (HSP2 == 0)
		{
		EndA = m_QueryLength;
		EndB = m_TargetLength;
		}
	else
		{
		EndA = HSP2->Alo;
		EndB = HSP2->Blo;
		}

	if (EndA > SP.LoA)
		SP.SA = EndA - SP.LoA;
	else
		SP.SA = 0;

	if (EndB > SP.LoB)
		SP.SB = EndB - SP.LoB;
	else
		SP.SB = 0;
	}

char *PWA::AlignSP(const SegPair &SP, const AlnParams &AP,
  const AlnHeuristics &AH, char *PathPtr)
	{
	StartTimer(PWA_AlignSP);
	if (SP.SA == 0)
		{
		for (unsigned i = 0; i < SP.SB; ++i)
			*PathPtr++ = 'I';
		EndTimer(PWA_AlignSP);
		return PathPtr;
		}

	if (SP.SB == 0)
		{
		for (unsigned i = 0; i < SP.SA; ++i)
			*PathPtr++ = 'D';
		EndTimer(PWA_AlignSP);
		return PathPtr;
		}

	const AlnParams *ptrAP = &AP;
	AlnParams MyAP;
	if (SP.IsFrag())
		{
		MyAP.Init(AP, SP);
		ptrAP = &MyAP;
		}

	PauseTimer(PWA_AlignSP);
	const char *Path;
	if (AH.BandWidth == 0)
		Path = ViterbiFast(SP, *ptrAP);
	else
		Path = ViterbiFastMainDiag(SP, *ptrAP, AH.BandWidth);
	StartTimer(PWA_AlignSP);

	for (const char *p = Path; *p; )
		*PathPtr++ = *p++;

	EndTimer(PWA_AlignSP);
	return PathPtr;
	}

void PWA::CompareFull(const char *Path, const char *PathEx,
  const vector<HSPData> &HSPs)
	{
	++m_CompareFullCount;

	double FractIdEx = GetFractIdGivenPath(m_QuerySeq, m_TargetSeq, PathEx);
	if (FractIdEx >= opt_id)
		++m_HitCount;

	if (HSPs.empty())
		++m_AlignNoHSPCount;

	if (Path == 0)
		{
	// Yuck. Fragile assumption: no path = HSP has low id.
		++m_HSPRejectCount;
		double FractIdEx = GetFractIdGivenPath(m_QuerySeq, m_TargetSeq, PathEx);
		if (FractIdEx >= opt_id)
			m_HSPRejectFPCount;
		return;
		}

	bool BadHSP = false;
	const unsigned HSPCount = SIZE(HSPs);
	for (unsigned i = 0; i < HSPCount; ++i)
		{
		if (!HSPFinder::HSPInPath(HSPs[i], PathEx))
			{
			BadHSP = true;
			if (opt_logbadhsps)
				LogBadHSP(HSPs[i], PathEx);
			++m_BadHSPCount;
			break;
			}
		}

	double FractId = GetFractIdGivenPath(m_QuerySeq, m_TargetSeq, Path);

	bool PathEq = (strcmp(Path, PathEx) == 0);
	if (PathEq)
		{
		++m_PathEqFullCount;
		if (FractIdEx >= opt_id)
			++m_TPPathEqFullCount;
		}

	if (Pct(fabs(FractId - FractIdEx), FractIdEx) > 1.0)
		++m_WrongIdCount;

	if (FractId >= opt_id && FractIdEx < opt_id)
		++m_FPHitCount;

	if (FractId < opt_id && FractIdEx >= opt_id)
		++m_FNHitCount;
	}

void PWA::LogStats() const
	{
#if	TIMING
	double Speedup = double(m_TotalExactTicks)/double(m_TotalHeuristicTicks);
#endif
	const unsigned N = m_CompareFullCount;
	
	Log("\n");
	Log("Pair-wise alignment statistics\n");
#define f(y)	y, Pct(y, N)
	Log("%10u  Alignments\n", N);
	Log("%10u  Hits (%.1f%%)\n", f(m_HitCount));
	Log("%10u  Fast alignments same as slow (hits) (%.1f%%)\n", m_TPPathEqFullCount, Pct(m_TPPathEqFullCount, m_HitCount));
	Log("%10u  Fast alignments same as slow (all) (%.1f%%)\n", f(m_PathEqFullCount));
	Log("%10u  No HSPs found (%.1f%%)\n", f(m_AlignNoHSPCount));
	Log("%10u  Alignments with HSPs not in slow (%.1f%%)\n", f(m_BadHSPCount));
	Log("%10u  Rejected by low HSP id (%.1f%%), %u are FPs (%.1f%%), %u are FNs (%.1f%%)\n", f(m_HSPRejectCount), f(m_HSPRejectFPCount));
	Log("%10u  Heuristic %%id > 1%% error vs. slow (%.1f%%)\n", f(m_WrongIdCount));
	Log("%10u  Heuristic false-positive hits (%.1f%%)\n", f(m_FPHitCount));
	Log("%10u  Heuristic false-negative hits (%.1f%%)\n", f(m_FNHitCount));
#if	TIMING
	Log("%10.3g  CPU time for slow alignments\n", double(m_TotalExactTicks));
	Log("%10.3g  CPU time for fast alignments\n", double(m_TotalHeuristicTicks));
	Log("%10.1f  Alignment time speedup by using heuristics\n", Speedup);
#endif
	}

void PWA::LogBadHSP(const HSPData &HSP, const char *Path) const
	{
	Log("\n");
	Log("Bad HSP\n");
	Log("Query  >%s\n", m_QueryLabel);
	Log("Target >%s\n", m_TargetLabel);
	Log("HSP Q %5u-%5u  %*.*s\n", HSP.Alo, HSP.GetAhi(), HSP.Length, HSP.Length, m_QuerySeq + HSP.Alo);
	Log("HSP T %5u-%5u  %*.*s\n", HSP.Blo, HSP.GetBhi(), HSP.Length, HSP.Length, m_TargetSeq + HSP.Blo);

	const byte *A = m_QuerySeq;
	const byte *B = m_TargetSeq;
	unsigned p = 0;
	for (unsigned i = 0; ; ++i)
		{
		char c = Path[i];
		if (c == 0)
			break;
		if (c == 'M' || c == 'D')
			Log("%c", A[p++]);
		else
			Log("-");
		}
	Log("\n");

	unsigned pa = 0;
	unsigned pb = 0;
	for (unsigned i = 0; ; ++i)
		{
		char c = Path[i];
		if (c == 0)
			break;
		if (c == 'M')
			{
			if (toupper(A[pa]) == toupper(B[pb]))
				Log("|");
			else
				Log(" ");
			}
		else
			Log(" ");
		if (c == 'M' || c == 'D')
			++pa;
		if (c == 'M' || c == 'I')
			++pb;
		}
	Log("\n");

	p = 0;
	for (unsigned i = 0; ; ++i)
		{
		char c = Path[i];
		if (c == 0)
			break;
		if (c == 'M' || c == 'I')
			Log("%c", B[p++]);
		else
			Log("-");
		}
	Log("\n");
	}
