#ifndef hit_h
#define hit_h

unsigned GetCompressedPathLetterCounts(const string &CompressedPath,
  unsigned &M, unsigned &D, unsigned &I);

struct HitData
	{
	const char *QueryLabel;
	const byte *QuerySeq;
	unsigned QueryLo;
	unsigned QueryLength;

	const char *SeedLabel;
	const byte *SeedSeq;
	unsigned SeedLo;
	unsigned SeedLength;

	char Strand;
	unsigned SeedIndex;
	bool Global;
	double FractId;

	string Path;

	void Clear(bool ctor = false)
		{
		QueryLabel = 0;
		QuerySeq = 0;
		QueryLo = UINT_MAX;
		QueryLength = UINT_MAX;
		SeedLabel = 0;
		SeedSeq = 0;
		SeedLo = UINT_MAX;
		Strand = '.';
		SeedLength = UINT_MAX;
		SeedIndex = UINT_MAX;
		Global = true;
		Path.clear();
		FractId = -999.0;
		}

	unsigned GetLength() const
		{
		unsigned M, D, I;
		return GetCompressedPathLetterCounts(Path, M, D, I);
		}

	void LogMe() const
		{
		Log("Query %s, Lo=%u L=%u, Seed=%s, Lo=%u L=%u\n",
		  QueryLabel,
		  QueryLo,
		  QueryLength,
		  SeedLabel,
		  SeedLo,
		  SeedLength);
		}
	};

#endif // hit_h
