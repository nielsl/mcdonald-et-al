#include "myutils.h"
#include "uc.h"
#include <algorithm>
#include <map>
#include <set>

/***
	1. RecType
		L=Lib seed
		S=New seed
		H=Hit
		D=Lib cluster
		C=New cluster
		N=Not matched
		R=Reject

	2. ClusterNr
	3. Size			Seq length or cluster size
	4. PctId
	5. Strand		+ - .
	6. QueryStart	0-based position in query of alignment start
					If RecType=D or C, QueryStart is cluster size.
	7. SeedStart	0-based position in seed of alignment start
					If minus strand, relative to start of rev-comped seed.
	8. Alignment
	9. Label
***/

void Range(vector<unsigned> &v, unsigned N);
const char *CompressPath(const string &Path);
void ExpandPath(const char *CP, string &Path);
void GetPathLetterCounts(const string &Path, unsigned &M, unsigned &D, unsigned &I);
void GetLetterCounts(const string &Path, unsigned &NA, unsigned &NB);
void GetCompressedPathLetterCounts(const char *CP,
  unsigned &ACount, unsigned &BCount);

extern bool g_IsNucleo;

static UCFile *g_UCF;

static bool LT(unsigned i, unsigned j)
	{
	unsigned SeedIndexi = g_UCF->m_SeedIndexes[i];
	unsigned SeedIndexj = g_UCF->m_SeedIndexes[j];
	if (SeedIndexi != SeedIndexj)
		return SeedIndexi < SeedIndexj;

	char Typei = g_UCF->m_RecTypes[i];
	char Typej = g_UCF->m_RecTypes[j];
	if (Typei != Typej)
		return Typei > Typej;

	return g_UCF->m_PctIds[i] < g_UCF->m_PctIds[j];
	}

UCFile::UCFile()
	{
	Clear(true);
	}

void UCFile::Clear(bool ctor)
	{
	if (!ctor)
		{
		if (m_File != 0)
			CloseStdioFile(m_File);
		myfree(m_Data);
		}

	m_File = 0;
	m_Data = 0;
	m_Labels.clear();
	m_SeedIndexes.clear();
	m_CompressedPaths.clear();
	}

void UCFile::Create(const string &FileName)
	{
	m_File = CreateStdioFile(FileName);

	string CmdLine;
	GetCmdLine(CmdLine);
	fprintf(m_File, "# %s\n", CmdLine.c_str());
	fprintf(m_File, "# version=1.1.%s\n", SVN_VERSION);
	fprintf(m_File, "# Tab-separated fields:\n");
	fprintf(m_File, "# 1=Type, 2=ClusterNr, 3=SeqLength or ClusterSize, 4=PctId, 5=Strand, 6=QueryStart, 7=SeedStart, 8=Alignment, 9=QueryLabel, 10=TargetLabel\n");
	fprintf(m_File, "# Record types (field 1): L=LibSeed, S=NewSeed, H=Hit, R=Reject, D=LibCluster, C=NewCluster, N=NoHit\n");
	fprintf(m_File, "# For C and D types, PctId is average id with seed.\n");
	fprintf(m_File, "# QueryStart and SeedStart are zero-based relative to start of sequence.\n");
	fprintf(m_File, "# If minus strand, SeedStart is relative to reverse-complemented seed.\n");
	}

static void LogLine(const char *pLine, char *Fields[9], unsigned FieldCount)
	{
	Log("\n");
	if (pLine == 0)
		{
		Log("pLine=NULL\n");
		return;
		}
	Log("Line=<0>", pLine);
	unsigned n = 0;
	for (const char *p = pLine; n <= FieldCount; ++p)
		{
		if (*p == 0)
			Log("<%u> ", ++n);
		else
			Log("%c", *p);
		}

	Log("\n");
	Log("Fields:\n");
	for (unsigned i = 0; i < FieldCount; ++i)
		Log("[%u]='%s'\n", i, Fields[i]);
	}

void UCFile::FromFile(const string &FileName)
	{
	Clear();

	m_File = OpenStdioFile(FileName);

	Progress("Reading %s\n", FileName.c_str());

	unsigned FileSize;
	off_t otFileSize;
	m_Data = ReadAllStdioFile(FileName, otFileSize);
	FileSize = (unsigned) otFileSize;
	if ((off_t) FileSize != otFileSize)
		Die("UCFile::FromFile, off_t overflow");

	Progress("%s bytes read", IntToStr(FileSize));

	const unsigned FIELD_COUNT = 10;
	char *Fields[FIELD_COUNT];

	char *pEnd = (char *) m_Data + FileSize;
	char *pData = (char *) m_Data;
	char *pLine = 0;
	unsigned LineNr = 0;
	set<char> UnknownRecTypes;
	for (;;)
		{
		if (pData >= pEnd)
			break;

		ProgressStep(unsigned(pData - (char *) m_Data), FileSize, "Parsing");

		++LineNr;
		pLine = pData;
		if (*pData == '#')
			{
			while (pData < pEnd)
				if (*pData++ == '\n')
					break;
			continue;
			}

		unsigned FieldCount = 0;
		Fields[0] = pData;
		for (;;)
			{
			if (pData >= pEnd)
				break;
			char c = *pData++;
			if (c == '\t')
				{
				if (FieldCount < FIELD_COUNT-1)
					{
					pData[-1] = 0;
					Fields[++FieldCount] = pData;
					}
				}
			else if (c == '\n')
				{
				pData[-1] = 0;
				break;
				}
			}

		if (FieldCount != FIELD_COUNT-1)
			{
			LogLine(pLine, Fields, FieldCount);
			Die("Error in '%s', line %u: not enough fields",
			  FileName.c_str(), LineNr);
			}

		if (strlen(Fields[0]) != 1)
			{
			LogLine(pLine, Fields, FieldCount);
			Die("Error in '%s', line %u: type '%s'",
			  FileName.c_str(), LineNr, Fields[0]);
			}
		if (strlen(Fields[4]) != 1)
			{
			LogLine(pLine, Fields, FieldCount);
			Die("Error in '%s', line %u: strand '%s'",
			  FileName.c_str(), LineNr, Fields[4]);
			}

		m_RecTypes.push_back(Fields[0][0]);
		m_SeedIndexes.push_back(atoi(Fields[1]));
		m_SeqLengths.push_back(atoi(Fields[2]));
		m_PctIds.push_back((float) atof(Fields[3]));
		m_Strands.push_back(Fields[4][0]);
		m_Los.push_back(atoi(Fields[5]));
		m_SeedLos.push_back(atoi(Fields[6]));
		m_CompressedPaths.push_back(Fields[7]);
		m_Labels.push_back(Fields[8]);
		m_SeedLabels.push_back(Fields[9]);
		}

	ProgressStep(FileSize - 1, FileSize, "Parsing done");

	Sort();
	}

void UCFile::Sort()
	{
	if (!m_SortOrder.empty())
		return;

	g_UCF = this;
	unsigned RecordCount = GetRecordCount();
	Range(m_SortOrder, RecordCount);
	Progress("Sorting\n");
	sort(m_SortOrder.begin(), m_SortOrder.end(), LT);
	Progress("Sorting done\n");
	}

unsigned UCFile::GetRecordCount() const
	{
	return SIZE(m_Labels);
	}

void UCFile::LogMe() const
	{
	unsigned RecordCount = GetRecordCount();
	Log("\n");
	Log("Type  Cluster     Size    PctId   Label (Path)\n");
	Log("----  -------  -------  -------  ------------\n");
	for (unsigned k = 0; k < RecordCount; ++k)
		{
		unsigned i = m_SortOrder[k];
		Log("%4c", m_RecTypes[i]);
		Log("  %7u  ", m_SeedIndexes[i]);
		Log("  %7u", m_SeqLengths[i]);
		if (m_CompressedPaths[i] == 0)
			Log("%7.7s  %s\n", "*", m_Labels[i]);
		else
			Log("%7.1f  %s (%s)\n",
			  m_PctIds[i], m_Labels[i], m_CompressedPaths[i]);
		}
	}

//>Cluster 0
//0       323nt, >KIRN_9A_80438... *
//>Cluster 2
//0       318nt, >KIRN_17A_45293... *
//1       307nt, >PCx423_192715... at +/90%

void UCFile::ToClstr(const string &FileName)
	{
	FILE *f = CreateStdioFile(FileName);

	unsigned RecordCount = GetRecordCount();
	unsigned Index = 0;
	for (unsigned k = 0; k < RecordCount; ++k)
		{
		ProgressStep(k, RecordCount, "Writing %s", FileName.c_str());
		unsigned i = m_SortOrder[k];
		char Type = m_RecTypes[i];
		bool IsSeed = (Type == 'S' || Type == 'L');
		bool IsHit = (Type == 'H');
		if (!IsSeed && !IsHit)
			continue;
		if (IsSeed)
			{
			fprintf(f, ">Cluster %u\n", m_SeedIndexes[i]);
			Index = 0;
			}
		fprintf(f, "%-8u", Index++);
		fprintf(f, "%u", m_SeqLengths[i]);
		char Strand = m_Strands[i];
		if (Strand == '.')
			fprintf(f, "aa, ");
		else
			fprintf(f, "nt, ");

		fprintf(f, ">%s...", m_Labels[i]);
		if (IsSeed)
			fprintf(f, " *");
		else
			{
			if (Strand == '.')
				fprintf(f, " at %.0f%%", m_PctIds[i]);
			else
				fprintf(f, " at %c/%.0f%%", Strand, m_PctIds[i]);
			}
		fprintf(f, "\n");
		}
	CloseStdioFile(f);
	}

void UCFile::WriteNotMatched(unsigned L, const char *Label) const
	{
	if (m_File == 0)
		return;
	fprintf(m_File, "N\t*\t%u\t*\t*\t*\t*\t*\t%s\t*\n", L, Label);
	              // 1  2   3  4  5  6  7  8   9
	}

void UCFile::WriteLibSeed(unsigned SeedIndex, unsigned L, const char *Label) const
	{
	if (m_File == 0)
		return;

	fprintf(m_File, "L\t%u\t%u\t*\t*\t*\t*\t*\t%s\t*\n", SeedIndex, L, Label);
	              // 1   2   3  4  5  6  7  8   9
	}

void UCFile::WriteNewSeed(unsigned SeedIndex, unsigned L, const char *Label) const
	{
	if (m_File == 0)
		return;

	fprintf(m_File, "S\t%u\t%u\t*\t*\t*\t*\t*\t%s\t*\n", SeedIndex, L, Label);
	              // 1   2   3  4  5  6  7  8   9
	}

void UCFile::WriteLibCluster(unsigned SeedIndex, unsigned Size, double AvgId,
  const char *Label) const
	{
	if (m_File == 0)
		return;

	if (Size <= 1)
		return;

	fprintf(m_File, "D\t%u\t%u\t*\t*\t*\t*\t%.1f\t%s\t*\n", SeedIndex, Size, 100*AvgId, Label);
			          // 1   2   3  4  5  6  7     8   9
	}

void UCFile::WriteNewCluster(unsigned SeedIndex, unsigned Size, double AvgId,
  const char *Label) const
	{
	if (m_File == 0)
		return;

	if (Size > 1)
		fprintf(m_File, "C\t%u\t%u\t%.1f\t*\t*\t*\t*\t%s\t*\n", SeedIndex, Size, 100*AvgId, Label);
			          // 1   2   3     4  5  6  7  8   9
	else
		fprintf(m_File, "C\t%u\t%u\t*\t*\t*\t*\t*\t%s\t*\n", SeedIndex, Size, Label);
			          // 1   2   3  4  5  6  7  8   9
	}

void UCFile::WriteHit(const HitData &Hit) const
	{
	if (m_File == 0)
		return;

#if	DEBUG
	{
	unsigned NA, NB;
	GetLetterCounts(Hit.Path, NA, NB);
	assert(Hit.QueryLo + NA <= Hit.QueryLength);
	assert(Hit.SeedLo + NB <= Hit.SeedLength);
	}
#endif

	const char *CP = "?";

	if (!Hit.Path.empty())
		{
		CP = CompressPath(Hit.Path);
#if	DEBUG
		if (Hit.Path[0] != '(')
			{
			unsigned NA1, NA2, NB1, NB2;
			GetLetterCounts(Hit.Path, NA1, NB1);
			GetCompressedPathLetterCounts(CP, NA2, NB2);
			assert(NA1 == NA2);
			assert(NB1 == NB2);
			}
#endif
		}

	char cType = Hit.FractId >= opt_id ? 'H' : 'R';

	fprintf(m_File, "%c\t%u\t%u\t%.1f\t%c\t%u\t%u\t%s\t%s\t%s\n",
		          //  1   2   3     4   5   6   7   8   9
      cType,
	  Hit.SeedIndex,
	  Hit.QueryLength,
	  Hit.FractId*100.0,
	  Hit.Strand,
	  Hit.QueryLo,
	  Hit.SeedLo,
	  CP,
	  Hit.QueryLabel,
	  Hit.SeedLabel);
	}

void UCFile::WriteHit(unsigned SeedIndex, unsigned L, double PctId,
  const char *CP, char Strand, unsigned Lo, unsigned SeedLo,
  const char *Label, const char *SeedLabel) const
	{
	if (m_File == 0)
		return;

	fprintf(m_File, "H\t%u\t%u\t%.1f\t%c\t%u\t%u\t%s\t%s\t%s\n",
		          // 1   2   3     4   5   6   7   8   9
	  SeedIndex,
	  L,
	  PctId,
	  Strand,
	  Lo,
	  SeedLo,
	  CP,
	  Label,
	  SeedLabel);
	}

void UCFile::ToFile(const string &FileName)
	{
	Create(FileName);

	unsigned RecordCount = GetRecordCount();
	unsigned Index = 0;
	for (unsigned i = 0; i < RecordCount; ++i)
		{
		ProgressStep(i, RecordCount, "Writing %s", FileName.c_str());

		unsigned k = m_SortOrder[i];
		float PctId = m_PctIds[k];
		switch (m_RecTypes[k])
			{
		case 'L':
			WriteLibSeed(m_SeedIndexes[k], m_SeqLengths[k], m_Labels[k]);
			break;

		case 'S':
			WriteNewSeed(m_SeedIndexes[k], m_SeqLengths[k], m_Labels[k]);
			break;

		case 'N':
			WriteNotMatched(m_SeqLengths[k], m_Labels[k]);
			break;

		case 'H':
			WriteHit(m_SeedIndexes[k], m_SeqLengths[k], m_PctIds[k],
			  m_CompressedPaths[k], m_Strands[k], m_Los[k], m_SeedLos[k],
			  m_Labels[k], m_SeedLabels[k]);
			break;

		case 'D':
			WriteLibCluster(m_SeedIndexes[k], m_SeqLengths[k], m_PctIds[k], m_Labels[k]);
			break;

		case 'C':
			WriteNewCluster(m_SeedIndexes[k], m_SeqLengths[k], m_PctIds[k], m_Labels[k]);
			break;

		default:
			Die("UCFile::ToFile, Invalid rec type '%c'", m_RecTypes[k]);
			}
		}

	CloseStdioFile(m_File);
	m_File = 0;
	}

void UCFile::ToFasta(const string &FileName, const SeqDB &Input)
	{
	if (opt_types.find('L') != string::npos || opt_types.find('D') != string::npos)
		Die("Invalid --types, L and D not allowed");

	Sort();

	const unsigned SeqCount = Input.GetSeqCount();

	map<string, unsigned> LabelToSeqIndex;
	for (unsigned SeqIndex = 0; SeqIndex < SeqCount; ++SeqIndex)
		{
		ProgressStep(SeqIndex, SeqCount, "Indexing .uc file");
		const string &Label = Input.GetLabel(SeqIndex);
		if (LabelToSeqIndex.find(Label) != LabelToSeqIndex.end())
			Die("Duplicate FASTA label in input '%s'", Label.c_str());
		LabelToSeqIndex[Label] = SeqIndex;
		}

	FILE *f = CreateStdioFile(FileName);

	unsigned ClusterCount = 0;
	const unsigned RecordCount = GetRecordCount();
	unsigned BadLengths = 0;
	for (unsigned i = 0; i < RecordCount; ++i)
		{
		ProgressStep(i, RecordCount, "Writing %s", FileName.c_str());

		unsigned k = m_SortOrder[i];

		char Type = m_RecTypes[k];
		size_t n = opt_types.find(Type);
		if (n == string::npos)
			continue;

		//bool IsSeed = (Type == 'S' || Type == 'L');
		bool IsHit = Type == 'H';
		//if (!IsHit && !IsSeed)
		//	continue;

		const char *Label = m_Labels[k];
		float PctId = m_PctIds[k];
		unsigned SeedIndex = m_SeedIndexes[k];

		if (IsHit)
			fprintf(f, ">%u|%.1f%%|%s\n", SeedIndex, PctId, Label);
		else
			fprintf(f, ">%u|*|%s\n", SeedIndex, Label);

		map<string, unsigned>::const_iterator p = LabelToSeqIndex.find(Label);
		if (p == LabelToSeqIndex.end())
			Die("Label not found (inconsistent use of --trunclabel?) '%s'", Label);

		unsigned SeqIndex = p->second;
		const byte *Seq = Input.GetSeq(SeqIndex);
		const unsigned L = Input.GetSeqLength(SeqIndex);
		const char *CP = m_CompressedPaths[k];
		WriteSeqX(f, Seq, L, CP);
		}

	//if (BadLengths > 0)
	//	Warning("%u seq lengths disagree between .uc and input", BadLengths);

	CloseStdioFile(f);
	}

void UCFile::WriteSeqX(FILE *f, const byte *Seq, unsigned L, const char *CP) const
	{
	if (f == 0)
		return;

	if (CP == 0 || *CP == '?' || *CP == '*' || *CP == '(')
		{
		for (unsigned k = 0; k < L; ++k)
			fputc(toupper(Seq[k]), f);;
		fputc('\n', f);
		return;
		}

	string Path;
	ExpandPath(CP, Path);

	unsigned i = 0;
	for (unsigned k = 0; k < SIZE(Path); ++k)
		{
		char c = Path[k];
		switch (c)
			{
		case 'M':
			fputc(toupper(Seq[i++]), f);
			break;
		case 'I':
			fputc('-', f);
			break;
		case 'D':
			fputc(tolower(Seq[i++]), f);
			break;
		default:
			Die("Invalid state in path %c, compressed %s",
			  c, CP);
			}
		}
	fputc('\n', f);

	if (i != L)
		Die("Seq length %u, compressed L %u %s",
		  L, i, CP);
	}

void UC2Clstr()
	{
	if (opt_uc2clstr == "")
		Die("Missing --uc");
	if (opt_output == "")
		Die("Missing --output");

	UCFile UF;
	UF.FromFile(opt_uc2clstr);
	UF.ToClstr(opt_output);
	}

void Clstr2UC()
	{
	if (opt_clstr2uc == "")
		Die("Missing --clstr2uc");
	if (opt_output == "")
		Die("Missing --output");

	UCFile UF;
	UF.FromClstr(opt_clstr2uc);
	UF.ToFile(opt_output);
	}

void UC2Fasta()
	{
	if (opt_uc2fasta == "")
		Die("Missing --uc");
	if (opt_input == "")
		Die("Missing --input");
	if (opt_output == "")
		Die("Missing --output");

	SeqDB Input;
	Input.FromFasta(opt_input);

	UCFile UF;
	UF.FromFile(opt_uc2fasta);
	UF.ToFasta(opt_output, Input);
	}

void SortUC()
	{
	if (opt_sortuc == "")
		Die("Missing --sortuc");
	if (opt_output == "")
		Die("Missing --output");

	UCFile UC;
	UC.FromFile(opt_sortuc);
	UC.ToFile(opt_output);
	UC.Clear();
	}
