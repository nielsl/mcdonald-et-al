#include "myutils.h"
#include "windex.h"
#include "timing.h"
#include <math.h>

extern unsigned g_AlphaSize;

void Windex::Init(unsigned WordLength)
	{
	m_WordLength = WordLength;
	m_WordCount = 1;
	for (unsigned i = 0; i < m_WordLength; ++i)
		m_WordCount *= g_AlphaSize;
	m_Hi = m_WordCount/g_AlphaSize;

	m_CapacityInc = CapacityInc;

	m_UniqueCounts = myalloc<byte>(m_WordCount);
	zero(m_UniqueCounts, m_WordCount);

	m_Capacities = myalloc<arrsize_t>(m_WordCount);
	m_Sizes = myalloc<arrsize_t>(m_WordCount);
	m_SeedIndexes = myalloc<seqindex_t *>(m_WordCount);

	zero(m_Capacities, m_WordCount);
	zero(m_Sizes, m_WordCount);
	zero(m_SeedIndexes, m_WordCount);
	}

void Windex::LogMe() const
	{
	Log("\n");
	Log("Windex::LogMe() m_WordLength=%u, WordCount=%u\n",
	  m_WordLength, m_WordCount);
	Log("      Word          kmer  Seqs\n");
	Log("----------  ------------  ----\n");
	for (unsigned Word = 0; Word < m_WordCount; ++Word)
		{
		unsigned Size = m_Sizes[Word];
		if (Size == 0)
			continue;
		Log("%10u  %12.12s ", Word, WordToStr(Word));

		for (unsigned k = 0; k < Size; ++k)
			Log(" %u", m_SeedIndexes[Word][k]);
		Log("\n");
		}
	}

void Windex::LogWordStats(unsigned TopWords) const
	{
	Log("\n");
	Log("Windex::LogWordStats()\n");
	Log("Word length %u, nr. words %s\n",
	  m_WordLength, IntToStr(m_WordCount));

	vector<unsigned> Order;

	void SortDescending(const unsigned *Values, unsigned N, vector<unsigned> &Order);
	SortDescending(m_Sizes, m_WordCount, Order);

	double SumCount = 0.0;
	for (unsigned i = 0; i < m_WordCount; ++i)
		SumCount += m_Sizes[i];

	double MaxCount = m_Sizes[Order[0]];
	double MeanCount = SumCount/m_WordCount;
	unsigned MiddleWord = Order[m_WordCount/2];
	double MedianCount = m_Sizes[MiddleWord];
	Log("Total words: %s\n", IntToStr(unsigned(SumCount)));
	Log("Seqs/word: max = %.1f, mean = %.1f, median = %.1f\n",
	  MaxCount, MeanCount, MedianCount);
	Log("\n");
	Log("Top words:\n");
	Log(" Nr. seeds  Word\n");
	Log("----------  ----\n");
	for (unsigned i = 0; i < min(TopWords, m_WordCount); ++i)
		{
		unsigned Word = Order[i];
		unsigned Count = m_Sizes[Word];
		Log("%10u  %s\n", Count, WordToStr(Word));
		}
	}

unsigned Windex::LogMemSize() const
	{
	unsigned NonZeroWordCount = 0;
	unsigned TotalLength = 0;

// Per-word vectors m_Capacities, m_Sizes and m_SeedIndexes.
	unsigned Bytes = m_WordCount*(2*sizeof(arrsize_t) + sizeof(seqindex_t *));
	for (unsigned Word = 0; Word < m_WordCount; ++Word)
		{
		Bytes += m_Capacities[Word]*sizeof(seqindex_t);
		unsigned Size = m_Sizes[Word];
		if (Size == 0)
			continue;
		++NonZeroWordCount;
		TotalLength += Size;
		}
	Log("Windex memory %s bytes\n", IntToStr(Bytes));
	return Bytes;
	}

const char *Windex::WordToStr(word_t Word) const
	{
	extern const char *g_Alpha;

	static char Str[32];
	for (unsigned i = 0; i < m_WordLength; ++i)
		{
		unsigned w = Word%g_AlphaSize;
		Str[m_WordLength-i-1] = g_Alpha[w];
		Word /= g_AlphaSize;
		}
	Str[m_WordLength] = 0;
	return Str;
	}

void Windex::AddWords(unsigned SeqIndex, const word_t *Words, unsigned N)
	{
	StartTimer(AddWords);

	for (unsigned i = 0; i < N; ++i)
		{
		word_t Word = Words[i];
		assert(Word < m_WordCount);

		arrsize_t Size = m_Sizes[Word];
		arrsize_t Capacity = m_Capacities[Word];
		if (Size == Capacity)
			{
			unsigned NewCapacity = unsigned(Capacity*1.5) + m_CapacityInc;
			seqindex_t *NewSeqIndexes = myallocz<seqindex_t>(NewCapacity);
			if (NewSeqIndexes == 0)
				{
				Log("\n");
				LogMemSize();
				Die("Out of memory Windex::AddWords: word=%u=%s Size=%u Cap=%u",
				  Word, WordToStr(Word), Size, Capacity);
				}

			seqcountperword_t *NewSeqCountsPerWord = myalloc<seqcountperword_t>(NewCapacity);
			for (unsigned k = 0; k < Size; ++k)
				NewSeqIndexes[k] = m_SeedIndexes[Word][k];

			myfree(m_SeedIndexes[Word]);
			m_SeedIndexes[Word] = NewSeqIndexes;
			m_Capacities[Word] = NewCapacity;
			}

		m_SeedIndexes[Word][Size] = SeqIndex;
		++(m_Sizes[Word]);
		}

	EndTimer(AddWords);
	}

unsigned Windex::SeqToWordsStep(unsigned Step, const byte *Seq, unsigned L,
  word_t *Words) const
	{
	if (Step == 1)
		return SeqToWords(Seq, L, Words);

	if (L < m_WordLength)
		return 0;
	StartTimer(SeqToWordsStep);

	unsigned WordCount = 0;
	for (unsigned Pos = 0; Pos < L; Pos += Step)
		{
		unsigned Word = SeqToWord(Seq+Pos);
		*Words++ = Word;
		++WordCount;
		}

	EndTimer(SeqToWordsStep);
	return WordCount;
	}

word_t Windex::SeqToWord(const byte *Seq) const
	{
	word_t Word = 0;
	const byte *Front = Seq;
	for (unsigned i = 0; i < m_WordLength; ++i)
		{
		unsigned Letter = CharToLetter[*Front++];
		Word = (Word*g_AlphaSize) + Letter;
		}
	return Word;
	}

unsigned Windex::SeqToWords(const byte *Seq, unsigned L, word_t *Words) const
	{
	if (L < m_WordLength)
		return 0;
	StartTimer(SeqToWords);

	const unsigned WordCount = L - m_WordLength + 1;
	word_t Word = 0;
	const byte *Hi = Seq;
	for (unsigned i = 0; i < m_WordLength-1; ++i)
		{
		unsigned Letter = CharToLetter[*Hi++];
		Word = (Word*g_AlphaSize) + Letter;
		}

	word_t *p = Words;
#if	DEBUG
	unsigned WordCount2 = 0;
#endif
	const byte *Lo = Seq;
	for (unsigned i = m_WordLength-1; i < L; ++i)
		{
		unsigned Letter = CharToLetter[*Hi++];
		Word = (Word*g_AlphaSize) + Letter;
		assert(Word < m_WordCount);
#if	DEBUG
		if (Word != SeqToWord(Seq+i+1-m_WordLength))
			{
			unsigned SWord = SeqToWord(Seq+i+1-m_WordLength);
			Log("SeqToWord(Pos=%u)=%u=%s\n", i+1-m_WordLength, SWord, WordToStr(SWord));
			Die("Word");
			}
#endif

		*p++ = Word;
#if	DEBUG
		++WordCount2;
#endif
		Letter = CharToLetter[*Lo++];
		Word -= Letter*(m_Hi);
		}
	assert(WordCount2 == WordCount);
	EndTimer(SeqToWords);
	return WordCount;
	}

unsigned Windex::WordsToCounts(const word_t *Words, unsigned N,
  word_t *UniqueWords, seqcountperword_t *Counts) const
	{
	unsigned UniqueWordCount = 0;
	for (unsigned i = 0; i < N; ++i)
		{
		unsigned Word = Words[i];
		assert(Word < m_WordCount);
		unsigned Count = m_UniqueCounts[Word];
		if (Count == 0)
			UniqueWords[UniqueWordCount++] = Word;
		m_UniqueCounts[Word] = Count+1;
		}

	for (unsigned i = 0; i < UniqueWordCount; ++i)
		{
		unsigned Word = UniqueWords[i];
		assert(Word < m_WordCount);

		Counts[i] = m_UniqueCounts[Word];
		m_UniqueCounts[Word] = 0;
		}

	return UniqueWordCount;
	}

// TODO: id trick?
unsigned Windex::GetUniqueWords(const word_t *Words, unsigned N,
  word_t *UniqueWords) const
	{
	StartTimer(WX_GetUniqueWords);

	unsigned UniqueWordCount = 0;
	for (unsigned i = 0; i < N; ++i)
		{
		unsigned Word = Words[i];
		assert(Word < m_WordCount);
		unsigned Count = m_UniqueCounts[Word];
		if (Count == 0)
			UniqueWords[UniqueWordCount++] = Word;
		m_UniqueCounts[Word] = Count+1;
		}

	for (unsigned i = 0; i < UniqueWordCount; ++i)
		{
		unsigned Word = UniqueWords[i];
		m_UniqueCounts[Word] = 0;
		}

	EndTimer(WX_GetUniqueWords);
	return UniqueWordCount;
	}
