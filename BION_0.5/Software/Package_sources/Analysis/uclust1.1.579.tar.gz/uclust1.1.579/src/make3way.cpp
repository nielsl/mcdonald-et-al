#include "myutils.h"

void Make3Way(
  const string &LabQ, const byte *Q, unsigned QL,
  const string &LabA, const byte *A, unsigned AL, const string &PathA,
  const string &LabB, const byte *B, unsigned BL, const string &PathB,
  string &Q3, string &A3, string &B3)
	{
#if	DEBUG
	{
	void GetLetterCounts(const string &Path, unsigned &NA, unsigned &NB);
	unsigned NA, NB;
	GetLetterCounts(PathA, NA, NB);
	asserta(NA == QL);
	asserta(NB == AL);

	GetLetterCounts(PathB, NA, NB);
	asserta(NA == QL);
	asserta(NB == BL);
	}
#endif
	Q3.clear();
	A3.clear();
	B3.clear();

	vector<unsigned> InsertCountsA(QL+1, 0);
	unsigned QPos = 0;
	for (unsigned i = 0; i < SIZE(PathA); ++i)
		{
		char c = PathA[i];
		if (c == 'M' || c == 'D')
			++QPos;
		else
			{
			asserta(c == 'I');
			asserta(QPos <= QL);
			++(InsertCountsA[QPos]);
			}
		}

	vector<unsigned> InsertCountsB(QL+1, 0);
	QPos = 0;
	for (unsigned i = 0; i < SIZE(PathB); ++i)
		{
		char c = PathB[i];
		if (c == 'M' || c == 'D')
			++QPos;
		else
			{
			asserta(c == 'I');
			asserta(QPos <= QL);
			++(InsertCountsB[QPos]);
			}
		}

	vector<unsigned> InsertCounts;
	for (unsigned i = 0; i <= QL; ++i)
		{
		unsigned is = max(InsertCountsA[i], InsertCountsB[i]);
		InsertCounts.push_back(is);
		}

	for (unsigned i = 0; i < QL; ++i)
		{
		for (unsigned k = 0; k < InsertCounts[i]; ++k)
			Q3.push_back('-');
		asserta(i < QL);
		Q3.push_back(Q[i]);
		}
	for (unsigned k = 0; k < InsertCounts[QL]; ++k)
		Q3.push_back('-');

// A
	QPos = 0;
	unsigned APos = 0;
	unsigned is = 0;
	for (unsigned i = 0; i < SIZE(PathA); ++i)
		{
		char c = PathA[i];
		if (c == 'M' || c == 'D')
			{
			unsigned isq = InsertCounts[QPos];
			asserta(is <= isq);
			for (unsigned i = 0; i < InsertCounts[QPos]-is; ++i)
				A3.push_back('-');
			is = 0;
			++QPos;
			}
		if (c == 'M')
			{
			asserta(APos < AL);
			A3.push_back(A[APos++]);
			}
		else if (c == 'D')
			A3.push_back('-');
		else if (c == 'I')
			{
			++is;
			asserta(APos < AL);
			A3.push_back(A[APos++]);
			}
		}
	asserta(is <= InsertCounts[QL]);
	for (unsigned k = 0; k < InsertCounts[QL]-is; ++k)
		A3.push_back('-');
	asserta(QPos == QL);
	asserta(APos == AL);

// B
	QPos = 0;
	unsigned BPos = 0;
	is = 0;
	for (unsigned i = 0; i < SIZE(PathB); ++i)
		{
		char c = PathB[i];
		if (c == 'M' || c == 'D')
			{
			asserta(is <= InsertCounts[QPos]);
			for (unsigned i = 0; i < InsertCounts[QPos]-is; ++i)
				B3.push_back('-');
			is = 0;
			++QPos;
			}
		if (c == 'M')
			{
			asserta(BPos < BL);
			B3.push_back(B[BPos++]);
			}
		else if (c == 'D')
			B3.push_back('-');
		else if (c == 'I')
			{
			++is;
			asserta(BPos < BL);
			B3.push_back(B[BPos++]);
			}
		}
	asserta(is <= InsertCounts[QL]);
	for (unsigned k = 0; k < InsertCounts[QL]-is; ++k)
		B3.push_back('-');
	asserta(APos == AL);
	asserta(BPos == BL);

	asserta(SIZE(Q3) == SIZE(A3));
	asserta(SIZE(Q3) == SIZE(B3));
	}
