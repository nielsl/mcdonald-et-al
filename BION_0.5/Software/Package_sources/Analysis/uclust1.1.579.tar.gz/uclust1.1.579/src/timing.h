#ifndef timing_h
#define timing_h

#define TIMING	1

#if TIMING

enum TIMER
	{
	TIMER_None,
#define T(x)	TIMER_##x,
#include "timers.h"
#undef T
	};

const unsigned TimerCount =
	1	// TIMER_None
#define T(x)	+1
#include "timers.h"
#undef T
	;

enum COUNTER
	{
#define C(x)	COUNTER_##x,
#include "counters.h"
#undef C
	};

const unsigned CounterCount =
#define C(x)	+1
#include "counters.h"
#undef C
	;

#ifdef _MSC_VER

typedef unsigned __int64 TICKS;

#pragma warning(disable:4035)
inline TICKS GetClockTicks()
	{
	_asm
		{
		_emit	0x0f
		_emit	0x31
		}
	}

#else	// ifdef _MSC_VER

typedef uint64_t TICKS;
__inline__ uint64_t GetClockTicks()
	{
	uint32_t lo, hi;
	/* We cannot use "=A", since this would use %rax on x86_64 */
	__asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
	return (uint64_t)hi << 32 | lo;
	}

#endif	// ifdef _MSC_VER

//void AddTicks(const string &Name, TICKS Ticks1, TICKS Ticks2);
//void AddBytes(const string &Name, double Bytes);
//#define SubBytes(Name, Bytes)	AddBytes(Name, -double(Bytes))

const char *TimerToStr(TIMER t);

extern TICKS g_BeginTicks[TimerCount];
extern double g_TotalTicks[TimerCount];
extern double g_TotalCounts[TimerCount];
extern double g_Counters[CounterCount];
extern TIMER g_CurrTimer;

inline void StartTimer_(TIMER Timer)
	{
	if (g_CurrTimer != TIMER_None)
		{
		Log("\n");
		Log("Curr timer %s\n", TimerToStr(g_CurrTimer));
		Die("Nested StartTimer(%s)", TimerToStr(Timer));
		}
	g_BeginTicks[Timer] = GetClockTicks();
	g_CurrTimer = Timer;
	}

inline void PauseTimer_(TIMER Timer)
	{
	if (Timer != g_CurrTimer)
		{
		Log("\n");
		Log("Curr timer %s\n", TimerToStr(g_CurrTimer));
		Die("PauseTimer(%s)", TimerToStr(Timer));
		}
	TICKS Now = GetClockTicks();
	g_TotalTicks[Timer] += double(Now - g_BeginTicks[Timer]);
	g_BeginTicks[Timer] = Now;
	g_CurrTimer = TIMER_None;
	}

inline void EndTimer_(TIMER Timer)
	{
	if (Timer != g_CurrTimer)
		{
		Log("\n");
		Log("Curr timer %s\n", TimerToStr(g_CurrTimer));
		Die("EndTimer(%s)", TimerToStr(Timer));
		}

	g_TotalTicks[Timer] += double(GetClockTicks() - g_BeginTicks[Timer]);
	++g_TotalCounts[Timer];
	g_CurrTimer = TIMER_None;
	}

inline void StartTimer2_(TIMER Timer)
	{
	g_BeginTicks[Timer] = GetClockTicks();
	}

inline void EndTimer2_(TIMER Timer)
	{
	g_TotalTicks[Timer] += double(GetClockTicks() - g_BeginTicks[Timer]);
	++g_TotalCounts[Timer];
	}

#define AddCounter(x, N)	g_Counters[COUNTER_##x] += N
#define IncCounter(x)		++(g_Counters[COUNTER_##x])
#define StartTimer(x)		StartTimer_(TIMER_##x)
#define PauseTimer(x)		PauseTimer_(TIMER_##x)
#define EndTimer(x)			EndTimer_(TIMER_##x)
#define StartTimer2(x)		!ERROR!StartTimer2_(TIMER_##x)
#define EndTimer2(x)		!ERROR!EndTimer2_(TIMER_##x)

#else	// if TIMING

#define AddCounter(x, N)	/* empty */
#define IncCounter(x)		/* empty */
#define StartTimer(x)		/* empty */
#define PauseTimer(x)		/* empty */
#define EndTimer(x)			/* empty */
#define StartTimer2(x)		/* empty */
#define PauseTimer2(x)		/* empty */
#define EndTimer2(x)		/* empty */

#endif	// if TIMING

void LogMemStats();
void LogTickStats();
void LogStats();

#define AddBytes(x, n)	/* empty */
#define SubBytes(x, n)	/* empty */

#endif	// if timing_h
