#include "myutils.h"
#include "hit.h"

void GetLetterCounts(const char *Path, unsigned &NA, unsigned &NB);
unsigned Overlap(unsigned StartA, unsigned EndA, unsigned StartB, unsigned EndB);
byte CompLetter(byte c);
bool isgap(char c);
void GetColTypeCounts(const byte *A, const byte *B, const char *Path,
  unsigned &LA, unsigned &LB, unsigned &PairCount, unsigned &SameCount,
  unsigned &InternalGapCount, unsigned &TerminalGapCount);

extern float **g_SubstMx;

static char g_IdChar = '|';
static char g_DiffChar = ' ';

char ProbStrengthSymbol(float Prob)
	{
	if (Prob > 0.9)
		return '*';
	else if (Prob > 0.75)
		return '|';
	else if (Prob > 0.5)
		return ':';
	else if (Prob > 0.25)
		return '.';
	return ' ';
	}

char MatchStrengthSymbolNucleo(byte Letter1, byte Letter2)
	{
	if (isgap(Letter1) || isgap(Letter2))
		return ' ';
	Letter1 = toupper(Letter1);
	Letter2 = toupper(Letter2);
	if (Letter1 == Letter2)
		return g_IdChar;
	return g_DiffChar;
	}

char MatchStrengthSymbolAmino(byte Letter1, byte Letter2)
	{
	if (isgap(Letter1) || isgap(Letter2))
		return ' ';
	Letter1 = toupper(Letter1);
	Letter2 = toupper(Letter2);
	if (Letter1 == Letter2)
		return Letter1;

	float Score = g_SubstMx[Letter1][Letter2];
	if (Score > 0.2)
		return '+';
	else if (Score > -0.5)
		return ' ';
	return '?';
	}

static void GetSimStrNucleo(const string &a, const string &b, string &s)
	{
	s.clear();
	const unsigned L = SIZE(a);
	asserta(SIZE(b) == L);
	for (unsigned i = 0; i < L; ++i)
		{
		char c = a[i];
		char d = b[i];
		s.push_back(MatchStrengthSymbolNucleo((byte) c, (byte) d));
		}
	}

void GetSimStrAmino(const string &a, const string &b, string &s)
	{
	s.clear();
	const unsigned L = SIZE(a);
	asserta(SIZE(b) == L);
	for (unsigned i = 0; i < L; ++i)
		{
		char c = a[i];
		char d = b[i];
		s.push_back(MatchStrengthSymbolAmino((byte) c, (byte) d));
		}
	}

void BlastOut(FILE *f, const char *LabelA, const char *LabelB,
  const byte *A, const byte *B, unsigned LA, unsigned LB,
  unsigned LoA, unsigned LoB, const string &Path_, char Strand,
  bool Nucleo)
	{
	if (f == 0)
		return;

	if (!opt_idchar.empty())
		g_IdChar = opt_idchar[0];
	if (!opt_diffchar.empty())
		g_DiffChar = opt_diffchar[0];

	bool Plus = (Strand != '-');
	string Path = Path_;
	if (!opt_blast_termgaps)
		{
		while (!Path.empty())
			{
			char c = Path[0];
			if (c == 'D')
				{
				Path.erase(Path.begin());
				++LoA;
				}
			else if (c == 'I')
				{
				Path.erase(Path.begin());
				++LoB;
				}
			else
				break;
			}

		while (!Path.empty())
			{
			char c = *Path.rbegin();
			if (c == 'D' || c == 'I')
				Path.erase(Path.end()-1);
			else
				break;
			}
		}

	if (Path.empty())
		return;

	asserta(!Path.empty());

	fprintf(f, "\n");
	fprintf(f, "Query  >%s\n", LabelA);
	fprintf(f, "Target >%s\n", LabelB);

	unsigned Ni;
	unsigned Nj;
	GetLetterCounts(Path.c_str(), Ni, Nj);
	unsigned Endi = LoA + Ni - 1;
	unsigned Endj = LoB + Nj - 1;

	unsigned NA;
	unsigned NB;
	GetLetterCounts(Path.c_str(), NA, NB);

	unsigned HiA = LoA + NA - 1;
	unsigned HiB = LoB + NB - 1;

	unsigned MaxPos = max(HiA, HiB);
	char sPos[16];
	sprintf(sPos, "%u", MaxPos);
	unsigned nPos = (unsigned) strlen(sPos);

	const unsigned ColCount = SIZE(Path);
	const unsigned BlockCount = (ColCount + opt_rowlen - 1)/opt_rowlen;

	unsigned OffsetA = LoA;
	unsigned OffsetB = LoB;

	unsigned PosA = LoA;
	unsigned PosB = Plus ? LoB : (LB - LoB - 1);

	unsigned MatchCount = 0;
	unsigned PairCount = 0;
	unsigned GapCount = 0;
	for (unsigned BlockIndex = 0; BlockIndex < BlockCount; ++BlockIndex)
		{
		unsigned ColStart = BlockIndex*opt_rowlen;
		unsigned ColEnd = ColStart + opt_rowlen;
		if (ColEnd > ColCount)
			ColEnd = ColCount;

		unsigned FirstPosA = PosA;
		unsigned LastPosA = PosA;
		string RowA;
		for (unsigned ColIndex = ColStart; ColIndex < ColEnd; ++ColIndex)
			{
			char c = Path[ColIndex];
			if (c == 'M' || c == 'D')
				{
				LastPosA = PosA;
				RowA.push_back(A[OffsetA++]);
				++PosA;
				}
			else
				RowA.push_back('-');
			}

		unsigned FirstPosB = PosB;
		unsigned LastPosB = PosB;
		string RowB;
		for (unsigned ColIndex = ColStart; ColIndex < ColEnd; ++ColIndex)
			{
			char c = Path[ColIndex];
			if (c == 'M' || c == 'I')
				{
				LastPosB = PosB;
				assert(OffsetB < LB);
				char b = B[OffsetB++];
				assert(b);
				RowB.push_back(b);
				if (Plus)
					++PosB;
				else
					--PosB;
				}
			else
				RowB.push_back('-');
			}

		string Sim;
		if (Nucleo)
			GetSimStrNucleo(RowA, RowB, Sim);
		else
			GetSimStrAmino(RowA, RowB, Sim);

		unsigned L = SIZE(RowA);
		asserta(SIZE(RowB) == L);
		for (unsigned i = 0; i < L; ++i)
			{
			char c = Path[ColStart + i];
			if (c == 'M')
				{
				++PairCount;
				if (toupper(RowA[i]) == toupper(RowB[i]))
					++MatchCount;
				}
			else
				++GapCount;
			}

		const char *Strand = (Nucleo ? "+ " : "");
		fprintf(f, "\n");
		fprintf(f, "%*u %s%s %u\n",
		  nPos, FirstPosA+1, Strand, RowA.c_str(), LastPosA+1);

		Strand = (Nucleo ? "  " : "");
		fprintf(f, "%*.*s %s%s\n", nPos, nPos, "", Strand, Sim.c_str());

		Strand = "";
		if (Nucleo)
			Strand = (Plus ? "+ " : "- ");
		fprintf(f, "%*u %s%s %u\n",
		  nPos, FirstPosB+1, Strand, RowB.c_str(), LastPosB+1);
		}

	fprintf(f, "\n");
	fprintf(f, "Identities %u/%u (%.1f%%)",
	  MatchCount, PairCount, Pct(MatchCount, PairCount));

	fprintf(f, ", gaps %u/%u (%.1f%%)",
	  GapCount, ColCount, Pct(GapCount, ColCount));

	unsigned MinLen = min(LA, LB);
	double FractId = (MinLen == 0 ? 0.0 : double(MatchCount)/double(MinLen));

	fprintf(f, ", Id %u/%u (%.1f%%)", MatchCount, MinLen, FractId*100.0);

	fprintf(f, "\n");
	}

void FastaPair(FILE *f, const HitData &Hit)
	{
	if (f == 0)
		return;

	string A;
	string B;

	unsigned pa = 0;
	unsigned pb = 0;
	const char *Path = Hit.Path.c_str();
	for (unsigned i = 0; ; ++i)
		{
		char c = Path[i];
		if (c == 0)
			break;
		if (c == 'M' || c == 'D')
			A.push_back(Hit.QuerySeq[pa++]);
		else
			A.push_back('-');

		if (c == 'M' || c == 'I')
			B.push_back(Hit.SeedSeq[pb++]);
		else
			B.push_back('-');
		}

	fprintf(f, ">%s\n", Hit.QueryLabel);
	fprintf(f, "%s\n", A.c_str());

	if (Hit.Strand == '+' || Hit.Strand == '-')
		fprintf(f, ">%s%c\n", Hit.SeedLabel, Hit.Strand);
	else
		fprintf(f, ">%s\n", Hit.SeedLabel);
	fprintf(f, "%s\n\n", B.c_str());
	}
