#include "dp.h"

#define TEST	1

static void EnumPathsRecurse(unsigned n1, unsigned n2,
  unsigned L1, unsigned L2, bool SubPaths, const string &Path,
  OnPathFn OnPath)
	{
	bool Full = (n1 == L1 && n2 == L2);
	if (SubPaths)
		OnPath(Path, Full);
	else if (Full)
		OnPath(Path, true);
	
	char LastLetter = 0;
	if (!Path.empty())
		LastLetter = *Path.rbegin();

	if (n1 < L1 && n2 < L2)
		EnumPathsRecurse(n1 + 1, n2 + 1, L1, L2, SubPaths, Path + 'M', OnPath);

	if (n1 < L1 && LastLetter != 'I')
		EnumPathsRecurse(n1 + 1, n2, L1, L2, SubPaths, Path + 'D', OnPath);

	if (n2 < L2 && LastLetter != 'D')
		EnumPathsRecurse(n1, n2 + 1, L1, L2, SubPaths, Path + 'I', OnPath);
	}

void EnumPaths(unsigned L1, unsigned L2, bool SubPaths, OnPathFn OnPath)
	{
	string Path;
	EnumPathsRecurse(0, 0, L1, L2, SubPaths, Path, OnPath);
	}

#ifdef	TEST
static void OnPath(const string &Path, bool Full)
	{
	if (Path.empty())
		{
		Log("(Path empty)\n");
		Log("\n");
		return;
		}
	Log("%s%s\n", Path.c_str(), Full ? "*" : "");
	const size_t N = Path.size();
	for (size_t i = 0; i < N; ++i)
		Log("%c", Path[i] == 'M' || Path[i] == 'D' ? 'A' : '-');
	Log("\n");
	for (size_t i = 0; i < N; ++i)
		Log("%c", Path[i] == 'M' || Path[i] == 'I'  ? 'B' : '-');
	Log("\n");
	Log("\n");
	}

void TestEnumPaths()
	{
	EnumPaths(4, 3, true, OnPath);
	}
#endif
