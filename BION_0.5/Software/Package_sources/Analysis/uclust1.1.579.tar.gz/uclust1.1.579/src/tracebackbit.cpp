#include "dp.h"

#define TRACE	0

Mx<byte> g_Mx_TBBit;
byte **g_TBBit;
float *g_DPRow1;
float *g_DPRow2;
static float *g_DPBuffer1;
static float *g_DPBuffer2;

static unsigned g_CacheLB;

void AllocBit(unsigned LA, unsigned LB)
	{
	g_Mx_TBBit.Alloc("TBBit", LA+1, LB+1);
	g_TBBit = g_Mx_TBBit.GetData();
	if (LB > g_CacheLB)
		{
		g_CacheLB = LB + 128;
		myfree(g_DPBuffer1);
		myfree(g_DPBuffer2);

	// Allow use of [-1]
		g_DPBuffer1 = myalloc<float>(g_CacheLB+2);
		g_DPBuffer2 = myalloc<float>(g_CacheLB+2);
		g_DPRow1 = g_DPBuffer1 + 1;
		g_DPRow2 = g_DPBuffer2 + 1;
		}
	}

char *TraceBackBit(unsigned LA, unsigned LB, char State)
	{
	StartTimer(TraceBackBit);

	AllocPath(LA, LB);

	char *PathPtr = g_PathBack;
	*PathPtr-- = 0;

	byte **TB = g_TBBit;

#if	TRACE
	Log("\n");
	Log("TraceBackBit\n");
#endif

	size_t i = LA;
	size_t j = LB;
	for (;;)
		{
#if	TRACE
		Log("i=%3d  j=%3d  state=%c\n", (int) i, (int) j, State);
#endif
		if (i == 0 && j == 0)
			break;
		//Path.push_back(State);
		*PathPtr-- = State;

		byte t;
		switch (State)
			{
		case 'M':
			asserta(i > 0 && j > 0);
			t = TB[i-1][j-1];
			if (t & TRACEBITS_DM)
				State = 'D';
			else if (t & TRACEBITS_IM)
				State = 'I';
			else
				State = 'M';
			--i;
			--j;
			break;
		case 'D':
			asserta(i > 0);
			t = TB[i-1][j];
			if (t & TRACEBITS_MD)
				State = 'M';
			else
				State = 'D';
			--i;
			break;

		case 'I':
			asserta(j > 0);
			t = TB[i][j-1];
			if (t & TRACEBITS_MI)
				State = 'M';
			else
				State = 'I';
			--j;
			break;

		default:
			Die("TraceBackBit, invalid state %c", State);
			}
		}
	++PathPtr;
	asserta(PathPtr >= g_PathBegin);
	EndTimer(TraceBackBit);
	return PathPtr;
	}
