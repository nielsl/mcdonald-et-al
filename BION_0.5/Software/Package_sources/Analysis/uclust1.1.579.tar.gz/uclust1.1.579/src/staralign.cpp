#include "myutils.h"
#include "seqdb.h"

#define TRACE	0

static bool IsSeed(const string &Label)
	{
	size_t pos = Label.find('|');
	if (pos == string::npos || pos == Label.size())
		return false;
	char c = Label[pos+1];
	return c == '*';
	}

static void AlignCluster(FILE *f, const SeqDB &Input, unsigned ClusterIndex,
  unsigned SeqIndexFrom, unsigned SeqIndexTo)
	{
	const unsigned SeqCount = Input.GetSeqCount();

	asserta(SeqIndexTo >= SeqIndexFrom);
	asserta(SeqIndexFrom < SeqCount);
	asserta(SeqIndexTo < SeqCount);

	unsigned SeedSeqIndex = UINT_MAX;
	for (unsigned SeqIndex = SeqIndexFrom; SeqIndex <= SeqIndexTo; ++SeqIndex)
		{
		const string &Label = Input.GetLabel(SeqIndex);
		if (IsSeed(Label))
			{
			if (SeedSeqIndex != UINT_MAX)
				Die("> 1 seed found in cluster %u %u, %u (%u-%u)",
				  ClusterIndex, SeedSeqIndex, SeqIndex, SeqIndexFrom, SeqIndexTo);
			SeedSeqIndex = SeqIndex;
			}
		}
	if (SeedSeqIndex == UINT_MAX)
		Die("No seed found in cluster %u", ClusterIndex);

	const byte *SeedSeq = Input.GetSeq(SeedSeqIndex);
	unsigned SeedL = Input.GetSeqLength(SeedSeqIndex);
	const string &SeedLabel = Input.GetLabel(SeedSeqIndex);

	vector<unsigned> InsertCounts(SeedL+1, 0);
	vector<bool> SeedConserved(SeedL, true);
	for (unsigned SeqIndex = SeqIndexFrom; SeqIndex <= SeqIndexTo; ++SeqIndex)
		{
		if (SeqIndex > 0)
			ProgressStep(SeqIndex, SeqCount, "Aligning");

		const string &Label = Input.GetLabel(SeqIndex);
		const byte *Seq = Input.GetSeq(SeqIndex);
		unsigned L = Input.GetSeqLength(SeqIndex);
		unsigned SeedPos = 0;
		unsigned InsertCount = 0;
		for (unsigned i = 0; i < L; ++i)
			{
			char c = Seq[i];
			if (isupper(c) || c == '-')
				{
				++SeedPos;
				InsertCount = 0;
				}
			else
				{
				assert(islower(c));
				asserta(SeedPos <= SeedL);
				++InsertCount;
				if (InsertCount > InsertCounts[SeedPos])
					InsertCounts[SeedPos] = InsertCount;
				}
			}
		asserta(SeedPos == SeedL);
		}
	
	unsigned TotIL = 0;
	for (unsigned i = 0; i <= SeedL; ++i)
		TotIL += InsertCounts[i];

	if (TotIL > 1024)
		{
		Log("Cluster %u skipped, TotIL %u\n", ClusterIndex, TotIL);
		return;
		}

	for (unsigned SeqIndex = SeqIndexFrom; SeqIndex <= SeqIndexTo; ++SeqIndex)
		{
		if (SeqIndex == SeedSeqIndex)
			continue;

		const string &Label = Input.GetLabel(SeqIndex);
		const byte *Seq = Input.GetSeq(SeqIndex);
		unsigned L = Input.GetSeqLength(SeqIndex);
		fprintf(f, ">%s\n", Label.c_str());

#if	TRACE
		Log("\n");
		Log(">%s\n", Label.c_str());
		Log("NonSeedPos  c  SeedPos  c  ICount\n");
		Log("----------  -  -------  -  ------\n");
#endif

		unsigned SeedPos = 0;
		unsigned SeqPos = 0;
		for (;;)
			{
			unsigned IL = 0;
			for (;;)
				{
				if (SeqPos >= L)
					break;
				char c = Seq[SeqPos];
				if (islower(c))
					{
#if	TRACE
					Log("  Insert SeqPos=%u c=%c L=%u SeedPos=%u IL=%u\n",
					  SeqPos, c, L, SeedPos, IL);
#endif
					fputc(c, f);
					++SeqPos;
					++IL;
					}
				else
					break;
				}

			if (SeqPos >= L)
				break;
			char c = Seq[SeqPos++];
#if	TRACE
			Log("SeqPos=%u c=%c L=%u SeedPos=%u IL=%u\n", SeqPos, c, L, SeedPos, IL);
#endif
			unsigned n = InsertCounts[SeedPos];
			asserta(IL <= n);
			for (unsigned j = 0; j < n-IL; ++j)
				fputc('.', f);

			if (isupper(c) || c == '-')
				{
				if (c != SeedSeq[SeedPos] && c != '-')
					SeedConserved[SeedPos] = false;
				fputc(c, f);
				}
			++SeedPos;
			}
		fputc('\n', f);
		asserta(SeedPos == SeedL);
		}
	fprintf(f, ">%s\n", SeedLabel.c_str());
	for (unsigned i = 0; i < SeedL; ++i)
		{
		for (unsigned j = 0; j < InsertCounts[i]; ++j)
			fputc('.', f);
		char c = SeedSeq[i];
		if (!SeedConserved[i])
			c = tolower(c);
		fputc(c, f);
		}

	for (unsigned j = 0; j < InsertCounts[SeedL]; ++j)
		fputc('.', f);
	fputc('\n', f);
	}

static unsigned GetClusterIndexFromLabel(const string &Label)
	{
	return (unsigned) atoi(Label.c_str());
	}

void StarAlign()
	{
	if (opt_staralign == "")
		Die("Missing --staralign");
	if (opt_output == "")
		Die("Missing --output");

	FILE *f = CreateStdioFile(opt_output);

	SeqDB Input;
	Input.FromFasta(opt_staralign);

	const unsigned SeqCount = Input.GetSeqCount();
	Progress("%u sequences\n", SeqCount);
	if (SeqCount == 0)
		return;

	const string &Label0 = Input.GetLabel(0);
	unsigned CurrClusterIndex = GetClusterIndexFromLabel(Label0);
	unsigned SeqIndexFrom = 0;
	ProgressStep(0, SeqCount, "Aligning");
	for (unsigned SeqIndex = 1; SeqIndex < SeqCount; ++SeqIndex)
		{
		const string &Label = Input.GetLabel(SeqIndex);
		unsigned ClusterIndex = GetClusterIndexFromLabel(Label);
		if (ClusterIndex != CurrClusterIndex)
			{
			AlignCluster(f, Input, CurrClusterIndex, SeqIndexFrom, SeqIndex-1);
			SeqIndexFrom = SeqIndex;
			}
		CurrClusterIndex = ClusterIndex;
		}
	AlignCluster(f, Input, CurrClusterIndex, SeqIndexFrom, SeqCount-1);

	CloseStdioFile(f);
	}
