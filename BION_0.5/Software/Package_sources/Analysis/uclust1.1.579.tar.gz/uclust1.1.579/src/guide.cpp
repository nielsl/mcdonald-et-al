#include "myutils.h"
#include "seqdb.h"
#include "upgma.h"
#include "pwa.h"

#define TRACE_DISTS		0

void SetOpts();
double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path);
double KimuraDist(double FractId);

extern bool g_IsNucleo;

static float FractIdToDist(float FractId)
	{
	asserta(FractId >= 0.0 && FractId <= 1.0);
	return (float) KimuraDist(FractId);
	}

void Guide()
	{
	if (opt_guide == "")
		Die("Missing --guide");
	if (opt_output == "")
		Die("Missing --output");

	SeqDB Input;
	Input.FromFasta(opt_guide);

	if (opt_amino)
		g_IsNucleo = false;
	else
		g_IsNucleo = opt_nucleo|| Input.IsNucleo();

	SetOpts();

	AlnParams AP;
	AlnHeuristics AH;

	AP.InitFromCmdLine(g_IsNucleo);
	AH.InitFromCmdLine();

	PWA pwa;
	pwa.Init(opt_k);

	const unsigned SeqCount = Input.GetSeqCount();
	if (SeqCount < 3)
		Die("Input file has < 3 seqs");

	const char **Names = myalloc<const char *>(SeqCount);
	for (unsigned i = 0; i < SeqCount; ++i)
		Names[i] = Input.GetLabel(i).c_str();

	unsigned PairCount = Input.GetPairCount();
	float *Dist = myalloc<float>(PairCount);

	UPGMA U;
	U.m_LeafCount = SeqCount;
#if	TRACE_DISTS
	Log("   PctId        Dist  Labels\n");
	Log("--------  ----------  ------\n");
#endif
	for (unsigned i = 0; i < SeqCount; ++i)
		{
		const char *Labeli = Input.GetLabel(i).c_str();
		const byte *Seqi = Input.GetSeq(i);
		unsigned Li = Input.GetSeqLength(i);
	
		pwa.SetQuery(Labeli, Seqi, Li);

		for (unsigned j = i+1; j < SeqCount; ++j)
			{
			const char *Labelj = Input.GetLabel(j).c_str();
			const byte *Seqj = Input.GetSeq(j);
			unsigned Lj = Input.GetSeqLength(j);

			pwa.SetTarget(Labelj, Seqj, Lj);
			const char *Path = pwa.Align(AP, AH);
			float Id = (float) GetFractIdGivenPath(Seqi, Seqj, Path);
			float d = FractIdToDist(Id);

#if	TRACE_DISTS
			Log("%7.1f%%  %10.4f  %s, %s\n", Id*100.0, d, Labeli, Labelj);
#endif

			unsigned k = U.Trix(i, j);
			Dist[k] = d;
			}
		}

	LINKAGE Linkage = LINKAGE_Avg;
	U.m_Bias = 0.1f;
	if (opt_linkage == "")
		;
	else if (opt_linkage == "avg")
		Linkage = LINKAGE_Avg;
	else if (opt_linkage == "max")
		Linkage = LINKAGE_Max;
	else if (opt_linkage == "min")
		Linkage = LINKAGE_Min;
	else if (opt_linkage == "biased")
		Linkage = LINKAGE_Biased;
	else
		Die("Invalid --linkage");

	U.Init(Dist, Names, SeqCount);
	U.Cluster(Linkage);
	U.ToNewick(opt_output);
	}
