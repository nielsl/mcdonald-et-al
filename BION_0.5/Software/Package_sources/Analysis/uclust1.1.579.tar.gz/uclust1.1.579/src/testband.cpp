#include "dp.h"
#include "seqdb.h"

#define TRACE_MX	0
#define BRUTE		0

extern float **g_SubstMx;
static Mx<bool> g_MaskM;
static Mx<bool> g_MaskD;
static Mx<bool> g_MaskI;

void TestBand()
	{
	SeqDB Input;
	Input.FromFasta(opt_input);

	AlnParams AP;
	// AP.Set(g_SubstMx, -10, -1);

	AP.SubstMx = g_SubstMx;
	AP.OpenA = -12;
	AP.OpenB = -11;
	AP.LOpenA = -10;
	AP.LOpenB = -9;
	AP.ROpenA = -8;
	AP.ROpenB = -7;
	AP.ExtA = -6;
	AP.ExtB = -5;
	AP.LExtA = -4;
	AP.LExtB = -3;
	AP.RExtA = -2;
	AP.RExtB = -1;

	AP.LogMe();

	const unsigned SeqCount = Input.GetSeqCount();
	unsigned PairCount = (SeqCount*(SeqCount - 1))/2;
	unsigned Count = 0;
	for (unsigned i = 0; i < SeqCount; ++i)
		{
		for (unsigned j = i+1; j < SeqCount; ++j)
			{
			ProgressStep(Count++, PairCount, "Testing");

			SegPair SP;
			SP.Init(Input, i, j);

			unsigned LA = Input.GetSeqLength(i);
			unsigned LB = Input.GetSeqLength(j);

			//unsigned DiagLo = 1;
			//unsigned DiagHi = LA + LB - 1;
			unsigned DiagLo = 5;
			unsigned DiagHi = LA + LB - 5;

			DiagBox Box(LA, LB, DiagLo, DiagHi);

			g_MaskM.Alloc("g_MaskM", LA+1, LB+1);
			g_MaskD.Alloc("g_MaskD", LA+1, LB+1);
			g_MaskI.Alloc("g_MaskI", LA+1, LB+1);

			for (unsigned i = 0; i <= LA; ++i)
				{
				for (unsigned j = 0; j <= LB; ++j)
					{
					g_MaskM.Put(i, j, Box.InBoxDPM(i, j));
					g_MaskD.Put(i, j, Box.InBoxDPD(i, j));
					g_MaskI.Put(i, j, Box.InBoxDPI(i, j));
					}
				}
#if	TRACE_MX
			g_MaskM.LogMe();
			g_MaskD.LogMe();
			g_MaskI.LogMe();
#endif
		// Use string as 'strsave' coz static buffer is overwritten.
			string PathSimpleBand = ViterbiSimpleBand(SP, AP, DiagLo, DiagHi);
			string PathFastBand = ViterbiFastBand(SP, AP, DiagLo, DiagHi);

			Mx<float> *SimpleBandM, *SimpleBandD, *SimpleBandI;
			GetSimpleBandMxs(&SimpleBandM, &SimpleBandD, &SimpleBandI);

#if	SAVE_FAST
			Mx<float> *FastBandM, *FastBandD, *FastBandI;
			GetFastBandMxs(&FastBandM, &FastBandD, &FastBandI);
#endif

#if	BRUTE
			string PathBrute = ViterbiBrute(SP, AP, DiagLo, DiagHi);
			Mx<float> *BruteM, *BruteD, *BruteI;
			GetBruteMxs(&BruteM, &BruteD, &BruteI);

			bool SimpleBandMEq = SimpleBandM->EqMask(*BruteM, g_MaskM);
			bool SimpleBandDEq = SimpleBandD->EqMask(*BruteD, g_MaskD);
			bool SimpleBandIEq = SimpleBandI->EqMask(*BruteI, g_MaskI);

#if	SAVE_FAST
			bool FastBandMEq = FastBandM->EqMask(*BruteM, g_MaskM);
			bool FastBandDEq = FastBandD->EqMask(*BruteD, g_MaskD);
			bool FastBandIEq = FastBandI->EqMask(*BruteI, g_MaskI);
#endif
#else	// BRUTE
			bool SimpleBandMEq = SimpleBandM->EqMask(*SimpleBandM, g_MaskM);
			bool SimpleBandDEq = SimpleBandD->EqMask(*SimpleBandD, g_MaskD);
			bool SimpleBandIEq = SimpleBandI->EqMask(*SimpleBandI, g_MaskI);

#if	SAVE_FAST
			bool FastBandMEq = FastBandM->EqMask(*SimpleBandM, g_MaskM);
			bool FastBandDEq = FastBandD->EqMask(*SimpleBandD, g_MaskD);
			bool FastBandIEq = FastBandI->EqMask(*SimpleBandI, g_MaskI);
#endif
#endif	// BRUTE

#if	TRACE_MX
			Log("---------------------\n");
#if	BRUTE
			Log("\n");
			Log("Brute:\n");
			Log("%s\n", PathBrute.c_str());
			LogAln(SP, PathBrute.c_str());
#endif
			Log("\n");
			Log("SimpleBand:\n");
			Log("%s\n", PathSimpleBand.c_str());
			LogAln(SP, PathSimpleBand.c_str());
#if	SAVE_FAST
			Log("\n");
			Log("FastBand:\n");
			Log("%s\n", PathFastBand.c_str());
			LogAln(SP, PathFastBand.c_str());
			Log("\n");
#endif // SAVE_FAST
#endif // TRACE_MX
			Log("EQ=MDI");
#if	BRUTE
			Log(" Simple=%c%c%c",
			  tof(SimpleBandMEq),
			  tof(SimpleBandDEq),
			  tof(SimpleBandIEq));
#endif
#if	SAVE_FAST
			Log(" SimpleBand=%c%c%c",
			  tof(FastBandMEq),
			  tof(FastBandDEq),
			  tof(FastBandIEq));
#endif
			Log("\n");
			}
		}
	}
