#include "myutils.h"
#include "chime.h"

void ChimeModel::Clear()
	{
	memset(this, 0xff, sizeof(*this));
	}

void ChimeModel::LogMe() const
	{
	Log("\n");
	Log("Seq     Lo    Xlo    Xhi     Hi      L\n");
	Log("---  -----  -----  -----  -----  -----\n");
	Log("  Q  %5u  %5u  %5u  %5u  %5u\n", Ranges.Qlo, Qxlo, Qxhi, Ranges.Qhi, Ranges.QL);
	Log(" P1  %5u  %5u  %5u  %5u  %5u\n", Ranges.P1lo, P1xlo, P1xhi, Ranges.P1hi, Ranges.P1L);
	Log(" P2  %5u  %5u  %5u  %5u  %5u\n", Ranges.P2lo, P2xlo, P2xhi, Ranges.P2hi, Ranges.P2L);
	Log("\n");
	Log("      .......Left.........  .....Cross-over.....  .......Right........  .......Total........\n");
	Log("Pair    Len  Diffs      id    Len  Diffs      id    Len  Diffs      id    Len  Diffs      id\n");
	Log("----  -----  -----  ------  -----  -----  ------  -----  -----  ------  -----  -----  ------\n");

	{
	unsigned LL = Qxlo - Ranges.Qlo + 1;
	unsigned LD = DiffsL1;
	double LId = 100.0*(1.0 - double(LD)/double(LL));

	unsigned XL = Qxhi - Qxlo + 1;
	unsigned XD = DiffsX1;
	double XId = 100.0*(1.0 - double(XD)/double(XL));

	unsigned RL = Ranges.Qhi - Qxhi + 1;
	unsigned RD = DiffsR1;
	double RId = 100.0*(1.0 - double(RD)/double(RL));

	unsigned L = Ranges.QL;
	unsigned D = DiffsQ1;
	double Id = 100.0*(1.0 - double(D)/double(L));

	Log("  Q1  %5u  %5u  %5.1f%%  %5u  %5u  %5.1f%%  %5u  %5u  %5.1f%%  %5u  %5u  %5.1f%%\n",
	  LL, LD, LId,
	  XL, XD, XId,
	  RL, RD, RId,
	  L, D, Id);
	}

	{
	unsigned LL = Qxlo - Ranges.Qlo + 1;
	unsigned LD = DiffsL2;
	double LId = 100.0*(1.0 - double(LD)/double(LL));

	unsigned XL = Qxhi - Qxlo + 1;
	unsigned XD = DiffsX2;
	double XId = 100.0*(1.0 - double(XD)/double(XL));

	unsigned RL = Ranges.Qhi - Qxhi + 1;
	unsigned RD = DiffsR2;
	double RId = 100.0*(1.0 - double(RD)/double(RL));

	unsigned L = Ranges.QL;
	unsigned D = DiffsQ2;
	double Id = 100.0*(1.0 - double(D)/double(L));

	Log("  Q2  %5u  %5u  %5.1f%%  %5u  %5u  %5.1f%%  %5u  %5u  %5.1f%%  %5u  %5u  %5.1f%%\n",
	  LL, LD, LId,
	  XL, XD, XId,
	  RL, RD, RId,
	  L, D, Id);
	}

	{
	unsigned L = Ranges.QL;
	unsigned D = DiffsQ12;
	double Id = 100.0*(1.0 - double(D)/double(L));

	const char *OneTwo = First1 ? "12" : "21";
	Log(" Q%s                                                                    %5u  %5u  %5.1f%%\n",
	  OneTwo, L, D, Id);
	}
	}
