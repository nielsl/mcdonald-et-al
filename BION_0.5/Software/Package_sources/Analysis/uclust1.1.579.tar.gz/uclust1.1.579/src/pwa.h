#ifndef pwa_h
#define pwa_h

#include "myutils.h"
#include "hspfinder.h"
#include "dp.h"
#include "path.h"

struct AlnHeuristics
	{
	AlnHeuristics()
		{
		Clear();
		}

	void Clear()
		{
		InitExact();
		}

	void InitFromCmdLine()
		{
		if (!opt_fastalign)
			InitExact();
		else
			{
			MinHSPLength = opt_hsp;
			BandWidth = opt_band;
			HSPScore = opt_hspscore;
			MinHSPFractId = opt_id;
			}
		}

	bool IsExact() const
		{
		return MinHSPLength == 0 && BandWidth == 0;
		}

	void InitExact()
		{
		MinHSPLength = 0;
		BandWidth = 0;
		HSPScore = 0.0;
		MinHSPFractId = 0.0;
		}

	void LogMe() const
		{
		Log("MinHSPLength %u, BandWidth %u, HSPScore %.1f, MinHSPFractId %.2f\n",
		  MinHSPLength,
		  BandWidth,
		  HSPScore,
		  MinHSPFractId);
		}

public:
	unsigned MinHSPLength;
	unsigned BandWidth;
	double HSPScore;
	double MinHSPFractId;
	};

// Pair-wise aligner
class PWA
	{
public:
	PWA();
	void Init(unsigned HSPFinderWordLength);
	void Clear(bool Ctor = false);
	void SetQuery(const char *QueryLabel, const byte *QuerySeq, unsigned QueryLength);
	void SetTarget(const char *TargetLabel, const byte *TargetSeq, unsigned TargetLength);
	const char *Align(const AlnParams &AP, const AlnHeuristics &AH);
	const char *AlignNoCompareFull(const AlnParams &AP, const AlnHeuristics &AH);
	const char *AlignNoHSPs(const AlnParams &AP, unsigned BandWidth);
	void LogStats() const;
	void LogBadHSP(const HSPData &HSP, const char *Path) const;

private:
	void SetQueryForHSPFinder();
	void GetSP(const HSPData *HSP1, const HSPData *HSP2, SegPair &SP);
	char *AlignSP(const SegPair &SP, const AlnParams &AP,
	  const AlnHeuristics &AH, char *PathPtr);
	void CompareFull(const char *Path, const char *PathEx,
	  const vector<HSPData> &HSPs);
	void AllocPath();

public:
	HSPFinder m_HSPFinder;

// Cached query
	const char *m_QueryLabel;
	const byte *m_QuerySeq;
	unsigned m_QueryLength;

	const char *m_TargetLabel;
	const byte *m_TargetSeq;
	unsigned m_TargetLength;

	bool m_QueryCachedInHSPFinder;
	vector<HSPData> m_HSPs;
	char *m_Path;
	unsigned m_PathBufferSize;

	bool m_CheckFast;

	unsigned m_CompareFullCount;
	unsigned m_TPPathEqFullCount;
	unsigned m_AlignNoHSPCount;
	unsigned m_PathEqFullCount;
	unsigned m_HSPRejectCount;
	unsigned m_HSPRejectFPCount;
	unsigned m_WrongIdCount;
	unsigned m_HitCount;
	unsigned m_FPHitCount;
	unsigned m_FNHitCount;
	unsigned m_BadHSPCount;

#if	TIMING
	TICKS m_TotalExactTicks;
	TICKS m_TotalHeuristicTicks;
#endif
	};

void LogAln(const byte *A, const byte *B, const char *Path);

#endif // pwa_h
