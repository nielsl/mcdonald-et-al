#include "myutils.h"
#include "diagbox.h"
#include "timing.h"

#define TRACE			0
#define	TRACE_ALIGN		0

/***
One-dimensional dynamic programming to find best segment match
on a given diagonal
	d = LA - i + j

Recursion relation.

Conceptually, there is one dynamic programming vector V,
defined as:

	V[i] =	score of best match ending in A[i], B[j]
			i = 0..(LA-1), j=(0..LB-1)
			where j = d + i - LA.

         =	max(0, V[i-1]) + SubstMx[A[i], B[j]]

We don't need to store the vector because all we need is the
current (i) & previous (i-1) values.
***/

extern float **g_SubstMx;

static const float MatchNucleo = 1.0;
static const float MismatchNucleo = -2.0;

static void GetBestSegNucleo(const byte *A, unsigned LA, const byte *B,
  unsigned LB, unsigned Diag, unsigned &loi, unsigned &len)
	{
	loi = UINT_MAX;
	len = 0;

	unsigned mini, minj, maxi, maxj;
	GetDiagRange(LA, LB, Diag, mini, minj, maxi, maxj);
	unsigned L = maxi - mini + 1;
#if	TRACE
	Log("\n");
	Log("GetBestSeg LA=%u LB=%u Diag=%u\n", LA, LB, Diag);
	Log("A=%*.*s\n", LA, LA, A);
	Log("B=%*.*s\n", LB, LB, B);
	Log("i=%u-%u, j=%u-%u, L=%u\n", mini, maxi, minj, maxj, L);
#endif
	assert(maxj - minj + 1 == L);

	const byte *a = A + mini;
	const byte *b = B + minj;
	float BestScore = 0.0f;
	float v = 0.0f;
	float maxv = -999.0f;
	const float * const *SM = g_SubstMx;
	unsigned Start = 0;
	unsigned lok = UINT_MAX;
	for (unsigned k = 0; k < L; ++k)
		{
		float Subst = (*a++ == *b++) ? MatchNucleo : MismatchNucleo;
		// float Subst = SM[*a++][*b++];
#if TRACE
		Log("k=%u v=%g a=%c b=%c Subst=%.1f\n",
		  k, v, *a, *b, Subst);
#endif
		v += Subst;
		if (v <= 0.0f)
			{
			v = 0;
			Start = k+1;
#if	TRACE
			Log("v=%g < 0, Start=%u, lok=%u\n", v, Start, lok);
#endif
			}
		else
			{
			if (v > maxv)
				{
				maxv = v;
				lok = Start;
				len = k - Start + 1;
#if	TRACE
				Log("New maxv=%g >= 0, Start=%u, lok=%u len=%u\n", maxv, Start, lok, len);
#endif
				}
			}
		}

	if (lok == UINT_MAX)
		return;

	loi = mini + lok;

#if	TRACE || TRACE_ALIGN
	Log("\n");
	Log("Done, maxv=%g, lok=%u loi=%u len=%u\n", v, lok, loi, len);

	unsigned n = 0;
	if (mini < minj)
		n = minj - mini;
	Log("A=");
	for (unsigned i = 0; i < n; ++i)
		Log(" ");
	for (unsigned i = 0; i < mini; ++i)
		Log("%c", tolower(A[i]));
	Log("|");
	for (unsigned i = mini; i <= maxi; ++i)
		{
		char c = A[i];
		if (i >= loi && i < loi + len)
			c = toupper(c);
		else
			c = tolower(c);
		Log("%c", c);
		}
	Log("|");
	for (unsigned i = maxi+1; i < LA; ++i)
		Log("%c", tolower(A[i]));
	Log("\n");

	n = 0;
	if (minj < mini)
		n = mini - minj;
	Log("B=");
	for (unsigned j = 0; j < n; ++j)
		Log(" ");
	for (unsigned j = 0; j < minj; ++j)
		Log("%c", tolower(B[j]));
	Log("|");
	unsigned loj = (Diag + loi) - LA;
	for (unsigned j = minj; j <= maxj; ++j)
		{
		char c = B[j];
		if (j >= loj && j < loj + len)
			c = toupper(c);
		else
			c = tolower(c);
		Log("%c", c);
		}
	Log("|");
	for (unsigned j = maxj+1; j < LB; ++j)
		Log("%c", tolower(B[j]));
	Log("\n");

	float Sum = 0.0;
	for (unsigned k = 0; k < len; ++k)
		{
		unsigned i = loi + k;
		unsigned j = (Diag + i) - LA;
		char a = A[i];
		char b = B[j];
		Sum += SM[a][b];
		}
	Log("Score=%g\n", Sum);
#endif
	}

static void GetBestSegAmino(const byte *A, unsigned LA, const byte *B,
  unsigned LB, unsigned Diag, unsigned &loi, unsigned &len)
	{
	loi = UINT_MAX;
	len = 0;

	unsigned mini, minj, maxi, maxj;
	GetDiagRange(LA, LB, Diag, mini, minj, maxi, maxj);
	unsigned L = maxi - mini + 1;
#if	TRACE
	Log("\n");
	Log("GetBestSeg LA=%u LB=%u Diag=%u\n", LA, LB, Diag);
	Log("A=%*.*s\n", LA, LA, A);
	Log("B=%*.*s\n", LB, LB, B);
	Log("i=%u-%u, j=%u-%u, L=%u\n", mini, maxi, minj, maxj, L);
#endif
	assert(maxj - minj + 1 == L);

	const byte *a = A + mini;
	const byte *b = B + minj;
	float BestScore = 0.0f;
	float v = 0.0f;
	float maxv = -999.0f;
	const float * const *SM = g_SubstMx;
	unsigned Start = 0;
	unsigned lok = UINT_MAX;
	for (unsigned k = 0; k < L; ++k)
		{
		// float Subst = (*a++ == *b++) ? 2.0f : -1.0f;
		float Subst = SM[*a++][*b++];
#if TRACE
		Log("k=%u v=%g a=%c b=%c Subst=%.1f\n",
		  k, v, *a, *b, Subst);
#endif
		v += Subst;
		if (v <= 0.0f)
			{
			v = 0;
			Start = k+1;
#if	TRACE
			Log("v=%g < 0, Start=%u, lok=%u\n", v, Start, lok);
#endif
			}
		else
			{
			if (v > maxv)
				{
				maxv = v;
				lok = Start;
				len = k - Start + 1;
#if	TRACE
				Log("New maxv=%g >= 0, Start=%u, lok=%u len=%u\n", maxv, Start, lok, len);
#endif
				}
			}
		}

	if (lok == UINT_MAX)
		return;

	loi = mini + lok;

// loj ok?
	asserta(Diag + loi >= LA);

#if	TRACE || TRACE_ALIGN
	Log("\n");
	Log("Done, maxv=%g, lok=%u loi=%u len=%u\n", v, lok, loi, len);

	unsigned n = 0;
	if (mini < minj)
		n = minj - mini;
	Log("A=");
	for (unsigned i = 0; i < n; ++i)
		Log(" ");
	for (unsigned i = 0; i < mini; ++i)
		Log("%c", tolower(A[i]));
	Log("|");
	for (unsigned i = mini; i <= maxi; ++i)
		{
		char c = A[i];
		if (i >= loi && i < loi + len)
			c = toupper(c);
		else
			c = tolower(c);
		Log("%c", c);
		}
	Log("|");
	for (unsigned i = maxi+1; i < LA; ++i)
		Log("%c", tolower(A[i]));
	Log("\n");

	n = 0;
	if (minj < mini)
		n = mini - minj;
	Log("A=");
	for (unsigned j = 0; j < n; ++j)
		Log(" ");
	for (unsigned j = 0; j < minj; ++j)
		Log("%c", tolower(B[j]));
	Log("|");
	unsigned loj = (Diag + loi) - LA;
	for (unsigned j = minj; j <= maxj; ++j)
		{
		char c = B[j];
		if (j >= loj && j < loj + len)
			c = toupper(c);
		else
			c = tolower(c);
		Log("%c", c);
		}
	Log("|");
	for (unsigned j = maxj+1; j < LB; ++j)
		Log("%c", tolower(A[j]));
	Log("\n");

	float Sum = 0.0;
	for (unsigned k = 0; k < len; ++k)
		{
		unsigned i = loi + k;
		unsigned j = (Diag + i) - LA;
		char a = A[i];
		char b = B[j];
		Sum += SM[a][b];
		}
	Log("Score=%g\n", Sum);
#endif
	}

void GetBestSeg(const byte *A, unsigned LA, const byte *B, unsigned LB,
  unsigned Diag, unsigned &loi, unsigned &len)
	{
	StartTimer(GetBestSeg);

	extern bool g_IsNucleo;
	if (g_IsNucleo)
		GetBestSegNucleo(A, LA, B, LB, Diag, loi, len);
	else
		GetBestSegAmino(A, LA, B, LB, Diag, loi, len);

// loj ok?
	asserta(loi == UINT_MAX || Diag + loi >= LA);

	EndTimer(GetBestSeg);
	}
