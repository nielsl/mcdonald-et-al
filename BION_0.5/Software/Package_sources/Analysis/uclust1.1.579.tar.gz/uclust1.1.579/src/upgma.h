#ifndef upgma_h
#define upgma_h

#include "mx.h"

typedef float dist_t;

enum LINKAGE
	{
	LINKAGE_Avg,
	LINKAGE_Min,
	LINKAGE_Max,
	LINKAGE_Biased,
	};

class UPGMA
	{
public:
	unsigned m_LeafCount;
	unsigned m_InternalNodeIndex;

/***
Triangular distance matrix is m_Dist, which is allocated
as a one-dimensional vector of length m_TriangleSize.
TriangleSubscript(i,j) maps row,column=i,j to the subscript
into this vector.
Row / column coordinates are a bit messy.
Initially they are leaf indexes 0..N-1.
But each time we create a new node (=new cluster, new subtree),
we re-use one of the two rows that become available (the children
of the new node). This saves memory.
We keep track of this through the m_NodeIndex vector.
***/
	dist_t *m_Dist;
	const char **m_Labels;

// Distance to nearest neighbor in row i of distance matrix.
// Subscript is distance matrix row.
	dist_t *m_MinDist;

// Nearest neighbor to row i of distance matrix.
// Subscript is distance matrix row.
	unsigned *m_NearestNeighbor;

// Node index of row i in distance matrix.
// Node indexes are 0..N-1 for leaves, N..2N-2 for internal nodes.
// Subscript is distance matrix row.
	unsigned *m_NodeIndex;

// The following vectors are defined on internal nodes,
// subscripts are internal node index 0..N-2.
// For m_Left/Right, value is the node index 0 .. 2N-2
// because a child can be internal or leaf.
	unsigned *m_Left;
	unsigned *m_Right;
	dist_t *m_Height;
	dist_t *m_LeftLength;
	dist_t *m_RightLength;
	LINKAGE m_Linkage;
	float m_Bias;

public:
	UPGMA();
	void Clear(bool ctor = false);
	void Alloc(unsigned LeafCount);
	void InitState();

// Dist is over-written, caller allocates for efficiency.
	void Init(dist_t *Dist, const char **Names, unsigned LeafCount);
	void Cluster(LINKAGE Linkage);

	unsigned GetTriangleSize() const
		{
		return (m_LeafCount*(m_LeafCount - 1))/2;
		}
	
	bool IsLeaf(unsigned NodeIndex) const
		{
		return NodeIndex < m_LeafCount;
		}

	bool IsInternal(unsigned NodeIndex) const
		{
		return NodeIndex >= m_LeafCount;
		}

	bool IsRoot(unsigned NodeIndex) const
		{
		return NodeIndex == GetRoot();
		}

	unsigned GetRoot() const
		{
		return 2*m_LeafCount - 2;
		}

// Triangle index, i.e. offset of (i,j) into triangular distance vector
	unsigned Trix(unsigned i, unsigned j) const
		{
		assert(i < m_LeafCount && j < m_LeafCount);
		unsigned k = i >= j ? j + (i*(i - 1))/2:  i + (j*(j - 1))/2;
		assert(k < GetTriangleSize());
		return k;
		}

	dist_t GetDist(unsigned i, unsigned j) const
		{
		return m_Dist[Trix(i, j)];
		}

	dist_t Link(dist_t dL, dist_t dR) const;
	void GetNearestNeighbors(unsigned &Row1, unsigned &Row2) const;
	unsigned GetNodeCount() const
		{
		return 2*m_LeafCount - 1;
		}

	void LogMe() const;
	void LogTree() const;
	void LogTreeRecurse(unsigned NodeIndex) const;
	void DistVecToDistMx(Mx<float> &DistMx) const;
	void GetDistMx(Mx<float> &DistMx) const;
	void GetDistsRecurse(unsigned NodeIndex, dist_t Dist,
	  vector<unsigned> &LeafIndexes, vector<dist_t> &Dists,
	  Mx<float> &DistMx) const;
	void LogDistMx(const Mx<float> &DistMx) const;
	void ToNewick(const string &FileName) const;
	void ToNewickRecurse(FILE *f, unsigned NodeIndex,
	  float BranchLength) const;
	};

#endif // upgma_h
