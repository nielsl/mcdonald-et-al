#include "dp.h"
#include <algorithm> // for reverse()

#define TRACE	0

static Mx<byte> g_MxTBM;
static Mx<byte> g_MxTBD;
static Mx<byte> g_MxTBI;

static Mx<float> g_MxDPM;
static Mx<float> g_MxDPD;
static Mx<float> g_MxDPI;

static byte **g_TBM;
static byte **g_TBD;
static byte **g_TBI;

static float **g_DPM;
static float **g_DPD;
static float **g_DPI;

static string g_Path;

void GetSimpleBandMxs(Mx<float> **M, Mx<float> **D, Mx<float> **I)
	{
	*M = &g_MxDPM;
	*D = &g_MxDPD;
	*I = &g_MxDPI;
	}

static void Alloc(unsigned LA, unsigned LB)
	{
	g_MxDPM.Alloc("SimpleBandM", LA+1, LB+1);
	g_MxDPD.Alloc("SimpleBandD", LA+1, LB+1);
	g_MxDPI.Alloc("SimpleBandI", LA+1, LB+1);

	g_MxTBM.Alloc("SimpleBandTBM", LA+1, LB+1);
	g_MxTBD.Alloc("SimpleBandTBD", LA+1, LB+1);
	g_MxTBI.Alloc("SimpleBandTBI", LA+1, LB+1);

	g_DPM = g_MxDPM.GetData();
	g_DPD = g_MxDPD.GetData();
	g_DPI = g_MxDPI.GetData();

	g_TBM = g_MxTBM.GetData();
	g_TBD = g_MxTBD.GetData();
	g_TBI = g_MxTBI.GetData();
	}

static const char *TraceBack(unsigned LA, unsigned LB, char State)
	{
	g_Path.clear();

	byte **TBM = g_TBM;
	byte **TBD = g_TBD;
	byte **TBI = g_TBI;

#if	TRACE_TB
	Log("\n");
	Log("TraceBack\n");
#endif

	size_t i = LA;
	size_t j = LB;
	for (;;)
		{
#if TRACE_TB
		Log("i=%3d  j=%3d  state=%c\n", (int) i, (int) j, State);
#endif
		if (i == 0 && j == 0)
			break;
		g_Path.push_back(State);

		switch (State)
			{
		case 'M':
			State = TBM[i][j];
			--i;
			--j;
			break;
		case 'D':
			State = TBD[i][j];
			--i;
			break;
		case 'I':
			State = TBI[i][j];
			--j;
			break;
		default:
			Die("TraceBack, invalid state %c", State);
			}
		}

	reverse(g_Path.begin(), g_Path.end());
	return g_Path.c_str();
	}

const char *ViterbiSimpleBand(const SegPair &SP, const AlnParams &AP,
  unsigned DiagLo, unsigned DiagHi)
	{
	const byte *A = SP.A + SP.LoA;
	const byte *B = SP.B + SP.LoB;
	const unsigned LA = SP.GetSegLenA();
	const unsigned LB = SP.GetSegLenB();

	if (LA*LB > 100*1000*1000)
		{
		SP.LogMe();
		Die("Sequences too long for dynamic programming (diags %u-%u)",
		  DiagLo, DiagHi);
		}

// Verify diagonal range includes i=LA,j=LB
	asserta(DiagLo <= DiagHi);
	asserta(LA > 0 && LB > 0);

// Verify diagonal range includes i=LA,j=LB
	DiagBox Box(LA, LB, DiagLo, DiagHi);
	asserta(Box.InBox(LA-1, LB-1));
	Alloc(LA, LB);

	const float * const *Mx = AP.SubstMx;

	float **DPM = g_DPM;
	float **DPD = g_DPD;
	float **DPI = g_DPI;
	
	byte **TBM = g_TBM;
	byte **TBD = g_TBD;
	byte **TBI = g_TBI;
	
	DPM[0][0] = float (0);
	DPD[0][0] = MINUS_INFINITY;
	DPI[0][0] = MINUS_INFINITY;
	TBM[0][0] = '!';
	TBD[0][0] = '!';
	TBI[0][0] = '!';
	
// Init zero'th row A
	{
	float s = AP.LOpenB;
	for (unsigned i = 0; i < LA; ++i)
		{
		if (i > 0)
			{
			s += AP.LExtB;
			}
		if (Box.InBoxDPD(i+1, 0))
			{
			DPM[i+1][0] = MINUS_INFINITY;
			DPD[i+1][0] = s;
			DPI[i+1][0] = MINUS_INFINITY;
			TBM[i+1][0] = '!';
			TBD[i+1][0] = (i == 0 ? 'M' : 'D');
			TBI[i+1][0] = '!';
			}
		else
			{
			DPM[i+1][0] = MINUS_INFINITY;
			DPD[i+1][0] = MINUS_INFINITY;
			DPI[i+1][0] = MINUS_INFINITY;
			TBM[i+1][0] = '*';
			TBD[i+1][0] = '*';
			TBI[i+1][0] = '*';
			}
		}
	}
	
// Init zero'th row B
	{
	float s = AP.LOpenA;
	for (unsigned j = 0; j < LB; ++j)
		{
		if (j > 0)
			{
			s += AP.LExtA;
			}
		if (Box.InBoxDPI(0, j+1))
			{
			DPM[0][j+1] = MINUS_INFINITY;
			DPD[0][j+1] = MINUS_INFINITY;
			DPI[0][j+1] = s;
			TBM[0][j+1] = '!';
			TBD[0][j+1] = '!';
			TBI[0][j+1] = (j == 0 ? 'M' : 'I');
			}
		else
			{
			DPM[0][j+1] = MINUS_INFINITY;
			DPD[0][j+1] = MINUS_INFINITY;
			DPI[0][j+1] = MINUS_INFINITY;
			TBM[0][j+1] = '*';
			TBD[0][j+1] = '*';
			TBI[0][j+1] = '*';
			}
		}
	}
	
// Main loop
	for (unsigned i = 0; i < LA; ++i)
		{
		byte a = A[i];
		const float *MxRow = Mx[a];
		const bool LeftA = (i == 0);
		const bool RightA = (i == LA-1);
		for (unsigned j = 0; j < LB; ++j)
			{
			byte b = B[j];
			const bool LeftB = (j == 0);
			const bool RightB = (j == LB-1);
			
		// xM
			{
			if (Box.InBoxDPM(i+1, j+1))
				{
				float Match = MxRow[b];
				float MM = DPM[i][j] + Match;
				float DM = DPD[i][j] + Match;
				float IM = DPI[i][j] + Match;
				Max_xM(DPM[i+1][j+1], MM, DM, IM, TBM[i+1][j+1]);
				}
			else
				{
				DPM[i+1][j+1] = MINUS_INFINITY;
				TBM[i+1][j+1] = '*';
				}
			}
			
		// xD
			{
			if (Box.InBoxDPD(i+1, j+1))
				{
				float EdgeMD = (RightB ? AP.ROpenB : AP.OpenB);
				float EdgeDD = (RightB ? AP.RExtB : AP.ExtB);
				float MD = DPM[i][j+1] + EdgeMD;
				float DD = DPD[i][j+1] + EdgeDD;
				Max_xD(DPD[i+1][j+1], MD, DD, TBD[i+1][j+1]);
				}
			else
				{
				DPD[i+1][j+1] = MINUS_INFINITY;
				TBD[i+1][j+1] = '*';
				}
			}
			
		// xI
			{
			if (Box.InBoxDPI(i+1, j+1))
				{
				float EdgeMI = (RightA ? AP.ROpenA : AP.OpenA);
				float EdgeII = (RightA ? AP.RExtA : AP.ExtA);
				float MI = DPM[i+1][j] + EdgeMI;
				float II = DPI[i+1][j] + EdgeII;
				Max_xI(DPI[i+1][j+1], MI, II, TBI[i+1][j+1]);
				}
			else
				{
				DPI[i+1][j+1] = MINUS_INFINITY;
				TBI[i+1][j+1] = '*';
				}
			}
			}
		}
	
	float FinalM = DPM[LA][LB];
	float FinalD = DPD[LA][LB];
	float FinalI = DPI[LA][LB];
	
	float Score = FinalM;
	byte State = 'M';
	if (FinalD > Score)
		{
		Score = FinalD;
		State = 'D';
		}
	if (FinalI > Score)
		{
		Score = FinalI;
		State = 'I';
		}

	const char *Path = TraceBack(LA, LB, State);
#if	TRACE
	g_MxDPM.LogMe();
	g_MxDPD.LogMe();
	g_MxDPI.LogMe();

	g_MxTBM.LogMe();
	g_MxTBD.LogMe();
	g_MxTBI.LogMe();
#endif
	return Path;
	}
