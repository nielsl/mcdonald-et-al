#include "myutils.h"
#include "dp.h"
#include "timing.h"

double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path);

void GetColTypeCounts(const byte *A, const byte *B, const char *Path,
  unsigned &LA, unsigned &LB, unsigned &PairCount, unsigned &SameCount,
  unsigned &InternalGapCount, unsigned &TerminalGapCount)
	{
	PairCount = 0;
	SameCount = 0;
	InternalGapCount = 0;
	TerminalGapCount = 0;

	unsigned pa = 0;
	unsigned pb = 0;
	unsigned GapCount = 0;
	unsigned PathLength = 0;
	for (unsigned i = 0; ; ++i)
		{
		char c = Path[i];
		if (c == 0)
			{
			PathLength = i;
			break;
			}
		if (c == 'M')
			{
			byte a = A[pa];
			byte b = B[pb];
			++PairCount;
			if (toupper(a) == toupper(b))
				++SameCount;
			}

		if (c == 'D' || c == 'I')
			++GapCount;
		if (c == 'M' || c == 'D')
			++pa;
		if (c == 'M' || c == 'I')
			++pb;
		}

	for (unsigned i = 0; i < PathLength; ++i)
		{
		char c = Path[i];
		if (c != 'D' && c != 'I')
			break;
		++TerminalGapCount;
		}

	for (unsigned i = 0; i < PathLength; ++i)
		{
		char c = Path[PathLength - i - 1];
		if (c != 'D' && c != 'I')
			break;
		++TerminalGapCount;
		}

	LA = pa;
	LB = pb;
	asserta(TerminalGapCount >= InternalGapCount);
	InternalGapCount = GapCount - TerminalGapCount;
	}

double GetFractIdGivenPath(const byte *A, const byte *B, const char *Path)
	{
	if (Path == 0)
		return 0.0;

	if (opt_idprefix > 0)
		{
		for (unsigned i = 0; i < opt_idprefix; ++i)
			{
			char c = Path[i];
			if (c != 'M' || toupper(A[i]) != toupper(B[i]))
				return 0.0;
			}
		}

	StartTimer(GetFractIdGivenPath);
	unsigned PosA = 0;
	unsigned PosB = 0;
	unsigned Ids = 0;
	for (const char *p = Path; *p; ++p)
		{
		char c = *p;
		if (c == 'M' && toupper(A[PosA]) == toupper(B[PosB]))
			++Ids;
		if (c == 'M' || c == 'D')
			++PosA;
		if (c == 'M' || c == 'I')
			++PosB;
		}
	unsigned MinLen = min(PosA, PosB);
	double FractId = (MinLen == 0 ? 0.0 : double(Ids)/double(MinLen));
	EndTimer(GetFractIdGivenPath);
	return FractId;
	}

void LogAln(const byte *A, const byte *B, const char *Path)
	{
	unsigned p = 0;
	for (unsigned i = 0; ; ++i)
		{
		char c = Path[i];
		if (c == 0)
			break;
		if (c == 'M' || c == 'D')
			Log("%c", A[p++]);
		else
			Log("-");
		}
	Log("\n");

	unsigned pa = 0;
	unsigned pb = 0;
	for (unsigned i = 0; ; ++i)
		{
		char c = Path[i];
		if (c == 0)
			break;
		if (c == 'M')
			{
			if (toupper(A[pa]) == toupper(B[pb]))
				Log("|");
			else
				Log(" ");
			}
		else
			Log(" ");
		if (c == 'M' || c == 'D')
			++pa;
		if (c == 'M' || c == 'I')
			++pb;
		}
	Log("\n");

	p = 0;
	for (unsigned i = 0; ; ++i)
		{
		char c = Path[i];
		if (c == 0)
			break;
		if (c == 'M' || c == 'I')
			Log("%c", B[p++]);
		else
			Log("-");
		}
	Log("\n");

	unsigned LA, LB, PairCount, SameCount, InternalGapCount, TerminalGapCount;
	GetColTypeCounts(A, B, Path, LA, LB, PairCount, SameCount, InternalGapCount, TerminalGapCount);

	Log("Identities %u/%u = %.1f%%\n",
	  SameCount, PairCount, Pct(SameCount, PairCount));
	}

void LogAln(const byte *A, const byte *B, const string &Path)
	{
	LogAln(A, B, Path.c_str());
	}

void LogAln(const SegPair &SP, const char *Path)
	{
	LogAln(SP.A + SP.LoA, SP.B + SP.LoB, Path);
	}
