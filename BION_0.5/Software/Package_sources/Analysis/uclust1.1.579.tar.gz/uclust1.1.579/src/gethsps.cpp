#include "myutils.h"
#include "hspfinder.h"
#include "timing.h"
#include "diagbox.h"
#include <algorithm>

#define	TRACE_GETHSPS		0
#define	TRACE_HSPS			0

//const unsigned SeedSpacing = 16;
//const float MinInnerScore = 18.0;

double HSPFinder::GetHSPs(vector<HSPData> &HSPs)
	{
	StartTimer(WF_GetHSPs);

	HSPs.clear();

	extern float **g_SubstMx;
	const float * const *SM = g_SubstMx;

#if	TRACE_GETHSPS
	Log("\n");
	Log("A>%s\n", m_LabelA);
	Log("B>%s\n", m_LabelB);
	Log("A=%*.*s\n", m_LA, m_LA, m_A);
	Log("B=%*.*s\n", m_LB, m_LB, m_B);
#endif

#if	DEBUG
	const unsigned DiagCount = m_LA + m_LB - 1;
#endif

	unsigned dlo, dhi;
	GetPlausibleDiagRange(dlo, dhi);

	unsigned PosB1 = 0;
/***
Example, k=3, minhsp=9, offset=6
		123456789
		AAABBBCCC
Offset:	0123456
***/
	if (opt_hsp <= 2*m_WordLength)
		Die("Min HSP <= 2*word length");
	unsigned PairOffset = opt_hsp - m_WordLength;
	asserta(PairOffset > m_WordLength);
	float MinInnerScore = float((opt_hsp - 2*m_WordLength)*opt_hspscore);
	unsigned EndPos = m_LB - m_WordLength + 1;
	for (;;)
		{
		unsigned PosB2 = PosB1 + PairOffset;
		if (PosB2 >= EndPos)
			break;

		unsigned Word1 = m_WordsB[PosB1];
		assert(Word1 < m_WordCount);
#if	TRACE_GETHSPS
		Log("PosB1=%u Word1=%s WCA=%u\n",
		  PosB1, WordToStr(Word1), m_WordCountsA[Word1]);
#endif

		unsigned N1 = m_WordCountsA[Word1];
		if (N1 == 0)
			{
			++PosB1;
			continue;
			}

		unsigned Word2 = m_WordsB[PosB2];
		assert(Word2 < m_WordCount);
#if	TRACE_GETHSPS
		Log(" PosB2=%u Word2=%s WCA=%u\n",
		  PosB2, WordToStr(Word2), m_WordCountsA[Word2]);
#endif

		unsigned N2 = m_WordCountsA[Word2];
		if (N2 == 0)
			{
			++PosB1;
			continue;
			}

		unsigned PosA1 = m_WordToPosA[Word1*MaxReps];
		unsigned PosA2 = m_WordToPosA[Word2*MaxReps];

		unsigned Diag1 = (m_LA + PosB1) - PosA1;
		unsigned Diag2 = (m_LA + PosB2) - PosA2;

		assert(Diag1 > 0);
		assert(Diag1 < DiagCount);
		assert(Diag2 > 0);
		assert(Diag2 < DiagCount);

#if	TRACE_GETHSPS
		Log("  Diags=%u, %u\n", Diag1, Diag2);
#endif

		if (Diag1 != Diag2)
			{
			++PosB1;
			continue;
			}

		if (Diag1 < dlo || Diag1 > dhi)
			{
			++PosB1;
			continue;
			}

	// Have spaced pair of matching words on same diagonal.
	// Now check if score of segment between words is +ve.
#if	TRACE_GETHSPS
		{
		Log("Score inner\n");
		Log("A=");
		for (unsigned PosB = PosB1; PosB < PosB2 + m_WordLength; ++PosB)
			{
			unsigned PosA = m_LA + PosB - Diag1;
			assert(PosA < m_LA);
			byte a = m_A[PosA];
			Log("%c", a);
			}
		Log("\n");
		Log("B=");
		for (unsigned PosB = PosB1; PosB < PosB2 + m_WordLength; ++PosB)
			{
			byte b = m_B[PosB];
			Log("%c", b);
			}
		Log("\n");
		}
#endif
		unsigned SameCount = 2*m_WordLength;
		float Score = 0.0f;
		for (unsigned PosB = PosB1 + m_WordLength; PosB < PosB2; ++PosB)
			{
		// d = LA - i + j
		// i = LA + j - d
			unsigned PosA = m_LA + PosB - Diag1;
			assert(PosA < m_LA);
			byte a = m_A[PosA];
			byte b = m_B[PosB];
			if (a == b)
				++SameCount;
			Score += SM[a][b];
#if	TRACE_GETHSPS
			Log(" %c%c=%.1f", a, b, SM[a][b]);
#endif
			}

#if	TRACE_GETHSPS
		Log(" = %.1f\n", Score);
#endif
		if (Score < MinInnerScore)
			{
			PosB1 = PosB2 + 1;
			continue;
			}

		unsigned Diag = Diag1;
		unsigned Blo = PosB1;
		unsigned Bhi = PosB2 + m_WordLength - 1;
		unsigned Alo = m_LA + Blo - Diag;
		unsigned Ahi = m_LA + Bhi - Diag;

	// Extend diagonal backwards until
	// subst score <= 0.
		for (;;)
			{
			if (Alo == 0 || Blo == 0)
				break;
			byte a = m_A[--Alo];
			byte b = m_B[--Blo];
			float Score = SM[a][b];
#if	TRACE_GETHSPS
			Log("Bwd: %c%c=%.1f\n", a, b, Score);
#endif
			if (Score <= 0)
				{
				++Alo;
				++Blo;
				break;
				}
			if (a == b)
				++SameCount;
			}

	// Extend diagonal forwards until
	// subst score <= 0.
		for (;;)
			{
			if (Ahi+1 >= m_LA || Bhi+1 >= m_LB)
				break;
			byte a = m_A[Ahi+1];
			byte b = m_B[Bhi+1];
			float Score = SM[a][b];
#if	TRACE_GETHSPS
			Log("Fwd: %c%c=%.1f\n", a, b, Score);
#endif
			if (Score <= 0)
				break;
			if (a == b)
				++SameCount;
			++Ahi;
			++Bhi;
			}

		unsigned HSPLength = Ahi - Alo + 1;
		assert(Bhi - Blo + 1 == HSPLength);

		HSPData HSP;
		HSP.Alo = Alo;
		HSP.Blo = Blo;
		HSP.Length = HSPLength;
		HSP.SameCount = SameCount;

		assert(HSP.GetAhi() < m_LA);
		assert(HSP.GetBhi() < m_LB);

#if	TRACE_GETHSPS
		Log("New HSP:");
		HSP.LogMe();
#endif

		HSPs.push_back(HSP);
		PosB1 = Bhi + 1;
		}

	unsigned N = SIZE(HSPs);
	
	unsigned TotalLength = 0;
	unsigned TotalSameCount = 0;

	for (unsigned i = 0; i < N; ++i)
		{
		const HSPData &HSP = HSPs[i];
		TotalLength += HSP.Length;
		TotalSameCount += HSP.SameCount;
		}

	double FractId = TotalLength == 0 ? 0.0 :
	  double(TotalSameCount)/double(TotalLength);

	PauseTimer(WF_GetHSPs);
	StartTimer(WF_ResolveHSPs);
	sort(HSPs.begin(), HSPs.end());
	for (;;)
		{
		if (HSPs.empty())
			break;
		bool AnyErased = false;
		const HSPData *PrevHSP = &HSPs.front();
		for (vector<HSPData>::iterator p = HSPs.begin() + 1;
		  p != HSPs.end(); ++p)
			{
			const HSPData &HSP = *p;

			if (PrevHSP->GetAhi() >= HSP.Alo || PrevHSP->GetBhi() >= HSP.Blo)
				{
				if (PrevHSP->Length >= HSP.Length)
					HSPs.erase(p);
				else
					HSPs.erase(p-1);
				AnyErased = true;
				break;
				}

			PrevHSP = &HSP;
			}
		if (!AnyErased)
			break;
		}
	EndTimer(WF_ResolveHSPs);
	StartTimer(WF_GetHSPs);

#if	TRACE_GETHSPS || TRACE_HSPS
	{
	unsigned N = SIZE(HSPs);
	Log("\n");
	Log("%u HSPs, id = %.1f\n", N, 100*FractId);
	for (unsigned i = 0; i < N; ++i)
		{
		const HSPData &HSP = HSPs[i];
		unsigned Alo = HSP.Alo;
		unsigned Blo = HSP.Blo;
		unsigned Ahi = Alo + HSP.Length - 1;
		unsigned Bhi = Blo + HSP.Length - 1;
		unsigned Diag = (m_LA + Blo) - Alo;
		Log("HSP[%u] diag %u id=%u/%u=%.1f%%:\n", i,
		  Diag, HSP.SameCount, HSP.Length, Pct(HSP.SameCount, HSP.Length));
		Log("A %4u-%4u = ", Alo, Ahi);
		for (unsigned PosA = Alo; PosA <= Ahi; ++PosA)
			{
			byte a = m_A[PosA];
			Log("%c", a);
			}
		Log("\n");
		Log("B %4u-%4u = ", Blo, Bhi);
		for (unsigned PosB = Blo; PosB <= Bhi; ++PosB)
			{
			byte b = m_B[PosB];
			Log("%c", b);
			}
		Log("\n");
		}
	}
#endif

	EndTimer(WF_GetHSPs);

	return FractId;
	}
