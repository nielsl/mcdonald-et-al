#ifndef alnparams_h
#define alnparams_h

struct SegPair;

// Gap penalty scores are negative
// (i.e., are scores, not penalties).
struct AlnParams
	{
	const float * const *SubstMx;

// Internal gaps
	float OpenA;
	float OpenB;

	float ExtA;
	float ExtB;

// Terminal gaps
	float LOpenA;
	float LOpenB;
	float ROpenA;
	float ROpenB;

	float LExtA;
	float LExtB;
	float RExtA;
	float RExtB;

	void Clear();
	void Init2(const float * const *Mx, float Open, float Ext);
	void Init4(const float * const *Mx, float Open, float Ext, float TermOpen, float TermExt);
	void Init(const AlnParams &AP, const SegPair &SP);
	void InitFromCmdLine(bool Nucleo);
	void SetPenalties(const string &OpenStr, const string &ExtStr);

	bool Is2() const;
	bool Is4() const;
	const char *GetType() const;

	void LogMe() const;
	};

const float OBVIOUSLY_WRONG_PENALTY = 1000.0;

#endif // alnparams_h
