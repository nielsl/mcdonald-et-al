#include "dp.h"

#define TRACE		0

#if	TRACE
#undef SAVE_FAST
#define SAVE_FAST	1
#endif

#if	SAVE_FAST
static Mx<float> g_MxDPM;
static Mx<float> g_MxDPD;
static Mx<float> g_MxDPI;

static Mx<char> g_MxTBM;
static Mx<char> g_MxTBD;
static Mx<char> g_MxTBI;

static float **g_DPM;
static float **g_DPD;
static float **g_DPI;

static char **g_TBM;
static char **g_TBD;
static char **g_TBI;

static void AllocSave(unsigned LA, unsigned LB)
	{
	g_MxDPM.Alloc("FastBandM", LA+1, LB+1);
	g_MxDPD.Alloc("FastBandD", LA+1, LB+1);
	g_MxDPI.Alloc("FastBandI", LA+1, LB+1);

	g_MxTBM.Alloc("FastBandTBM", LA+1, LB+1);
	g_MxTBD.Alloc("FastBandTBD", LA+1, LB+1);
	g_MxTBI.Alloc("FastBandTBI", LA+1, LB+1);

	g_DPM = g_MxDPM.GetData();
	g_DPD = g_MxDPD.GetData();
	g_DPI = g_MxDPI.GetData();

	g_TBM = g_MxTBM.GetData();
	g_TBD = g_MxTBD.GetData();
	g_TBI = g_MxTBI.GetData();
	}

static void SAVE_DPM(unsigned i, unsigned j, float x)
	{
	g_DPM[i][j] = x;
	}

static void SAVE_DPD(unsigned i, unsigned j, float x)
	{
	g_DPD[i][j] = x;
	}

static void SAVE_DPI(unsigned i, unsigned j, float x)
	{
	g_DPI[i][j] = x;
	}

static void SAVE_TBM(unsigned i, unsigned j, char x)
	{
	g_TBM[i][j] = x;
	}

static void SAVE_TBD(unsigned i, unsigned j, char x)
	{
	g_TBD[i][j] = x;
	}

static void SAVE_TBI(unsigned i, unsigned j, char x)
	{
	g_TBI[i][j] = x;
	}

void GetFastBandMxs(Mx<float> **M, Mx<float> **D, Mx<float> **I)
	{
	*M = &g_MxDPM;
	*D = &g_MxDPD;
	*I = &g_MxDPI;
	}

#else	// SAVE_FAST

#define	SAVE_DPM(i, j, x)	/* empty */
#define	SAVE_DPD(i, j, x)	/* empty */
#define	SAVE_DPI(i, j, x)	/* empty */

#define	SAVE_TBM(i, j, x)	/* empty */
#define	SAVE_TBD(i, j, x)	/* empty */
#define	SAVE_TBI(i, j, x)	/* empty */

#define AllocSave(LA, LB)	/* empty */

#endif	// SAVE_FAST

const char *ViterbiFastBand(const SegPair &SP, const AlnParams &AP,
  unsigned DiagLo, unsigned DiagHi)
	{
#if	TRACE
	Log("\n");
	Log("ViterbiFastBand\n");
	Log("SP: ");
	SP.LogMe();
	Log("AP: ");
	AP.LogMe();
#endif
	const byte *A = SP.A + SP.LoA;
	const byte *B = SP.B + SP.LoB;
	const unsigned LA = SP.GetSegLenA();
	const unsigned LB = SP.GetSegLenB();

	asserta(LA > 0 && LB > 0);
	asserta(DiagLo <= DiagHi);

// Verify diagonal range includes terminals
	DiagBox Box(LA, LB, DiagLo, DiagHi);
	asserta(Box.InBox(0, 0));
	asserta(Box.InBox(LA-1, LB-1));

	AllocBit(LA, LB);
	AllocSave(LA, LB);

	StartTimer(ViterbiFastBand);
	
	const float * const *Mx = AP.SubstMx;
	float OpenA = AP.LOpenA;
	float ExtA = AP.LExtA;

	float *Mrow = g_DPRow1;
	byte **TB = g_TBBit;
	float *Drow = g_DPRow2;

// Use Mrow[j-1] when j=0, so...
	Mrow[-1] = MINUS_INFINITY;

// TODO: surely don't need to initialize all entries in vector
	for (unsigned j = 0; j <= LB; ++j)
		{
		Mrow[j] = MINUS_INFINITY;
		SAVE_DPM(0, j, MINUS_INFINITY);
		SAVE_TBM(0, j, '?');

		Drow[j] = MINUS_INFINITY;
		SAVE_DPD(0, j, MINUS_INFINITY);
		SAVE_TBD(0, j, '?');
		}

// Main loop
	SAVE_DPM(0, 0, 0);

	for (unsigned i = 0; i < LA; ++i)
		{
		unsigned Startj, Endj;
		Box.GetRange_j(i, Startj, Endj);
#if	TRACE
		Log("i=%u j=%u..%u\n", i, Startj, Endj);
#endif
		if (Endj == 0)
			{
			static bool WarningDone = false;
			if (!WarningDone)
				{
				Warning("Endj==0");
				WarningDone = true;
				}
			continue;
			}

		float OpenB = Startj == 0 ? AP.LOpenB : AP.OpenB;
		float ExtB = Startj == 0 ? AP.LExtB : AP.ExtB;

		byte a = A[i];
		const float *MxRow = Mx[a];
		float I0 = MINUS_INFINITY;
		float M0;
		if (i == 0)
			M0 = 0;
		else
			{
			if (Startj == 0)
				M0 = MINUS_INFINITY;
			else
				M0 = Mrow[int(Startj)-1];
			}

		SAVE_TBM(i, 0, '?');

		SAVE_DPI(i, 0, MINUS_INFINITY);
		SAVE_DPI(i, 1, MINUS_INFINITY);

		SAVE_TBI(i, 0, '?');
		SAVE_TBI(i, 1, '?');
		
		byte *TBrow = TB[i];
		if (Startj > 0)
			TBrow[int(Startj)-1] = TRACEBITS_IM;

#if	SAVE_FAST
		{
		for (unsigned j = 0; j < Startj; ++j)
			{
			SAVE_DPM(i+1, j+1, MINUS_INFINITY);
			SAVE_TBM(i+1, j+1, '*');

			SAVE_DPD(i+1, j, MINUS_INFINITY);
			SAVE_TBD(i+1, j, '*');

			SAVE_DPI(i, j+1, MINUS_INFINITY);
			SAVE_TBI(i+1, j, '*');
			}
		}
#endif
		for (unsigned j = Startj; j < Endj; ++j)
			{
			byte b = B[j];
			byte TraceBits = 0;
			float SavedM0 = M0;

		// MATCH
			{
		// M0 = DPM[i][j]
		// I0 = DPI[i][j]
		// Drow[j] = DPD[i][j]
			
			float xM = M0;
			SAVE_TBM(i+1, j+1, 'M');
			if (Drow[j] > xM)
				{
				xM = Drow[j];
				TraceBits = TRACEBITS_DM;
				SAVE_TBM(i+1, j+1, 'D');
				}
			if (I0 > xM)
				{
				xM = I0;
				TraceBits = TRACEBITS_IM;
				SAVE_TBM(i+1, j+1, 'I');
				}
			M0 = Mrow[j];
			Mrow[j] = xM + MxRow[b];
		// Mrow[j] = DPM[i+1][j+1])
			SAVE_DPM(i+1, j+1, Mrow[j]);
			}
			
		// DELETE
			{
		// SavedM0 = DPM[i][j]
		// Drow[j] = DPD[i][j]
			
			float md = SavedM0 + OpenB;
			Drow[j] += ExtB;
			SAVE_TBD(i+1, j, 'D');
			if (md >= Drow[j])
				{
				Drow[j] = md;
				TraceBits |= TRACEBITS_MD;
				SAVE_TBD(i+1, j, 'M');
				}
		// Drow[j] = DPD[i+1][j]
			SAVE_DPD(i+1, j, Drow[j]);
			}
			
		// INSERT
			{
		// SavedM0 = DPM[i][j]
		// I0 = DPI[i][j]
			
			float mi = SavedM0 + OpenA;
			I0 += ExtA;
			SAVE_TBI(i, j+1, 'I');
			if (mi >= I0)
				{
				I0 = mi;
				TraceBits |= TRACEBITS_MI;
				SAVE_TBI(i, j+1, 'M');
				}
		// I0 = DPI[i][j+1]
			SAVE_DPI(i, j+1, I0);
			}
			
			OpenB = AP.OpenB;
			ExtB = AP.ExtB;
			
			TBrow[j] = TraceBits;
			}

#if	SAVE_FAST
		{
		for (unsigned j = Endj; j < LB; ++j)
			{
			SAVE_DPM(i+1, j+1, MINUS_INFINITY);
			SAVE_TBM(i+1, j+1, '*');

			SAVE_DPD(i+1, j, MINUS_INFINITY);
			SAVE_TBD(i+1, j, '*');

			SAVE_DPI(i, j+1, MINUS_INFINITY);
			SAVE_TBI(i+1, j, '*');
			}
		}
#endif
		
	// Special case for end of Drow[]
		{
	// M0 = DPM[i][LB]
	// Drow[LB] = DPD[i][LB]
		
		TBrow[LB] = 0;
		float md = M0 + AP.ROpenB;
		Drow[LB] += AP.RExtB;
		SAVE_TBD(i+1, LB, 'D');
		if (md >= Drow[LB])
			{
			Drow[LB] = md;
			TBrow[LB] = TRACEBITS_MD;
			SAVE_TBD(i+1, LB, 'M');
			}
	// Drow[LB] = DPD[i+1][LB]
		SAVE_DPD(i+1, LB, Drow[LB]);
		}
		
		SAVE_DPM(i+1, 0, MINUS_INFINITY);
		M0 = MINUS_INFINITY;

		OpenA = AP.OpenA;
		ExtA = AP.ExtA;
		}
	
	SAVE_TBM(LA, 0, '?');

	SAVE_DPI(LA, 0, MINUS_INFINITY);
	SAVE_TBI(LA, 0, '?');

	SAVE_DPI(LA, 1, MINUS_INFINITY);
	SAVE_TBI(LA, 1, '?');

	unsigned Startj, Endj;
	Box.GetRange_j(LA-1, Startj, Endj);
	asserta(Endj == LB);
#if	SAVE_FAST
	{
	for (unsigned j = 0; j < Startj; ++j)
		{
		SAVE_DPM(LA, j+1, MINUS_INFINITY);
		SAVE_TBM(LA, j+1, '*');

		SAVE_DPD(LA, j, MINUS_INFINITY);
		SAVE_TBD(LA, j, '*');

		SAVE_DPI(LA-1, j+1, MINUS_INFINITY);
		SAVE_TBI(LA, j, '*');
		}
	}
#endif

// Special case for last row of DPI
	byte *TBrow = TB[LA];
	float I1 = MINUS_INFINITY;
	Mrow[int(Startj)-1] = MINUS_INFINITY;
	for (unsigned j = Startj; j < Endj; ++j)
		{
	// Mrow[j-1] = DPM[LA][j]
	// I1 = DPI[LA][j]
		TBrow[j] = 0;
		float mi = Mrow[int(j)-1] + AP.ROpenA;
		I1 += AP.RExtA;
		SAVE_TBI(LA, j+1, 'I');
		if (mi > I1)
			{
			I1 = mi;
			TBrow[j] = TRACEBITS_MI;
			SAVE_TBI(LA, j+1, 'M');
			}
		SAVE_DPI(LA, j+1, I1);
		}
	
	float FinalM = Mrow[LB-1];
	float FinalD = Drow[LB];
	float FinalI = I1;
// FinalM = DPM[LA][LB]
// FinalD = DPD[LA][LB]
// FinalI = DPI[LA][LB]
	
	float Score = FinalM;
	byte State = 'M';
	if (FinalD > Score)
		{
		Score = FinalD;
		State = 'D';
		}
	if (FinalI > Score)
		{
		Score = FinalI;
		State = 'I';
		}

#if	TRACE
	g_MxDPM.LogMe();
	g_MxDPD.LogMe();
	g_MxDPI.LogMe();

	g_MxTBM.LogMe();
	g_MxTBD.LogMe();
	g_MxTBI.LogMe();
#endif

	EndTimer(ViterbiFastBand);
	const char *Path = TraceBackBit(LA, LB, State);
#if	DEBUG
	{
	unsigned NA, NB;
	void GetLetterCounts(const char *Path, unsigned &NA, unsigned &NB);
	GetLetterCounts(Path, NA, NB);
	asserta(NA == LA);
	asserta(NB == LB);
	}
#endif
	return Path;
	}

const char *ViterbiFastMainDiag(const SegPair &SP, const AlnParams &AP,
  unsigned BandWidth)
	{
// Main diagonal
// d = LA - i + j = 1 .. LA+LB-1
// Left term: i=0,j=0 d=LA
// Right term: i=LA-1,j=LB-1 d=LA-(LA-1)+(LB-1) = LB
	unsigned DiagLo = min(SP.SA, SP.SB);
	unsigned DiagHi = max(SP.SA, SP.SB);
	if (DiagLo > BandWidth)
		DiagLo -= BandWidth;
	else
		DiagLo = 1;
	DiagHi += BandWidth;
	unsigned MaxDiag = SP.SA + SP.SB - 1;
	if (DiagHi > MaxDiag)
		DiagHi = MaxDiag;
	return ViterbiFastBand(SP, AP, DiagLo, DiagHi);
	}
