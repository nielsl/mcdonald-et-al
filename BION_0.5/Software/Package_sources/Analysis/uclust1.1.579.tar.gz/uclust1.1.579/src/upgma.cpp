#include "myutils.h"
#include "upgma.h"
#include <float.h>

// UPGMA clustering in O(N^2) time and space.
// Adapted from MUSCLE code.

#define	TRACE	0

#define	MIN(x, y)	((x) < (y) ? (x) : (y))
#define	MAX(x, y)	((x) > (y) ? (x) : (y))
#define	AVG(x, y)	(((x) + (y))/2)

void UPGMA::LogTreeRecurse(unsigned NodeIndex) const
	{
	asserta(NodeIndex < 2*m_LeafCount - 1);

	if (IsLeaf(NodeIndex))
		Log("%7u  %7.7s  %7.7s  %7.7s  %7.7s  %7.7s  %s\n",
		  NodeIndex, "", "", "", "", "", m_Labels[NodeIndex]);
	else
		{
		unsigned Left = m_Left[NodeIndex - m_LeafCount];
		unsigned Right = m_Right[NodeIndex - m_LeafCount];
		float LBranch = m_LeftLength[NodeIndex - m_LeafCount];
		float RBranch = m_RightLength[NodeIndex - m_LeafCount];
		float Height = m_Height[NodeIndex - m_LeafCount];
		Log("%7u  %7u  %7u  %7.4f  %7.4f  %7.4f",
		  NodeIndex, Left, Right, LBranch, RBranch, Height);
		if (IsRoot(NodeIndex))
			Log("  [Root]");
		Log("\n");

		LogTreeRecurse(Left);
		LogTreeRecurse(Right);
		}
	}

void UPGMA::LogTree() const
	{
	Log("\n");
	Log("Tree:\n");
	Log("   Node     Left    Right  LBranch  RBranch   Height  Label\n");
	Log("-------  -------  -------  -------  -------  -------  -----\n");
	LogTreeRecurse(GetRoot());
	}

void UPGMA::LogMe() const
	{
	Log("\n");
	Log("UPGMA %u leaves\n", m_LeafCount);
	Log("     ");
	for (unsigned i = 0; i < m_LeafCount; ++i)
		{
		if (m_NodeIndex[i] == UINT_MAX)
			continue;
		Log("  %5u", m_NodeIndex[i]);
		}
	Log("\n");

	for (unsigned i = 0; i < m_LeafCount; ++i)
		{
		if (m_NodeIndex[i] == UINT_MAX)
			continue;
		Log("%5u  ", m_NodeIndex[i]);
		for (unsigned j = 0; j < m_LeafCount; ++j)
			{
			if (m_NodeIndex[j] == UINT_MAX)
				continue;
			if (i == j)
				Log("       ");
			else
				Log("%5.2g  ", (double) GetDist(i, j));
			}
		Log("\n");
		}

	Log("\n");
	Log("    i   Node   NrNb   MinDist\n");
	Log("-----  -----  -----  --------\n");
	for (unsigned i = 0; i < m_LeafCount; ++i)
		{
		if (m_NodeIndex[i] == UINT_MAX)
			continue;
		Log("%5u", i);
		Log("  %5u", m_NodeIndex[i]);
		Logu(m_NearestNeighbor[i], 5);
		Logf(m_MinDist[i], 8);
		Log("\n");
		}

	Log("\n");
	Log(" Node      L      R   Height  LLength  RLength\n");
	Log("-----  -----  -----  -------  -------  -------\n");
	for (unsigned i = 0; i <= m_InternalNodeIndex; ++i)
		{
		Log("%5u", i);
		Logu(m_Left[i], 5);
		Logu(m_Right[i], 5);
		Logf(m_Height[i], 7);
		Logf(m_LeftLength[i], 7);
		Logf(m_RightLength[i], 7);
		Log("\n");
		}
	}

UPGMA::UPGMA()
	{
	Clear(true);
	}

void UPGMA::Clear(bool ctor)
	{
	if (!ctor)
		{
	// Not m_Dist or m_Labels (caller allocates).
		myfree(m_NearestNeighbor);
		myfree(m_NodeIndex);
		myfree(m_Left);
		myfree(m_Right);
		myfree(m_MinDist);
		myfree(m_Height);
		myfree(m_LeftLength);
		myfree(m_RightLength);
		}

	m_Dist = 0;
	m_Labels = 0;
	m_Linkage = LINKAGE_Avg;
	m_Bias = 0.0f;

	m_NearestNeighbor = 0;
	m_NodeIndex = 0;
	m_Left = 0;
	m_Right = 0;

	m_Dist = 0;
	m_MinDist = 0;
	m_Height = 0;
	m_LeftLength = 0;
	m_RightLength = 0;
	m_Labels = 0;

	m_LeafCount = UINT_MAX;
	m_InternalNodeIndex = UINT_MAX;
	}

void UPGMA::Alloc(unsigned LeafCount)
	{
	m_LeafCount = LeafCount;

// Per-leaf vectors
	m_NodeIndex = myalloc<unsigned>(m_LeafCount);
	m_NearestNeighbor = myalloc<unsigned>(m_LeafCount);
	m_MinDist = myalloc<dist_t>(m_LeafCount);

// Per-internal node vctors
	unsigned InternalNodeCount = m_LeafCount - 1;
	m_Left = myalloc<unsigned>(InternalNodeCount);
	m_Right = myalloc<unsigned>(InternalNodeCount);
	m_Height = myalloc<dist_t>(InternalNodeCount);
	m_LeftLength = myalloc<dist_t>(InternalNodeCount);
	m_RightLength = myalloc<dist_t>(InternalNodeCount);
	}

void UPGMA::InitState()
	{
	asserta(m_LeafCount > 2);

	for (unsigned i = 0; i < m_LeafCount; ++i)
		m_NodeIndex[i] = i;

	unsigned InternalNodeCount = m_LeafCount - 1;
	for (unsigned i = 0; i < InternalNodeCount; ++i)
		{
		m_Left[i] = UINT_MAX;
		m_Right[i] = UINT_MAX;
		m_LeftLength[i] = FLT_MAX;
		m_RightLength[i] = FLT_MAX;
		m_Height[i] = FLT_MAX;
		}

// Initialize m_MinDist and m_NearestNeighbor
	for (unsigned i = 0; i < m_LeafCount; ++i)
		{
		m_MinDist[i] = FLT_MAX;
		m_NearestNeighbor[i] = UINT_MAX;

		const dist_t *Row = m_Dist + Trix(i, 0);
		for (unsigned j = 0; j < i; ++j)
			{
			const dist_t d = Row[j];
			if (d < m_MinDist[i])
				{
				m_MinDist[i] = d;
				m_NearestNeighbor[i] = j;
				}
			if (d < m_MinDist[j])
				{
				m_MinDist[j] = d;
				m_NearestNeighbor[j] = i;
				}
			}
		}
	m_InternalNodeIndex = 0;
	}

dist_t UPGMA::Link(dist_t dL, dist_t dR) const
	{
	switch (m_Linkage)
		{
	case LINKAGE_Avg:
		return AVG(dL, dR);

	case LINKAGE_Min:
		return MIN(dL, dR);

	case LINKAGE_Max:
		return MAX(dL, dR);

	case LINKAGE_Biased:
		return m_Bias*AVG(dL, dR) + (1 - m_Bias)*MIN(dL, dR);

	default:
		Die("UPGMA::Link(): Invalid LINKAGE_%u", m_Linkage);
		}

	return dist_t(0);
	}

void UPGMA::GetNearestNeighbors(unsigned &Row1, unsigned &Row2) const
	{
	dist_t MinDist = FLT_MAX;
	for (unsigned i = 0; i < m_LeafCount; ++i)
		{
		if (m_NodeIndex[i] == UINT_MAX)
			continue;

		dist_t d = m_MinDist[i];
		if (d < MinDist)
			{
			MinDist = d;
			Row1 = i;
			Row2 = m_NearestNeighbor[i];
			assert(UINT_MAX != Row2);
			assert(UINT_MAX != m_NodeIndex[Row2]);
			}
		}

	assert(Row1 != UINT_MAX);
	assert(Row2 != UINT_MAX);
	assert(MinDist != FLT_MAX);

#if	TRACE
	Log("Nearest neighbors Row1=%u(Node=%u) Row2=%u(Node=%u) dist %.2f\n",
	  Row1,
	  m_NodeIndex[Row1],
	  Row2,
	  m_NodeIndex[Row2],
	  MinDist);
#endif
	}

void UPGMA::Init(dist_t *Dist, const char **Names, unsigned LeafCount)
	{
	Alloc(LeafCount);

	m_LeafCount = LeafCount;
	m_Dist = Dist;
	m_Labels = Names;
	}

// Dist is over-written, caller allocates for efficiency.
void UPGMA::Cluster(LINKAGE Linkage)
	{
	m_Linkage = Linkage;

	InitState();

#if	TRACE
	Log("Initial state:\n");
	LogMe();
#endif

	for (m_InternalNodeIndex = 0; m_InternalNodeIndex < m_LeafCount - 1;
	  ++m_InternalNodeIndex)
		{
#if	TRACE
		Log("\n");
		Log("MAIN LOOP: Internal node index %u\n", m_InternalNodeIndex);
#endif

	// Find nearest neighbors
		unsigned Lmin = UINT_MAX;
		unsigned Rmin = UINT_MAX;
		GetNearestNeighbors(Lmin, Rmin);

	// Compute distances to new node
	// New node overwrites row currently assigned to Lmin
		dist_t NewMinDist = FLT_MAX;
		unsigned NewNearestNeighbor = UINT_MAX;
		for (unsigned j = 0; j < m_LeafCount; ++j)
			{
			if (j == Lmin || j == Rmin)
				continue;
			if (m_NodeIndex[j] == UINT_MAX)
				continue;

			const unsigned vL = Trix(Lmin, j);
			const unsigned vR = Trix(Rmin, j);
			const dist_t dL = m_Dist[vL];
			const dist_t dR = m_Dist[vR];
			dist_t NewDist = Link(dL, dR);

		/***
		Nasty special case.
		If nearest neighbor of j is Lmin or Rmin, then make the new
		node (which overwrites the row currently occupied by Lmin)
		the nearest neighbor. This situation can occur when there are
		equal distances in the matrix. If we don't make this fix,
		the nearest neighbor pointer for j would become invalid.
		(We don't need to test for == Lmin, because in that case
		the net change needed is zero due to the change in row
		numbering).
		***/
			if (m_NearestNeighbor[j] == Rmin)
				m_NearestNeighbor[j] = Lmin;

#if	TRACE
			Log("New dist to %u = (%.2f[%u] + %.2f[%u])/2 = %.2f\n",
			  j, dL, Lmin, dR, Rmin, NewDist);
#endif
			m_Dist[vL] = NewDist;
			if (NewDist < NewMinDist)
				{
				NewMinDist = NewDist;
				NewNearestNeighbor = j;
				}
			}

		assert(m_InternalNodeIndex < m_LeafCount - 1 || FLT_MAX != NewMinDist);
		assert(m_InternalNodeIndex < m_LeafCount - 1 || UINT_MAX != NewNearestNeighbor);

		const unsigned v = Trix(Lmin, Rmin);
		const dist_t dLR = m_Dist[v];
		const dist_t NewHeight = dLR/2;
		const unsigned Left = m_NodeIndex[Lmin];
		const unsigned Right = m_NodeIndex[Rmin];
		const dist_t LeftHeight =
		  Left < m_LeafCount ? 0 : m_Height[Left - m_LeafCount];
		const dist_t RightHeight =
		  Right < m_LeafCount ? 0 : m_Height[Right - m_LeafCount];

		m_Left[m_InternalNodeIndex] = Left;
		m_Right[m_InternalNodeIndex] = Right;
		m_LeftLength[m_InternalNodeIndex] = NewHeight - LeftHeight;
		m_RightLength[m_InternalNodeIndex] = NewHeight - RightHeight;
		m_Height[m_InternalNodeIndex] = NewHeight;

	// Row for left child overwritten by row for new node
		m_NodeIndex[Lmin] = m_LeafCount + m_InternalNodeIndex;
		m_NearestNeighbor[Lmin] = NewNearestNeighbor;
		m_MinDist[Lmin] = NewMinDist;

	// Delete row for right child
		m_NodeIndex[Rmin] = UINT_MAX;

#if	TRACE
		Log("\nInternalNodeIndex=%u Lmin=%u Rmin=%u\n",
		  m_InternalNodeIndex, Lmin, Rmin);
		LogMe();
#endif
		}
	}

void UPGMA::GetDistsRecurse(unsigned NodeIndex, dist_t Dist,
  vector<unsigned> &LeafIndexes, vector<dist_t> &Dists,
  Mx<float> &DistMx) const
	{
	if (IsLeaf(NodeIndex))
		{
		LeafIndexes.push_back(NodeIndex);
		Dists.push_back(Dist);
		return;
		}

	unsigned Left = m_Left[NodeIndex - m_LeafCount];
	unsigned Right = m_Right[NodeIndex - m_LeafCount];
	float LBranch = m_LeftLength[NodeIndex - m_LeafCount];
	float RBranch = m_RightLength[NodeIndex - m_LeafCount];

	vector<unsigned> LLeafIndexes;
	vector<unsigned> RLeafIndexes;
	vector<dist_t> LDists;
	vector<dist_t> RDists;
	GetDistsRecurse(Left, LBranch, LLeafIndexes, LDists, DistMx);
	GetDistsRecurse(Right, RBranch, RLeafIndexes, RDists, DistMx);

	unsigned NL = SIZE(LDists);
	unsigned NR = SIZE(RDists);

	for (unsigned i = 0; i < NL; ++i)
		{
		unsigned L = LLeafIndexes[i];
		dist_t dL = LDists[i];
		for (unsigned j = 0; j < NR; ++j)
			{
			unsigned R = RLeafIndexes[j];
			dist_t dR = RDists[j];
			dist_t d = dL + dR;
			DistMx.Put(L, R, d);
			DistMx.Put(R, L, d);
			}
		}

	for (unsigned i = 0; i < NL; ++i)
		{
		unsigned k = LLeafIndexes[i];
		dist_t d = LDists[i];
		LeafIndexes.push_back(k);
		Dists.push_back(Dist+d);
		}

	for (unsigned i = 0; i < NR; ++i)
		{
		unsigned k = RLeafIndexes[i];
		dist_t d = RDists[i];
		LeafIndexes.push_back(k);
		Dists.push_back(Dist+d);
		}
	}

void UPGMA::GetDistMx(Mx<float> &DistMx) const
	{
	DistMx.Alloc("UPGMADistMx", m_LeafCount, m_LeafCount);
	vector<unsigned> LeafIndexes;
	vector<dist_t> Dists;
#if	DEBUG
	DistMx.Assign(float(-1));
#endif
	for (unsigned i = 0; i < m_LeafCount; ++i)
		DistMx.Put(i, i, float(0));
	unsigned Root = GetRoot();
	GetDistsRecurse(Root, 0, LeafIndexes, Dists, DistMx);
	}

void UPGMA::DistVecToDistMx(Mx<float> &DistMx) const
	{
	DistMx.Alloc("UPGMADistMx", m_LeafCount, m_LeafCount);
	for (unsigned i = 0; i < m_LeafCount; ++i)
		{
		for (unsigned j = 0; j < m_LeafCount; ++j)
			{
			if (i == j)
				DistMx.Put(i, i, float(0));
			else
				DistMx.Put(i, j, m_Dist[Trix(i, j)]);
			}
		}
	}

void UPGMA::LogDistMx(const Mx<float> &DistMx) const
	{
	const unsigned w = 8;
	Log("\n");
	Log("%*.*s", w, w, "");
	for (unsigned i = 0; i < m_LeafCount; ++i)
		Log("  %*.*s", w, w, m_Labels[i]);
	Log("\n");

	Log("%*.*s", w, w, "");
	for (unsigned i = 0; i < m_LeafCount; ++i)
		{
		Log("  ");
		for (unsigned j = 0; j < w; ++j)
			Log("-");
		}
	Log("\n");

	for (unsigned i = 0; i < m_LeafCount; ++i)
		{
		Log("%*.*s", w, w, m_Labels[i]);
		for (unsigned j = 0; j < m_LeafCount; ++j)
			{
			if (i == j)
				Log("  %*.*s", w, w, ".");
			else
				Log("  %*.3f", w, DistMx.Get(i, j));
			}
		Log("\n");
		}
	}

void UPGMA::ToNewickRecurse(FILE *f, unsigned NodeIndex,
  float BranchLength) const
	{
	if (IsLeaf(NodeIndex))
		fprintf(f, "%s:%.4f", m_Labels[NodeIndex], BranchLength);
	else
		{
		unsigned Left = m_Left[NodeIndex - m_LeafCount];
		unsigned Right = m_Right[NodeIndex - m_LeafCount];
		float LeftBranch = m_LeftLength[NodeIndex - m_LeafCount];
		float RightBranch = m_RightLength[NodeIndex - m_LeafCount];

		fprintf(f, "(");
		ToNewickRecurse(f, Left, LeftBranch);
		fprintf(f, ",\n");
		ToNewickRecurse(f, Right, RightBranch);
		fprintf(f, ")\n");
		if (!IsRoot(NodeIndex))
			fprintf(f, ":%.4f", BranchLength);
		}
	}

void UPGMA::ToNewick(const string &FileName) const
	{
	FILE *f = CreateStdioFile(FileName);
	ToNewickRecurse(f, GetRoot(), 0.0f);
	fprintf(f, ";\n");
	CloseStdioFile(f);
	}

/***
N=4, dist= (1,0), (2,0), (2,1), (3,0), (3,1), (3,2)
***/

void TestUPGMA()
	{
	const unsigned N = 4;
	const char *Names[N] = { "LeafA", "LeafB", "LeafC", "LeafD" };
	float Dist[(N*(N-1))/2] = { 1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f };

	UPGMA U;

	U.Init(Dist, Names, N);

	Mx<float> D0;
	U.DistVecToDistMx(D0);
	U.LogDistMx(D0);

	U.Cluster(LINKAGE_Avg);
	U.LogTree();

	Mx<float> D;
	U.GetDistMx(D);
	D.LogMe();
	U.LogDistMx(D);

	U.ToNewick("test.phy");
	}
