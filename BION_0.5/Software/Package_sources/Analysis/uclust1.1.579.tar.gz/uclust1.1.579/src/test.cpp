#include "myutils.h"
#include "seqdb.h"
#include "timing.h"

void Test()
	{
	if (0)
		;
	else if (opt_test == "diagbox")
		{
		void TestDiagBox();
		TestDiagBox();
		}
	else if (opt_test == "sfasta")
		{
		void TestSFasta();
		TestSFasta();
		}
	else if (opt_test == "beta")
		{
		void TestBeta();
		TestBeta();
		}
	else if (opt_test == "vit")
		{
		void TestVit();
		TestVit();
		}
	else if (opt_test == "band")
		{
		void TestBand();
		TestBand();
		}
	else if (opt_test == "pwa")
		{
		void TestPWA();
		TestPWA();
		}
	else if (opt_test == "enumpaths")
		{
		void TestEnumPaths();
		TestEnumPaths();
		}
	else if (opt_test == "gapstr")
		{
		void TestGapStr();
		TestGapStr();
		}
	else if (opt_test == "upgma")
		{
		void TestUPGMA();
		TestUPGMA();
		}
	else
		Die("Bad --test");

	LogTickStats();
	}
