#ifndef ultra_h
#define ultra_h

#include "windex.h"
#include "pwa.h"
#include "hit.h"

class Ultra;

typedef bool ON_HIT_FN(const HitData &Hit);

// An ultra-fast clustering class.
class Ultra
	{
public:
	double m_MinFractId;

// Word index for seeds
	Windex m_Windex;
	
// Pair-wise alignment class
	PWA m_PWA;
	AlnParams m_AP;
	AlnHeuristics m_AH;

// Number of seeds
	unsigned m_SeedCount;

// Max seed count (size of several vectors)
	unsigned m_MaxSeedCount;

// m_WordCounts[i] = number of words in common
// between current sequence and seed i.
	commonwordcount_t *m_WordCounts;

// "Hot" seeds exceed the threshold for number of
// words in common with current sequence.
// m_HotHits[i] = seed index of a hot hit
	unsigned *m_HotSeeds;

// m_HotHitWordsCounts[i] = number of words in common
// with seed m_HotHits[i].
	unsigned *m_HotWordCounts;

// Number of hot seeds.
	unsigned m_HotCount;

	unsigned *m_HotSortOrder;

// Max seq length (size of m_Words and m_UniqueWords).
	unsigned m_MaxSeqLength;

// Words in current sequence
	unsigned m_Step;
	word_t *m_CurrWords;
	unsigned m_CurrWordCount;

// Unique words in current sequence
	word_t *m_CurrUniqueWords;
	unsigned m_CurrUniqueWordCount;

// Current sequence
	const char *m_CurrLabel;
	const byte *m_CurrSeq;
	unsigned m_CurrSeqLength;

// If Rev is true, then both forward and reverse-complemented
// seeds sequences are stored and indexed. Seed 2n is forward,
// 2n+1 is rev-comp'd.
	bool m_Rev;

private:
// Seeds. Keep them private because we want to hide
// the implementation of minus strand searching.
// Strictly speaking we don't need to keep labels, but the
// memory needed will rarely be enough to matter and they are
// very handy for informative output.
	const char **m_SeedLabels;
	byte **m_SeedSeqs;
	unsigned *m_SeedLengths;

public:
	Ultra();
	virtual ~Ultra();
	void Clear(bool ctor = false);

	void Init(double FractId, unsigned WindexWordLength, unsigned FilterWordLength,
	  const AlnParams &AP, const AlnHeuristics &AH);
	void SetCurrSeq(const char *Label, const byte *Seq, unsigned L);
	void CurrSeqToWords(unsigned Step);
	//void SetSeed(unsigned SeedIndex);
	void SetWordCounts();
	void SetHotHits(unsigned MinWordCount);
	bool Search(const char *Label, const byte *Seq, unsigned L,
	  ON_HIT_FN OnHit, HitData &BestHit);
	bool OnHitWrapper(ON_HIT_FN OnHit, HitData &Hit);
	const char *AlignCurrToSeed(unsigned SeedIndex);
	void GetWordCountingParams(unsigned L, unsigned &MinWindexWordCount, unsigned &Step);

// Make current sequence a seed.
	unsigned AddSeed();
	unsigned AddSeed(const char *Label, const byte *Seq, unsigned L);

	void AllocSeqLength(unsigned SeqLength);
	void AllocSeedCount(unsigned SeedCount);

	const byte *GetSeedSeq(unsigned SeedIndex) const;
	unsigned GetSeedLength(unsigned SeedIndex) const;
	const char *GetSeedLabel(unsigned SeedIndex) const;
	};

#endif // ultra_h
