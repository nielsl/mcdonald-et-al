#include "myutils.h"
#include "ultra.h"
#include "sfasta.h"
#include "timing.h"
#include "seqdb.h"
#include "uc.h"
#include <time.h>

void LogAln(const byte *A, const byte *B, const char *Path);
void SortByLength(const string &InputFileName, const string &OutputFileName);
void SortDescending(const vector<unsigned> &Values, vector<unsigned> &Order);
void BlastOut(FILE *f, const char *LabelA, const char *LabelB,
  const byte *A, const byte *B, unsigned LA, unsigned LB,
  unsigned LoA, unsigned LoB, const string &Path_, char Strand,
  bool Nucleo);
void FastaPair(FILE *f, const HitData &Hit);
void GetLetterCounts(const char *Path, unsigned &NA, unsigned &NB);
const byte *RevComp(const byte *Seq, unsigned L);
const char *CompressPath(const char *Path);
bool OnHitChimeras(const Ultra &U, const HitData &Hit);
void OnNewSeqChimeras();
void OnDoneSeqChimeras();

extern bool g_IsNucleo;
extern float g_GapOpen;
extern float g_GapExt;

UCFile g_UC;
FILE *g_fBlastOut;
FILE *g_fFastaPairs;
static Ultra *g_U;
static unsigned g_LibSeedCount;

void SetOpts()
	{
	if (g_IsNucleo)
		{
		if (!optset_w)
			opt_w = 8;
		if (!optset_k)
			opt_k = 4;
		}
	else
		{
		if (!optset_w)
			opt_w = 5;
		if (!optset_k)
			opt_k = 3;
		}

	if (opt_exact)
		{
		opt_maxrejects = 0;
		opt_wordcountreject = false;
		}

	if (opt_optimal)
		{
		opt_maxaccepts = 0;
		opt_maxrejects = 0;
		opt_wordcountreject = false;
		}
	}

static bool OnHit(const HitData &Hit)
	{
	unsigned SeedIndex = Hit.SeedIndex;
	if (SeedIndex < g_LibSeedCount)
		{
		static vector<bool> AnyHits;
		if (SeedIndex >= SIZE(AnyHits))
			AnyHits.resize(SeedIndex+1, false);

		if (!AnyHits[SeedIndex])
			{
			const char *SeedLabel = g_U->GetSeedLabel(SeedIndex);
			unsigned L = g_U->GetSeedLength(SeedIndex);
			g_UC.WriteLibSeed(SeedIndex, L, SeedLabel);
			AnyHits[SeedIndex] = true;
			}
		}

	g_UC.WriteHit(Hit);

	FastaPair(g_fFastaPairs, Hit);

	BlastOut(g_fBlastOut, Hit.QueryLabel, Hit.SeedLabel, Hit.QuerySeq, Hit.SeedSeq,
	  Hit.QueryLength, Hit.SeedLength, Hit.QueryLo, Hit.SeedLo,
	  Hit.Path, Hit.Strand, g_IsNucleo);

	return true;
	}

static void LogPen(const char *Str, const float &Pen)
	{
	if (Pen == MINUS_INFINITY)
		Log("%10.10s", "*");
	else
		Log("%10.2f", -Pen);
	Log("  %s", Str);
	}

static void LogSettings(const AlnParams &AP, const AlnHeuristics &AH,
  const Ultra &U)
	{
	Log("\n");
	Log("Database search:\n");
	Log("%10.10s  Alphabet\n", g_IsNucleo ? "Nucleo" : "Amino");
	if (g_IsNucleo)
		Log("%10.10s  Strand(s)\n", opt_rev ? "Both" : "Plus only");
	Log("%10u  Max accepts\n", opt_maxaccepts);
	Log("%10u  Max rejects\n", opt_maxrejects);
	Log("%10u  Word length for unique word matching\n", U.m_Windex.m_WordLength);
	Log("%10.10s  Word count rejection\n", opt_wordcountreject ? "On" : "Off");

	if (opt_stepwords > 0)
		Log("%10u  Step words\n", opt_stepwords);
	else
		Log("%10.10s  Step words\n", "Off");

	if (opt_bump > 0)
		Log("%10u  Bump percent\n", opt_bump);
	else
		Log("%10.10s  Bumping\n", "Off");

	Log("\n");
	Log("Alignment:\n");
	if (g_IsNucleo)
		{
		Log("%10.2f  Match score\n", opt_match);
		Log("%10.2f  Mis-match score\n", opt_mismatch);
		}
	else
		{
		extern Mx<float> g_SubstMxf;
		Log("%10.10s  Substitution matrix\n", g_SubstMxf.m_Name.c_str());
		}
	bool Exact = AH.IsExact();
	Log("%10.10s  Fast heuristics\n", Exact ? "Off" : "On");
	if (!Exact)
		{
		Log("%10u  HSP length\n", opt_hsp);
		Log("%10u  Word length for HSP finding\n", U.m_PWA.m_HSPFinder.m_WordLength);
		Log("%10.2f  Minimum score/col of HSP\n", opt_hspscore);
		Log("%10u  Band radius\n", AH.BandWidth);
		}

	if (AP.Is2())
		{
		LogPen("Gap open penalty (internal and terminal)\n", AP.OpenA);
		LogPen("Gap ext. penalty (internal and terminal)\n", AP.ExtA);
		}
	else if (AP.Is4())
		{
		LogPen("Open penalty (internal gaps)\n", AP.OpenA);
		LogPen("Open penalty (end gaps)\n", AP.LOpenA);
		LogPen("Ext. penalty (internal gaps)\n", AP.ExtA);
		LogPen("Ext. penalty (end gaps)\n", AP.LExtA);
		}
	else
		{
		LogPen("Open penalty (query, internal)\n", AP.OpenA);
		LogPen("Open penalty (query, left end)\n", AP.LOpenA);
		LogPen("Open penalty (query, right end)\n", AP.ROpenA);
		LogPen("Open penalty (target, internal)\n", AP.OpenB);
		LogPen("Open penalty (target, left end)\n", AP.LOpenB);
		LogPen("Open penalty (target, right end)\n", AP.ROpenB);
		LogPen("Ext. penalty (query, internal)\n", AP.ExtA);
		LogPen("Ext. penalty (query, left end)\n", AP.LExtA);
		LogPen("Ext. penalty (query, right end)\n", AP.RExtA);
		LogPen("Ext. penalty (target, internal)\n", AP.ExtB);
		LogPen("Ext. penalty (target, left end)\n", AP.LExtB);
		LogPen("Ext. penalty (target, right end)\n", AP.RExtB);
		}
	}

void UCluster()
	{
	if (opt_uc == "" && opt_blastout == "" && opt_fastapairs == "")
		Die("No output file, use --uc, --blastout and/or --fastapairs");

	if (opt_uc != "")
		g_UC.Create(opt_uc);

	if (opt_blastout != "")
		{
		g_fBlastOut = CreateStdioFile(opt_blastout);
		string CmdLine;
		GetCmdLine(CmdLine);
		fprintf(g_fBlastOut, "# %s\n", CmdLine.c_str());
		fprintf(g_fBlastOut, "# version=1.1.%s\n", SVN_VERSION);
		}

	if (opt_fastapairs != "")
		g_fFastaPairs = CreateStdioFile(opt_fastapairs);

	string InputFileName = opt_input;

	SFasta SF;
	SF.Open(InputFileName);
	if (opt_amino)
		g_IsNucleo = false;
	else
		g_IsNucleo = opt_nucleo|| SF.IsNucleo();

	SetOpts();

	double FractId = opt_id;
	unsigned WindexWordLength = opt_w;
	unsigned FilterWordLength = opt_k;

	Ultra U;
	AlnParams AP;
	AlnHeuristics AH;

	AP.InitFromCmdLine(g_IsNucleo);
	AH.InitFromCmdLine();
	U.Init(FractId, WindexWordLength, FilterWordLength, AP, AH);

	U.m_PWA.m_CheckFast = opt_check_fast;
	g_U = &U;

	if (g_IsNucleo)
		U.m_Rev = opt_rev;

	LogSettings(AP, AH, U);

	if (opt_lib != "")
		{
		SFasta Lib;
		Lib.Open(opt_lib);
		unsigned Scale = 1000000;
		ProgressStep(0, Scale, "Reading lib, %u seeds", g_LibSeedCount);
		for (;;)
			{
			const byte *Seq = Lib.GetNextSeq();
			if (Seq == 0)
				break;

			double PctDone = Lib.GetPctDone();
			unsigned Counter = unsigned((PctDone*Scale)/100.0);
			if (Counter == 0)
				Counter = 1;
			if (Counter >= Scale-1)
				Counter = Scale-2;

			const char *Label = Lib.GetLabel();
			unsigned L = Lib.GetSeqLength();
			unsigned SeedIndex = U.AddSeed(Label, Seq, L);
			++g_LibSeedCount;
			//g_UC.WriteLibSeed(SeedIndex, L, Label);
			ProgressStep(Counter, Scale, "Reading lib, %u seeds", g_LibSeedCount);
			}
		ProgressStep(Scale-1, Scale, "Reading lib, %u seeds", g_LibSeedCount);

		Lib.Clear();
		}
	//U.m_Windex.LogWordStats(UINT_MAX);

	unsigned SeqCount = 0;
	unsigned TotalClusterCount = g_LibSeedCount;
	unsigned NewClusterCount = 0;
	unsigned HitCount = 0;
	unsigned MinLenCount = 0;
	unsigned MaxLenCount = 0;
	double SumId = 0.0;
	unsigned LastL = UINT_MAX;
	unsigned Scale = 1000000;
	ProgressStep(0, Scale, "");
	unsigned NotMatched = 0;
	vector<unsigned> ClusterSize(g_LibSeedCount, 1);
	vector<float> TotalFractId(g_LibSeedCount, 0);
	for (;;)
		{
		const byte *Seq = SF.GetNextSeq();
		if (Seq == 0)
			break;

		++SeqCount;
		double PctDone = SF.GetPctDone();
		unsigned Counter = unsigned((PctDone*Scale)/100.0);
		if (Counter == 0)
			Counter = 1;
		if (Counter >= Scale-1)
			Counter = Scale-2;
		
		double AvgSize = TotalClusterCount == 0 ? 0.0 : double(SeqCount)/TotalClusterCount;
		double AvgId = HitCount == 0 ? 0.0 : SumId*100/HitCount;

		if (opt_libonly)
			ProgressStep(Counter, Scale, "%.1f%% matched to lib at %.1f%%, id %.1f%%",
			  Pct(HitCount, SeqCount), FractId*100.0, AvgId);
		else if (g_LibSeedCount > 0)
			ProgressStep(Counter, Scale, "%.1f%% matched, %u new clusters at %.1f%%",
			  Pct(HitCount, SeqCount), NewClusterCount, FractId*100.0);
		else
			ProgressStep(Counter, Scale, "%u clusters at %.1f%%, size %.1f, id %.1f%%",
			  NewClusterCount, FractId*100.0, AvgSize, AvgId);

		const char *Label = SF.GetLabel();
		unsigned L = SF.GetSeqLength();
		if (L > LastL && !opt_usersort && !opt_libonly)
			Die("Input not sorted by length");
		LastL = L;

		if (L < opt_minlen)
			{
			++MinLenCount;
			continue;
			}
		else if (L > opt_maxlen && opt_maxlen > 0)
			{
			++MaxLenCount;
			continue;
			}

		bool Found = false;

		HitData BestHit;
		Found = U.Search(Label, Seq, L, OnHit, BestHit);
		if (Found)
			{
			++HitCount;

			double FractId = BestHit.FractId;
			asserta(FractId >= 0.0 && FractId <= 1.0);
			unsigned SeedIndex = BestHit.SeedIndex;
			++(ClusterSize[SeedIndex]);
			TotalFractId[SeedIndex] += (float) FractId;
			SumId += FractId;
			}
		else
			{
			if (opt_libonly)
				{
				++NotMatched;
				g_UC.WriteNotMatched(L, Label);
				}
			else
				{
				++NewClusterCount;
				++TotalClusterCount;
				unsigned SeedIndex = U.AddSeed();
				g_UC.WriteNewSeed(SeedIndex, L, Label);

				asserta(SeedIndex == SIZE(ClusterSize));

				ClusterSize.push_back(1);
				TotalFractId.push_back(0);
				}
			}
		}

	SF.Clear();

	double AvgSize = TotalClusterCount == 0 ? 0.0 : double(SeqCount)/TotalClusterCount;
	double AvgId = HitCount == 0 ? 0.0 : SumId*100/HitCount;

	if (opt_libonly)
		ProgressStep(Scale-1, Scale, "%.1f%% matched to lib at %.1f%%, id %.1f%%",
		  Pct(HitCount, SeqCount), FractId*100.0, AvgId);
	else if (g_LibSeedCount > 0)
		ProgressStep(Scale-1, Scale, "%.1f%% matched, %u new clusters at %.1f%%",
		  Pct(HitCount, SeqCount), NewClusterCount, AvgId);
	else
		ProgressStep(Scale-1, Scale, "%u clusters at %.1f%%, size %.1f, id %.1f%%",
		  TotalClusterCount, FractId*100.0, AvgSize, AvgId);

	LogStats();
	U.m_Windex.LogMemSize();
	U.m_Windex.LogWordStats();

	unsigned SeedCount = U.m_SeedCount;
	asserta(SIZE(ClusterSize) == TotalClusterCount);

	for (unsigned ClusterIndex = 0; ClusterIndex < TotalClusterCount; ++ClusterIndex)
		{
		asserta(ClusterIndex < SIZE(ClusterSize));
		asserta(ClusterIndex < SIZE(TotalFractId));

		unsigned Size = ClusterSize[ClusterIndex];
		const char *Label = U.GetSeedLabel(ClusterIndex);
		double AvgId = Size <= 1 ? 0 : TotalFractId[ClusterIndex]/(Size-1);

		if (ClusterIndex < g_LibSeedCount)
			g_UC.WriteLibCluster(ClusterIndex, Size, AvgId, Label);
		else
			g_UC.WriteNewCluster(ClusterIndex, Size, AvgId, Label);
		}

	g_UC.Clear();

	if (opt_check_fast)
		U.m_PWA.LogStats();

	U.Clear();

	Log("\n");
	if (MinLenCount > 0 || MaxLenCount > 0)
		Log("%u seqs < minlen=%u, %u seqs > maxlen=%u\n",
		  MinLenCount, opt_minlen, MaxLenCount, opt_maxlen);

	if (g_LibSeedCount == 0)
		Log("%u seqs, %u clusters, avg size %.1f, avg id %.1f%%\n",
		  SeqCount, NewClusterCount, AvgSize, AvgId);
	else
		Log("%u seqs, %u lib/%u new clusters, avg size %.1f, avg id %.1f%%\n",
		  SeqCount, g_LibSeedCount, NewClusterCount, AvgSize, AvgId);

	if (NotMatched > 0)
		Log("%u (%.1f%%) not matched\n", NotMatched, Pct(NotMatched, SeqCount));

	if (g_fBlastOut != 0)
		{
		CloseStdioFile(g_fBlastOut);
		g_fBlastOut = 0;
		}
	}
