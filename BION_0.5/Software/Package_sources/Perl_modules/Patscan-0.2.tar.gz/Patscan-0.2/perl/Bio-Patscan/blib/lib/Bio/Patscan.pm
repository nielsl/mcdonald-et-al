package Bio::Patscan;

use 5.010000;
use strict;
use warnings;

our $VERSION = '0.01';

require XSLoader;
XSLoader::load('Bio::Patscan', $VERSION);

# Preloaded methods go here.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Bio::Patscan - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Bio::Patscan;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Bio::Patscan, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.

=head2 Exportable functions

  void _Exit(int) __attribute__((__noreturn__))
  unsigned long ___runetype(__darwin_ct_rune_t)
  __darwin_ct_rune_t ___tolower(__darwin_ct_rune_t)
  __darwin_ct_rune_t ___toupper(__darwin_ct_rune_t)
  int __maskrune(__darwin_ct_rune_t, unsigned long)
  int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  
  int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  
  int __srget(FILE *)
  int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)))
  int __swbuf(int, FILE *)
  __darwin_ct_rune_t __tolower(__darwin_ct_rune_t)
  __darwin_ct_rune_t __toupper(__darwin_ct_rune_t)
  int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  
  int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  
  long a64l(const char *)
  void abort(void) __attribute__((__noreturn__))
  int abs(int) __attribute__((__const__))
  void *alloca(size_t)
  u_int32_t
  arc4random(void)
  void arc4random_addrandom(unsigned char * , int )
  void arc4random_buf(void * , size_t ) __attribute__((visibility("default")))
  void arc4random_stir(void)
  u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")))
  int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)))
  int atexit(void (*)(void))
  int atexit_b(void (^)(void)) __attribute__((visibility("default")))
  double atof(const char *)
  int atoi(const char *)
  long atol(const char *)
  long long
  atoll(const char *)
  int bcmp(const void *, const void *, size_t) 
  void bcopy(const void *, void *, size_t) 
  void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *))
  void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")))
  void bzero(void *, size_t) 
  void *calloc(size_t, size_t)
  char *cgetcap(char *, const char *, int)
  int cgetclose(void)
  int cgetent(char **, char **, const char *)
  int cgetfirst(char **, char **)
  int cgetmatch(const char *, const char *)
  int cgetnext(char **, char **)
  int cgetnum(char *, const char *, long *)
  int cgetset(const char *)
  int cgetstr(char *, const char *, char **)
  int cgetustr(char *, const char *, char **)
  void clearerr(FILE *)
  int comp_data(char *in, char *out)
  char compl(char c)
  char *ctermid(char *)
  char *ctermid_r(char *)
  char *devname(dev_t, mode_t)
  char *devname_r(dev_t, mode_t, char *buf, int len)
  div_t div(int, int) __attribute__((__const__))
  int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")))
  double drand48(void)
  char *ecvt(double, int, int *, int *)
  double erand48(unsigned short[3])
  void exit(int) __attribute__((__noreturn__))
  int fclose(FILE *)
  char *fcvt(double, int, int *, int *)
  int feof(FILE *)
  int ferror(FILE *)
  int fflush(FILE *)
  int ffs(int)
  int ffsl(long) __attribute__((visibility("default")))
  int fgetc(FILE *)
  char *fgetln(FILE *, size_t *)
  int fgetpos(FILE * , fpos_t *)
  char *fgets(char * , int, FILE *)
  int fileno(FILE *)
  void flockfile(FILE *)
  int fls(int) __attribute__((visibility("default")))
  int flsl(long) __attribute__((visibility("default")))
  const char *fmtcheck(const char *, const char *)
  int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)))
  int fpurge(FILE *)
  int fputc(int, FILE *)
  size_t fread(void * , size_t, size_t, FILE * )
  void free(void *)
  int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)))
  int fseek(FILE *, long, int)
  int fseeko(FILE *, off_t, int)
  int fsetpos(FILE *, const fpos_t *)
  long ftell(FILE *)
  off_t ftello(FILE *)
  int ftrylockfile(FILE *)
  void funlockfile(FILE *)
  FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *))
  char *gcvt(double, int, char *)
  char *getbsize(int *, long *)
  int getc(FILE *)
  int getc_unlocked(FILE *)
  int getchar(void)
  int getchar_unlocked(void)
  ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")))
  char *getenv(const char *)
  int getiopolicy_np(int, int) __attribute__((visibility("default")))
  ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")))
  int getloadavg(double [], int)
  int getpriority(int, id_t)
  const char
 *getprogname(void)
  int getrusage(int, struct rusage *)
  char *gets(char *)
  int getsubopt(char **, char * const *, char **)
  int getw(FILE *)
  int grantpt(int)
  int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *))
  int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")))
  char *index(const char *, int) 
  char *initstate(unsigned, char *, size_t)
  long jrand48(unsigned short[3])
  char *l64a(long)
  long labs(long) __attribute__((__const__))
  void lcong48(unsigned short[7])
  ldiv_t ldiv(long, long) __attribute__((__const__))
  long long
  llabs(long long)
  lldiv_t lldiv(long long, long long)
  long lrand48(void)
  void *malloc(size_t)
  unsigned long *match_pattern_forward(const char* seq, int protein)
  unsigned long *match_pattern_reverse(const char* seq)
  int mblen(const char *, size_t)
  size_t mbstowcs(wchar_t * , const char * , size_t)
  int mbtowc(wchar_t * , const char * , size_t)
  void *memccpy(void *, const void *, int, size_t)
  void *memchr(const void *, int, size_t)
  int memcmp(const void *, const void *, size_t)
  void *memcpy(void *, const void *, size_t)
  void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")))
  void *memmove(void *, const void *, size_t)
  void *memset(void *, int, size_t)
  void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")))
  void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")))
  void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")))
  int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *))
  int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")))
  int mkstemp(char *)
  char *mktemp(char *)
  long mrand48(void)
  long nrand48(unsigned short[3])
  int parse_dna_cmd(char *line)
  int parse_peptide_cmd(char *line)
  int pclose(FILE *)
  void perror(const char *)
  int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")))
  int posix_openpt(int)
  int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)))
  void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")))
  void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")))
  void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")))
  char *ptsname(int)
  int putc(int, FILE *)
  int putc_unlocked(int, FILE *)
  int putchar(int)
  int putchar_unlocked(int)
  int puts(const char *)
  int putw(int, FILE *)
  void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *))
  void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")))
  void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *))
  int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned)
  int rand(void)
  int rand_r(unsigned *)
  long random(void)
  void *realloc(void *, size_t)
  void *reallocf(void *, size_t)
  int remove(const char *)
  int rename (const char *, const char *)
  void rewind(FILE *)
  char *rindex(const char *, int) 
  int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)))
  unsigned short
 *seed48(unsigned short[3])
  void setbuf(FILE * , char * )
  void setbuffer(FILE *, char *, int)
  int setiopolicy_np(int, int, int) __attribute__((visibility("default")))
  int setlinebuf(FILE *)
  int setpriority(int, id_t, int)
  void setprogname(const char *)
  char *setstate(const char *)
  int setvbuf(FILE * , char * , int, size_t)
  int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)))
  int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)))
  int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned)
  void srand(unsigned)
  void srand48(long)
  void sranddev(void)
  void srandom(unsigned)
  void srandomdev(void)
  int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)))
  char *stpcpy(char *, const char *)
  char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")))
  int strcasecmp(const char *, const char *)
  char *strcasestr(const char *, const char *)
  char *strcat(char *, const char *)
  char *strchr(const char *, int)
  int strcmp(const char *, const char *)
  int strcoll(const char *, const char *)
  char *strcpy(char *, const char *)
  size_t strcspn(const char *, const char *)
  char *strdup(const char *)
  int strerror_r(int, char *, size_t)
  size_t strlcat(char *, const char *, size_t)
  size_t strlcpy(char *, const char *, size_t)
  size_t strlen(const char *)
  void strmode(int, char *)
  int strncasecmp(const char *, const char *, size_t)
  char *strncat(char *, const char *, size_t)
  int strncmp(const char *, const char *, size_t)
  char *strncpy(char *, const char *, size_t)
  char *strndup(const char *, size_t) __attribute__((visibility("default")))
  size_t strnlen(const char *, size_t) __attribute__((visibility("default")))
  char *strnstr(const char *, const char *, size_t)
  char *strpbrk(const char *, const char *)
  char *strrchr(const char *, int)
  char *strsep(char **, const char *)
  char *strsignal(int sig)
  size_t strspn(const char *, const char *)
  char *strstr(const char *, const char *)
  char *strtok(char *, const char *)
  char *strtok_r(char *, const char *, char **)
  long strtol(const char *, char **, int)
  long double
  strtold(const char *, char **) 
  long long
  strtoll(const char *, char **, int)
  long long
  strtoq(const char *, char **, int)
  unsigned long
  strtoul(const char *, char **, int)
  unsigned long long
  strtoull(const char *, char **, int)
  unsigned long long
  strtouq(const char *, char **, int)
  size_t strxfrm(char *, const char *, size_t)
  void swab(const void * , void * , ssize_t)
  FILE *tmpfile(void)
  char *tmpnam(char *)
  int ungetc(int, FILE *)
  int unlockpt(int)
  void *valloc(size_t)
  int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)))
  int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")))
  int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)))
  int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)))
  int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)))
  int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)))
  int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)))
  int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)))
  int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)))
  pid_t wait3(int *, int, struct rusage *)
  pid_t wait4(pid_t, int *, int, struct rusage *)
  size_t wcstombs(char * , const wchar_t * , size_t)
  int wctomb(char *, wchar_t)
  FILE *zopen(const char *, const char *, int)



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Gene Selkov, E<lt>selkovjr@localE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2012 by Gene Selkov

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.12.3 or,
at your option, any later version of Perl 5 you may have available.


=cut
