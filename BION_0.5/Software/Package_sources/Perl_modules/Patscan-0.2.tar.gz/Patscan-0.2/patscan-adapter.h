#include <string.h>

void match_pattern( char* cdata, int datlen, unsigned long *hitbuf );
void match_pattern_forward( char* seq, int seqlen, unsigned long* hitbuf, int protein);
void match_pattern_reverse( char* seq, int seqlen, unsigned long* hitbuf, int protein);
