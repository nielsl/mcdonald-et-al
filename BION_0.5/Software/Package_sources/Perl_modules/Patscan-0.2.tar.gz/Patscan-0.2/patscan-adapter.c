#include "patscan-adapter.h"
#include "patscan.h"

char *hits[2000];

void match_pattern_forward( char *seq, int seqlen, unsigned long *hitbuf, int protein )
{
    /* 
       Gene Selkov and Niels Larsen, January 2012.
      
       Matches a given sequence character array against an already parsed pattern
       in the forward direction. 
    */

    char cdata[ seqlen+1 ];

    /* For protein use character data as is, DNA and RNA is compacted to 2 bit */

    if ( protein)
    {
        /* Scan for matches, using original data - Ross: is this safe? */

        match_pattern( seq, seqlen, hitbuf );
    }
    else
    {
        /* Compact to 2 bit */

        comp_data( seq, cdata );

        /* Scan for matches */

        match_pattern( cdata, seqlen, hitbuf );
    }
    
    return;
}

void match_pattern_reverse( char* seq, int seqlen, unsigned long *hitbuf, int protein )
{
    /* 
       Gene Selkov and Niels Larsen, January 2012.
      
       Matches a given sequence character array against an already parsed pattern
       in the reverse direction. 
    */

    char data[ seqlen+1 ];
    char cdata[ seqlen+1 ];
    
    unsigned long i, j;
    char tmp;

    if ( protein )
    {
        /* Scan for matches, using original data - Ross: is this safe? */

        match_pattern( seq, seqlen, hitbuf );
    }
    else
    {
        /* Make complemented version */ 

        for ( i = 0, j = seqlen-1; i <= j; i++, j-- )
        {
            tmp = compl( seq[i] );
            data[i] = compl( seq[j] );
            data[j] = tmp;
        }

        /* Compact to 2 bit */

        comp_data( data, cdata );

        /* Scan for matches */

        match_pattern( cdata, seqlen, hitbuf );
    }        

    return;
}

void match_pattern_reverse_alt( char* seq, int seqlen, unsigned long *hitbuf, int protein )
{
    /* 
       Gene Selkov and Niels Larsen, January 2012.
      
       As match_pattern_reverse, but the incoming sequence is altered, rather than
       a copy being made. For DNA/RNA the complemented version is returned, for
       proteins the begin/end character order is swapped.
    */

    char cdata[ seqlen+1 ];
    
    unsigned long i, j;
    char tmp;

    if ( protein )
    {
        for ( i = 0, j = seqlen-1; i <= j; i++, j-- )
        {
            tmp = seq[i];
            seq[i] = seq[j];
            seq[j] = tmp;
        }
        
        match_pattern( seq, seqlen, hitbuf );
    }
    else
    {
        for ( i = 0, j = seqlen-1; i <= j; i++, j-- )
        {
            tmp = compl( seq[i] );
            seq[i] = compl( seq[j] );
            seq[j] = tmp;
        }

        comp_data( seq, cdata );

        match_pattern( cdata, seqlen, hitbuf );
    }        

    return;
}

void match_pattern( char* cdata, int datlen, unsigned long *hitbuf )
{
    /*
       Gene Selkov and Niels Larsen, January 2012.
      
       Matches a given character array against an already parsed pattern in the 
       forward direction. Returns a buffer where the match positions are encoded
       like this example:

       { 2,  2,0,6,10,5,  2,30,7,39,5 }

       First element is the number of matches with the entire pattern, and each 
       following number clusters are the pattern element matches. The first match 
       says "two sub-matches, the first starting at 0 and of length 6, the second
       at position 10, length 5". 

       The hitbuf array must be decoded by higher-level languages. See the function 
       decode_matches_forward in Bio::Patscan.pm on CPAN for a perl example.
    */

    unsigned long match_count, bufndx;
    unsigned long pu_hits, pu_hit_len, i, j;
    
    match_count = 0;
    bufndx = 1;

    for ( pu_hits = first_match( cdata, datlen, hits ); pu_hits > 0; pu_hits = cont_match( hits ) )
    {
        match_count++;

        hitbuf[bufndx++] = pu_hits;

        for ( i = 0; i < pu_hits; i++ )
        {
            pu_hit_len = hits[i + 1] - hits[i];

            hitbuf[bufndx++] = hits[i] - cdata;
            hitbuf[bufndx++] = pu_hit_len;
        }
    }

    hitbuf[0] = match_count;

    return;
}
