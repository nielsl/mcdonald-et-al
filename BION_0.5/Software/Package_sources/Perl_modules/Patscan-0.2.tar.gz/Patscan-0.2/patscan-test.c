#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>

#include "patscan-adapter.h"

#define MAX_SEQ_LEN 10000000
#define MAX_PAT_LINE_LN 32000

/* ============================================================= */
/* ============================================================= */

unsigned long buf[12000]; // the return value of the match function

typedef struct match_str {
  unsigned long index;
  unsigned long length;
} match;

const char *test_dna_pattern[1] = {
  /*
  "4...8",
  "p1=4...7 3...8 ~p1",
  "p1=4...4 ~p1",
  "p1=3...8 0...5 p1",
  "p1=2...3 0...4 p2=2...5 1...5 ~p2 0...4 ~p1",
  "p1=2...3 p3=0...4 p2=2...5 p4=1...5 ~p2 p5=0...4 length(p3+p4+p5) < 7 ~p1",
  "p1={(50,0,50,0),(0,0,0,75),(50,50,0,0)} > 100 0...10 p1",
  "p1=175 > {(50,0,50,0),(0,0,0,75),(50,50,0,0)} > 100 0...10 p1",
  "p1=AYYYRC[1,0,0] 0...30 p1",
  "r1={au,ua,gc,cg,gu,ug,ga,ag} r2={au,ua,gc,cg} p1=2...3 0...4 p2=2...5 1...5 r1~p2 0...4 r2~p1",
  "p1=4...4 2...8 ~p1[0,1,0]",
  "p1=4...4 2...8 ~p1[0,0,1]",
  "p1=4...4 (GGCC | CCGG) ~p1[0,0,1]",
  //  "p1=nnnn p1 p1",
  */
  //"TACGUAAC CGGTTAA",
  //"CGGTTAA 4...4 UUACGT"
  "T"
};

const char *test_dna_input[1] = {
  //"acgtacguaaccggttaaccgguuacgtacgu",
  //"ACGTACGUAACCGGTTAACCGGUUACGTACGUACGTACGUAACCGGTTAACCGGUUACGTACGU"
  "ATGGGGGGTATCCCCCGT"
};

const char *dna_id[3] = {
  "tst1",
  "tst2",
  "tst3"
};


const char *test_prot_pattern[4] = {
  "ACG 0...4 any(HQD) 1...3 notany(HK)",
  "ACGL[1,0,0] 0...4 any(HQD) 1...3 notany(HK)",
  "p1=0...4 any(HQD) 1...3 notany(HK) p1",
  "CGXXYWG[1,0,0]"
};


const char *test_prot_input[2] = {
  "ACGHYWQLLVAAGG",
  "ACGGHYAGG"
};

const char *prot_id[2] = {
  "tstprot1",
  "tstprot2"
};


char *data, *cdata;

int parse_pattern (const char* pattern, int protein) {
  if (protein) {
    return parse_peptide_cmd(pattern);
  }
  else {
    return parse_dna_cmd(pattern);
  }
}


main(argc,argv)
int argc;
char *argv[];
{
  int complements=0;
  int protein=0;

  int i, p;

  unsigned long *match, *mp;
  int m, sm, n;
  char *bp;
  int group_c;

  
  if (((data  = malloc(MAX_SEQ_LEN+1)) == NULL) || ((cdata  = malloc(MAX_SEQ_LEN+1)) == NULL)) {
    fprintf(stderr,"failed to alloc memory\n");
  }


  for (p = 0; p < 1; p++) { // pattern loop
    printf("=====================\n");
    printf("%s\n\n\n", test_dna_pattern[p]);
    parse_pattern(test_dna_pattern[p], 0);
    for (i = 0; i < 1; i++) { // input loop
      fprintf(stderr, "patt: %s\n", test_dna_pattern[p]);
      fprintf(stderr, "  against: %s\n", test_dna_input[i]);
      // mp = match = match_pattern_forward( test_dna_input[i], 0 );
      mp = match = match_pattern_reverse( test_dna_input[i], strlen(test_dna_input[i]) );

      // hex dump
      group_c = 0;
      bp = (char *)match;
      while( bp < (char *)match + 200) {
        group_c++;
        fprintf(stderr, "%2x", *bp++);
        if ( group_c % 8 == 0) {
          fprintf(stderr, " ");
        }
      }
      fprintf(stderr, "\n");

      fprintf(stderr, "number of matches: %ld\n", match[0]);
      fprintf(stderr, "number of submatches: %ld\n", match[1]);

      mp++; // progress to the first submatch counter
      // now mp points to the same object as match[1]

      for (m = 0; m < match[0]; m++) { // the first element is the number of matches
        // read a match
        fprintf (stderr, "match %d, with %ld submatches\n", m, *mp);

        n = *mp++;  // mp has not changed until n was read; n == match[1]
        // now mp points at the first submatch index

        for (sm = 0; sm < n; sm++) { // the current element at mp is the number of submatches
          // read a submatch (there only two elements)
          fprintf (stderr, "  reading submatch %d\n", sm);
          fprintf (stderr, "    index: %ld\n", *mp++); // element 1
          fprintf (stderr, "    length: %ld\n", *mp++); // element 2
          // now mp points to the next structure, whatever it is, or end of input.
        }
      }
    }
  }

  exit(0);
  printf("==========<<<< Protein Matches >>>>==========\n");
  for (p = 0; p < 4; p++) { // pattern loop
    printf("=====================\n");
    printf("%s\n\n\n", test_prot_pattern[p]);
    parse_pattern(test_prot_pattern[p], 1);
    for (i = 0; i < 2; i++) { // input loop
      match_pattern(prot_id[i], test_prot_input[i], complements, 1);
    }
  }
}

//    n_matches [n_submatches match match match] [2 mach match] [1 match] [3 match match match]
