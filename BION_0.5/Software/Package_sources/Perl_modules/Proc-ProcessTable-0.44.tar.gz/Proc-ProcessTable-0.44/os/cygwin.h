static char *Fields[] = {
	"uid",
	"pid",
	"ppid",
	"pgid",
	"winpid",
	"fname",
	"start",
	"ttynum",
	"state",
};
