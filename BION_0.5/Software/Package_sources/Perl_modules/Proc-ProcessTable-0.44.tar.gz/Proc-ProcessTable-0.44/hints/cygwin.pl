symlink "os/cygwin.c", "OS.c" || die "Could not link os/cygwin.c to os/OS.c\n";
