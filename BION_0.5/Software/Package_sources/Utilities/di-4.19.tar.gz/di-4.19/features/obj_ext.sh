#!/bin/sh
#
# $Id: obj_ext.sh,v 1.10 2010-01-31 11:30:08-08 bll Exp $
# $Source: /home/bll/DI/features.base/RCS/obj_ext.sh,v $
# Copyright 2001-2010 Brad Lanam, Walnut Creek, California, USA
#

OBJEXT_FILE=object_ext

if [ ! -f "${OBJEXT_FILE}" ]
then
    cat > x$$.c << HERE
#include <stdio.h>
main ()
{
    printf ("hello\n");
    return 0;
}
HERE

    ${CC} ${CFLAGS} -c x$$.c > /dev/null 2>&1 # don't care about warnings...
    OBJ_EXT=".o"
    if [ -f "x$$.obj" ]
    then
         OBJ_EXT=".obj"
    fi
    rm -f x$$.o x$$.obj a.out > /dev/null 2>&1

    ${CC} ${CFLAGS} -o x$$ x$$.c > /dev/null 2>&1 # don't care about warnings...
    EXE_EXT=""
    if [ -f "x$$.exe" ]
    then
         EXE_EXT=".exe"
    fi
    rm -f x$$.c x$$.o x$$.obj x$$ x$$.exe a.out > /dev/null 2>&1

    echo "OBJ_EXT=${OBJ_EXT};" > ${OBJEXT_FILE}
    echo "EXE_EXT=${EXE_EXT};" >> ${OBJEXT_FILE}
    echo "export OBJ_EXT;" >> ${OBJEXT_FILE}
    echo "export EXE_EXT" >> ${OBJEXT_FILE}
fi

cat ${OBJEXT_FILE}
exit 0
